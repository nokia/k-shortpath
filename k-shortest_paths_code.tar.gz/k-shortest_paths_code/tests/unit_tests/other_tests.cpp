// initialize CATCH
#pragma clang diagnostic push
#pragma ide diagnostic ignored "ClangTidyInspection"

#include "catch.hpp"
#include "test_tools.h"

// other includes
#include <omp.h>
#include "Yen.h"
#include "OptYen.h"
#include "Katoh.h"
#include "Feng.h"
#include "DeltaSteppingStatic.h"
#include "DeltaSteppingDynamic.h"
#include "GraphRW.h"

const gt_undirected G_d01 = GraphRW::read_graph(const_cast<char*>("../resources/big_metis_file.graph"), const_cast<char*>("0.1"),
                                             GraphRW::file_type::METIS, GraphRW::weight_converting::ORIGINAL);
const gt_undirected G_d1  = GraphRW::read_graph(const_cast<char*>("../resources/big_metis_file.graph"), const_cast<char*>("1"),
                                             GraphRW::file_type::METIS, GraphRW::weight_converting::ORIGINAL);
const gt_directed G_dd01  = GraphRW::read_graph<true, true, true>(const_cast<char*>("../resources/directed_test_big.edgelist"), const_cast<char*>("0.1"),
                                             GraphRW::file_type::EDGELIST, GraphRW::weight_converting::ORIGINAL);

/* todo binary files are all broken due to the big graph refactoring
 * delete this or fix it if binary graphs are still needed.
 */
//SCENARIO("Read Binary Files")
//{
//    REQUIRE_NOTHROW([]()
//                    {
//                        // check if reading works
//                        BasicGraph G(const_cast<char*>("../resources/big_binary_file.graph"), BasicGraph::BINARY);
//                        // check if the graph is read correctly. We should see the expected k shortest paths.
//                        testKSP<Yen, DeltaSteppingDynamic, gt>(G, 1);        // delta = 0.1
//                    }());
//}

SCENARIO("Read Edgelist Files")
{
    auto test = []()
    {
        using gt = BasicGraph<false, true>;
        // check if reading works
        gt G = GraphRW::read_graph(const_cast<char*>("../resources/big_metis_file.graph"), const_cast<char*>("0.1"),
                                   GraphRW::file_type::METIS, GraphRW::weight_converting::ORIGINAL);
        // check if the graph is read correctly. We should see the expected k shortest paths.
        testKSP<Yen, DeltaSteppingDynamic, gt, 1, false>(G);
    };

    REQUIRE_NOTHROW(test());
}

TEST_CASE("Reverse Graph")
{
    REQUIRE(G_d01.check_reverse_graph());
}

SCENARIO("Reverse SSSP trees")
{
    using gt = BasicGraph<true, false>;

    gt G = GraphRW::read_graph<true, false, true>(const_cast<char*>("../resources/directed_test.edgelist"), const_cast<char*>("0.1"), GraphRW::file_type::EDGELIST, GraphRW::weight_converting::ORIGINAL);

    KSPGraph<gt> KG(G);
    DeltaSteppingDynamic<gt> d(KG, 1);
    d.compute(0);

    KSPGraph<gt> KG_reverse(G.get_reverse_graph());
    DeltaSteppingDynamic<gt> d2(KG_reverse, 1);
    d2.compute(3);

    auto path_orig    = d.get_shortest_path_to(3);
    auto path_reverse = d2.get_shortest_path_to(0, true);

    REQUIRE(path_orig == path_reverse);
}

SCENARIO("Feng's Algorithm on directed graphs", "[feng][directed]")
{
    auto seed = static_cast<unsigned int>(time(nullptr));
    srand(seed);

    for(unsigned int j = 0; j < 10; )
    {
        try
        {
            const NODE_ID source = rand() % G_dd01.get_num_nodes();
            const NODE_ID target = rand() % G_dd01.get_num_nodes();

            Feng<DeltaSteppingStatic, gt_directed, 1, false> ksp(G_dd01, k);
            path_list paths = ksp.compute(source, target);

            REQUIRE(paths.size() > 2);
            for(unsigned int i = 1; i < paths.size(); i++)
            {
                CAPTURE(source);
                CAPTURE(target);
                CAPTURE(j);
                CAPTURE(i);
                REQUIRE(paths[i - 1].length <= paths[i].length);
            }
        }
        catch(NoPathException& e)
        {
            std::cerr << "s and t are not connected -> retry" << std::endl;
            continue;
        }

        j++;    // only count this run if source and destination were connected.
    }
}


TEST_CASE("Feng statistics")
{
    srand(static_cast<unsigned int>(time(nullptr)));

    Feng<DeltaSteppingDynamic, gt_directed, 1, false> ksp(G_dd01, k);

    while(true)
    {
        try
        {

            const NODE_ID source = rand() % G_dd01.get_num_nodes(),
                          target = rand() % G_dd01.get_num_nodes();

            std::vector<Path> paths = ksp.compute(source, target);

            auto stats = ksp.get_stats();

            for(unsigned int i = 0; i < paths.size(); i++)
            {
                CAPTURE(source);
                CAPTURE(target);
                REQUIRE(paths[i].length == stats.lengths[i]);
                REQUIRE(paths[i].p.size() - 1 == stats.hops[i]);
            }

            for(unsigned int i = 1; i < paths.size(); i++)
            {
                CAPTURE(source);
                CAPTURE(target);
                REQUIRE(paths[i - 1].length < paths[i].length);
            }

            break;
        }
        catch(NoPathException& e)
        {
            std::cerr << "no path from s to t -> retry" << std::endl;
            continue;
        }
    }
}

TEST_CASE("G(n,m) generator", "[generator]")
{
    SECTION("directed")
    {
        GraphRW::generate_G_n_m<true>(100, 1000, "directed_test_graph.metis");
        auto graph = GraphRW::read_graph<true>(const_cast<char*>("directed_test_graph.metis"), const_cast<char*>("0.1"),
                                               GraphRW::file_type::METIS, GraphRW::weight_converting::ORIGINAL);

        REQUIRE(graph.get_num_nodes() == 100);
        REQUIRE(graph.get_num_edges() == 1000);
    }

    SECTION("undirected")
    {
        GraphRW::generate_G_n_m<false>(100, 1000, "undirected_test_graph.metis");
        auto graph = GraphRW::read_graph<false>(const_cast<char*>("undirected_test_graph.metis"), const_cast<char*>("0.1"),
                                                GraphRW::file_type::METIS, GraphRW::weight_converting::ORIGINAL);

        REQUIRE(graph.get_num_nodes() == 100);
        REQUIRE(graph.get_num_edges() == 2000);

        for(NODE_ID u = 0; u < 100; u++)
        {
            for(auto e = graph.get_edge_list_begin_iter(u); e < graph.get_edge_list_end_iter(u); ++e)
            {
                REQUIRE(e->get_weight() == graph.get_edge_weight(u, e->get_target()));
            }
        }
    }
}

#pragma clang diagnostic pop