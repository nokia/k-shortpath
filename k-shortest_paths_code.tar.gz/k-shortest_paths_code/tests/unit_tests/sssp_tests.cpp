//
// Created by Alex Schickedanz <alex@ae.cs.uni-frankfurt.de> on 05.09.17.
//

#include "catch.hpp"
#include "test_tools.h"

#include "GraphRW.h"
#include "DeltaSteppingDynamic.h"
#include "DeltaSteppingStatic.h"
#include "Dijkstra.h"

struct test_struct
{
    int i;
    int j;

    test_struct(int i, int j) : i(i), j(j) {}

    friend bool operator < (const test_struct& l, const test_struct& r)
    {
        return l.j < r.j;
    }
};

const gt_undirected G_d01 = GraphRW::read_graph(const_cast<char*>("../resources/big_metis_file.graph"), const_cast<char*>("0.1"),
                                                GraphRW::file_type::METIS, GraphRW::weight_converting::ORIGINAL);
const gt_undirected G_d1  = GraphRW::read_graph(const_cast<char*>("../resources/big_metis_file.graph"), const_cast<char*>("1"),
                                                GraphRW::file_type::METIS, GraphRW::weight_converting::ORIGINAL);
const gt_directed G_dd01 = GraphRW::read_graph<true, true, true>(const_cast<char*>("../resources/directed_test_big.edgelist"), const_cast<char*>("0.1"),
                                                                 GraphRW::file_type::EDGELIST, GraphRW::weight_converting::ORIGINAL);


SCENARIO("Delta Stepping works with disconnected directed graphs")
{
    BasicGraph<true, true> G = GraphRW::read_graph<true, true>(const_cast<char*>("../resources/disconnected.metis"),
                                                               const_cast<char*>("0.1"), GraphRW::file_type::METIS,
                                                               GraphRW::weight_converting::ORIGINAL);

    KSPGraph<gt_directed> KSPG(G);

    WHEN("array-delta-stepping")
    {
        DeltaSteppingDynamic<gt_directed> ds(KSPG, 1);
        ds.compute(0, 2);
        REQUIRE(ds.get_distance(2) == static_cast<w_type>(0.1));
    }

    WHEN("list-delta-stepping")
    {
        DeltaSteppingStatic<gt_directed> ds(KSPG, 1);
        ds.compute(0, 2);
        REQUIRE(ds.get_distance(2) == static_cast<w_type>(0.1));
    }
}

SCENARIO("Priority Queue")
{
    WHEN("Using Integers")
    {
        PriorityQueue<int> pq;

        for(int i = 10; i > 0; --i)
            pq.push(i);

        for(int i = 1; !pq.empty(); i++)
        {
            REQUIRE(pq.top() == i);
            pq.pop();
        }
    }

    WHEN("using decrease key")
    {
        PriorityQueue<int> pq;

        for(int i = 10; i > 0; --i)
            pq.push(i * 2);

        for(int i = 12; i <= 20; i += 2)
            pq.update_key(i, i - 11);

        for(int i = 1; !pq.empty(); i++)
        {
            REQUIRE(pq.top() == i);
            pq.pop();
        }
    }

    WHEN("Using structs (using emplace)")
    {
        GIVEN("with less operator")
        {
            PriorityQueue<test_struct> pq;

            for(int i = 10; i > 0; i--)
                pq.emplace(1, i);


            for(int i = 1; !pq.empty(); i++)
            {
                REQUIRE(pq.top().j == i);
                pq.pop();
            }
        }

        GIVEN("with lambdas")
        {
            auto cmp = [](const test_struct &a, const test_struct &b) -> bool {
                return a.j > b.j;
            };

            PriorityQueue<test_struct, decltype(cmp)> pq(cmp);

            for(int i = 1; i <= 10; i++)
                pq.emplace(1, i);

            for(int i = 10; !pq.empty(); i--)
            {
                REQUIRE(pq.top().j == i);
                pq.pop();
            }
        }

        GIVEN("with update key")
        {
            auto cmp = [](const test_struct &a, const test_struct &b) -> bool {
                return a.j > b.j;
            };

            auto updater = [](test_struct& el, int new_key){ el.j = new_key; };

            PriorityQueue<test_struct, decltype(cmp), int, decltype(updater)> pq(cmp, updater);

            for(int i = 1; i <= 10; i++)
                pq.emplace(1, i);

            test_struct el(1,100);
            pq.push(el);

            pq.update_key(el, 0);

            for(int i = 10; !pq.empty(); i--)
            {
                REQUIRE(pq.top().j == i);
                pq.pop();
            }
        }

        GIVEN("Using external (maybe equal) priorities")
        {
            std::vector<int> priorities = {4,4,4,3,3,2,1,1,1,1};
            const auto& priorities_ref = priorities;
            auto cmp = [&priorities_ref](unsigned int a, unsigned int b) -> bool {
                return priorities_ref[a] == priorities_ref[b]
                       ? a < b
                       : priorities_ref[a] < priorities_ref[b];
            };
            auto priority_updater = [&priorities](unsigned int a, int new_priority) -> void { priorities[a] = new_priority; };
            PriorityQueue<unsigned int, decltype(cmp), int, decltype(priority_updater)> pq(cmp, priority_updater);

            for(unsigned int i = 0; i < 10; i++)
            {
                pq.push(i);
            }

            // every item is in there
            REQUIRE(pq.size() == 10);

            // Only one item gets deleted and inserted again.
            pq.update_key(1, 2);
            REQUIRE(pq.size() == 10);

            // the expected order after updating the priority
            std::vector<unsigned int> expected_result = {6, 7, 8, 9, 1, 5, 3, 4, 0, 2};

            for(unsigned int i = 0; i < 10; i++)
            {
                REQUIRE(pq.top() == expected_result[i]);
                pq.pop();
            }

        };
    }

    WHEN("Sorting by external values")
    {
        std::vector<int> priorities = {1, 5, 3, 2, 4};
        std::vector<unsigned int> expected_result = {0, 3, 2, 4, 1};

        auto cmp = [priorities](unsigned int a, unsigned int b) -> bool {
            return priorities[a] < priorities[b];
        };
        PriorityQueue<int, decltype(cmp)> pq(cmp);
        for(unsigned int i = 0; i < 5; i++)
            pq.push(i);

        for(unsigned int i = 0; !pq.empty(); i++)
        {
            REQUIRE(pq.top() == expected_result[i]);
            pq.pop();
        }
    };

    WHEN("inserting a key that already exists")
    {
        std::vector<int> priorities = {1, 5, 3, 2, 4};
        std::vector<unsigned int> expected_result = {3, 2, 4, 1, 0};

        auto cmp = [priorities](unsigned int a, unsigned int b) -> bool {
            return priorities[a] < priorities[b];
        };

        PriorityQueue<int, decltype(cmp)> pq(cmp);
        for(unsigned int i = 0; i < 5; i++)
            pq.push(i);

        priorities[0] = 6;
        pq.push(0);
        REQUIRE(pq.size() == 5);    // key gets not again
        REQUIRE_FALSE(pq.top() == expected_result[0]);  // ... but gets also not updated
    }

    WHEN("updating a key that is not in the priority queue")
    {
        PriorityQueue<int> pq;

        pq.update_key(1,1);

        REQUIRE(pq.top() == 1);
    }
}

SCENARIO("SSSP Tree Child Arrays")
{
    KSPGraph<gt_undirected> KSPG(G_d01);

    DeltaSteppingDynamic<gt_undirected> ds(KSPG, 1);
    ds.compute(source, destination);

    ds.compute_sssp_child_array();

    // for each child of u, u must be the parent
    for(NODE_ID u = 0; u < KSPG.get_num_nodes(); u++)
    {
        for(auto v = ds.get_sssp_tree().get_children_begin(u); v != ds.get_sssp_tree().get_children_end(u); ++v)
        {
            REQUIRE(ds.get_sssp_tree().at(*v).parent == u);
        }
    }
}

SCENARIO("Dijkstra", "[dijkstra]")
{
    Dijkstra<gt_undirected> d(G_d01);

    d.compute_sssp(source, destination);

    auto path = d.get_shortest_path_to(destination);

    REQUIRE(result[0] == path);  // todo use sssp checker
}

TEST_CASE("Delta Stepping", "[ds]")
{
    auto seed = static_cast<unsigned int>(time(nullptr));
    srand(seed);

    GIVEN("Undirected Graph")
    {
        GIVEN("Dynamic Version")
        {
            GIVEN("One Thread")
            {
                KSPGraph<gt_undirected> g(G_d01);
                DeltaSteppingDynamic<gt_undirected> ds(g, 1);

                NODE_ID source = rand() % G_d01.get_num_nodes();

                ds.compute(source);

                REQUIRE(sssp_check(G_d01, ds.get_sssp_tree(), source));
            }

            GIVEN("Two Threads")
            {
                KSPGraph<gt_undirected> g(G_d01);
                DeltaSteppingDynamic<gt_undirected> ds(g, 2);

                NODE_ID source = rand() % G_d01.get_num_nodes();

                ds.compute(source);

                REQUIRE(sssp_check(G_d01, ds.get_sssp_tree(), source));
            }
        }

        GIVEN("Static Version")
        {
            GIVEN("One Thread")
            {
                KSPGraph<gt_undirected> g(G_d01);
                DeltaSteppingStatic<gt_undirected> ds(g, 1);

                NODE_ID source = rand() % G_d01.get_num_nodes();

                ds.compute(source);

                REQUIRE(sssp_check(G_d01, ds.get_sssp_tree(), source));
            }

            GIVEN("Two Threads")
            {
                KSPGraph<gt_undirected> g(G_d01);
                DeltaSteppingStatic<gt_undirected> ds(g, 2);

                NODE_ID source = rand() % G_d01.get_num_nodes();

                ds.compute(source);

                REQUIRE(sssp_check(G_d01, ds.get_sssp_tree(), source));
            }
        }
    }

    GIVEN("Directed Graph")
    {
        GIVEN("Dynamic Version")
        {
            GIVEN("One Thread")
            {
                KSPGraph<gt_directed> g(G_dd01);
                DeltaSteppingDynamic<gt_directed> ds(g, 1);

                NODE_ID source = rand() % G_dd01.get_num_nodes();

                ds.compute(source);

                REQUIRE(sssp_check(G_dd01, ds.get_sssp_tree(), source));
            }

            GIVEN("Two Threads")
            {
                KSPGraph<gt_directed> g(G_dd01);
                DeltaSteppingDynamic<gt_directed> ds(g, 2);

                NODE_ID source = rand() % G_dd01.get_num_nodes();

                ds.compute(source);

                REQUIRE(sssp_check(G_dd01, ds.get_sssp_tree(), source));
            }
        }

        GIVEN("Static Version")
        {
            GIVEN("One Thread")
            {
                KSPGraph<gt_directed> g(G_dd01);
                DeltaSteppingStatic<gt_directed> ds(g, 1);

                NODE_ID source = rand() % G_dd01.get_num_nodes();

                ds.compute(source);

                REQUIRE(sssp_check(G_dd01, ds.get_sssp_tree(), source));
            }

            GIVEN("Two Threads")
            {
                KSPGraph<gt_directed> g(G_dd01);
                DeltaSteppingStatic<gt_directed> ds(g, 2);

                NODE_ID source = rand() % G_dd01.get_num_nodes();

                ds.compute(source);

                REQUIRE(sssp_check(G_dd01, ds.get_sssp_tree(), source));
            }
        }
    }
}