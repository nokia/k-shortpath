//
// Created by Alex Schickedanz <alex@ae.cs.uni-frankfurt.de> on 05.09.17.
//

#include "catch.hpp"
#include "test_tools.h"

#include "Yen.h"
#include "OptYen.h"
#include "Katoh.h"
#include "Feng.h"

TEST_CASE("Cross check all algorithms on undirected graphs", "[feng][yen][opt_yen][katoh][cross][undirected]")
{
    const gt_undirected G_d01 = GraphRW::read_graph(const_cast<char*>("../resources/big_metis_file.graph"), const_cast<char*>("0.1"),
                                                    GraphRW::file_type::METIS, GraphRW::weight_converting::ORIGINAL);

    const unsigned int k = 10;

    path_list feng_paths1, feng_paths2, feng_paths4;
    path_list yen_paths1, yen_paths2, yen_paths4;
    path_list opt_yen_paths1, opt_yen_paths2, opt_yen_paths4;
    path_list katoh_paths1, katoh_paths2, katoh_paths4;

    NODE_ID source, target;

    const auto seed = static_cast<unsigned int>(time(nullptr));
    srand(seed);

    GIVEN("1 thread")
    {
        srand(seed);
        while(true)
        {
            source = rand() % G_d01.get_num_nodes();    // 6615, 4801
            target = rand() % G_d01.get_num_nodes();    // 2950, 1041

            try
            {
                Feng<DeltaSteppingStatic, gt_undirected, 1, false> feng1(G_d01, k);
                feng_paths1 = feng1.compute(source, target);

                Yen<DeltaSteppingStatic, gt_undirected, 1, false> yen1(G_d01, k);
                yen_paths1 = yen1.compute(source, target);

                OptYen<DeltaSteppingStatic, gt_undirected, 1, false> opt_yen1(G_d01, k);
                opt_yen_paths1 = opt_yen1.compute(source, target);

                Katoh<DeltaSteppingStatic, gt_undirected, 1, false> katoh1(G_d01, k);
                katoh_paths1 = katoh1.compute(source, target);

                break;
            }
            catch(NoPathException& e)
            {
                std::cerr << "no path from s to t -> retry" << std::endl;
                continue;
            }
        }

        SECTION("Yen == Katoh, 1 thread")
        {
            assert_path_lists_are_equal(yen_paths1, katoh_paths1, source, target);
        }

        SECTION("Yen == OptYen, 1 thread")
        {
            assert_path_lists_are_equal(yen_paths1, opt_yen_paths1, source, target);
        }

        SECTION("Yen == Feng, 1 thread")
        {
            assert_path_lists_are_equal(yen_paths1, feng_paths1, source, target);
        }

        SECTION("Katoh == OptYen, 1 thread")
        {
            assert_path_lists_are_equal(katoh_paths1, opt_yen_paths1, source, target);
        }

        SECTION("Katoh == Feng, 1 thread")
        {
            assert_path_lists_are_equal(katoh_paths1, feng_paths1, source, target);
        }

        SECTION("OptYen == Feng, 1 thread")
        {
            assert_path_lists_are_equal(opt_yen_paths1, feng_paths1, source, target);
        }

        SECTION("Paths are sorted by length, 1 thread")
        {
            REQUIRE(feng_paths1.size() == yen_paths1.size());
            REQUIRE(feng_paths1.size() == opt_yen_paths1.size());
            REQUIRE(feng_paths1.size() == katoh_paths1.size());

            for(unsigned int i = 1; i < yen_paths1.size(); i++)
            {
                CAPTURE(source);
                CAPTURE(target);
                CAPTURE(i);
                REQUIRE(yen_paths1[i - 1].length <= yen_paths1[i].length);
                REQUIRE(feng_paths1[i - 1].length <= feng_paths1[i].length);
                REQUIRE(katoh_paths1[i - 1].length <= katoh_paths1[i].length);
                REQUIRE(opt_yen_paths1[i - 1].length <= opt_yen_paths1[i].length);
            }
        }

        SECTION("Paths are simple, 1 thread")
        {
            for(unsigned int i = 0; i < yen_paths1.size(); i++)
            {
                REQUIRE(path_is_simple(yen_paths1[i].p) == "yes");
                REQUIRE(path_is_simple(opt_yen_paths1[i].p) == "yes");
                REQUIRE(path_is_simple(katoh_paths1[i].p) == "yes");
                REQUIRE(path_is_simple(feng_paths1[i].p) == "yes");
            }
        }

        SECTION("Paths are unique, 1 threads")
        {
            REQUIRE(paths_are_unique(yen_paths1) == "yes");
            REQUIRE(paths_are_unique(opt_yen_paths1) == "yes");
            REQUIRE(paths_are_unique(katoh_paths1) == "yes");
            REQUIRE(paths_are_unique(feng_paths1) == "yes");
        }
    }
    GIVEN("2 threads")
    {
        srand(seed);
        while(true)
        {
            source = rand() % G_d01.get_num_nodes();
            target = rand() % G_d01.get_num_nodes();

            try
            {
                Feng<DeltaSteppingStatic, gt_undirected, 2, false> feng2(G_d01, k);
                feng_paths2 = feng2.compute(source, target);

                Yen<DeltaSteppingStatic, gt_undirected, 2, false> yen2(G_d01, k);
                yen_paths2 = yen2.compute(source, target);

                OptYen<DeltaSteppingStatic, gt_undirected, 2, false> opt_yen2(G_d01, k);
                opt_yen_paths2 = opt_yen2.compute(source, target);

                Katoh<DeltaSteppingStatic, gt_undirected, 2, false> katoh2(G_d01, k);
                katoh_paths2 = katoh2.compute(source, target);

                break;
            }
            catch(NoPathException& e)
            {
                std::cerr << "no path from s to t -> retry" << std::endl;
                continue;
            }
        }
        SECTION("Yen == Katoh, 2 threads")
        {
            assert_path_lists_are_equal(yen_paths2, katoh_paths2, source, target);
        }

        SECTION("Yen == OptYen, 2 threads")
        {
            assert_path_lists_are_equal(yen_paths2, opt_yen_paths2, source, target);
        }

        SECTION("Yen == Feng, 2 threads")
        {
            assert_path_lists_are_equal(yen_paths2, feng_paths2, source, target);
        }

        SECTION("Katoh == OptYen, 2 threads")
        {
            assert_path_lists_are_equal(katoh_paths2, opt_yen_paths2, source, target);
        }

        SECTION("Katoh == Feng, 2 threads")
        {
            assert_path_lists_are_equal(katoh_paths2, feng_paths2, source, target);
        }

        SECTION("OptYen == Feng, 2 threads")
        {
            assert_path_lists_are_equal(opt_yen_paths2, feng_paths2, source, target);
        }

        SECTION("Paths are sorted by length, 2 threads")
        {
            REQUIRE(feng_paths2.size() == yen_paths2.size());
            REQUIRE(feng_paths2.size() == opt_yen_paths2.size());
            REQUIRE(feng_paths2.size() == katoh_paths2.size());

            for(unsigned int i = 1; i < yen_paths2.size(); i++)
            {
                CAPTURE(source);
                CAPTURE(target);
                CAPTURE(i);
                REQUIRE(yen_paths2[i - 1].length <= yen_paths2[i].length);
                REQUIRE(feng_paths2[i - 1].length <= feng_paths2[i].length);
                REQUIRE(katoh_paths2[i - 1].length <= katoh_paths2[i].length);
                REQUIRE(opt_yen_paths2[i - 1].length <= opt_yen_paths2[i].length);
            }
        }

        SECTION("Paths are simple, 2 threads")
        {
            for(unsigned int i = 0; i < yen_paths2.size(); i++)
            {
                REQUIRE(path_is_simple(yen_paths2[i].p) == "yes");
                REQUIRE(path_is_simple(opt_yen_paths2[i].p) == "yes");
                REQUIRE(path_is_simple(katoh_paths2[i].p) == "yes");
                REQUIRE(path_is_simple(feng_paths2[i].p) == "yes");
            }
        }

        SECTION("Paths are unique, 2 threads")
        {
            REQUIRE(paths_are_unique(yen_paths2) == "yes");
            REQUIRE(paths_are_unique(opt_yen_paths2) == "yes");
            REQUIRE(paths_are_unique(katoh_paths2) == "yes");
            REQUIRE(paths_are_unique(feng_paths2) == "yes");
        }
    }

    GIVEN("4 threads")
    {
        srand(seed);
        while(true)
        {
            source = rand() % G_d01.get_num_nodes();
            target = rand() % G_d01.get_num_nodes();

            try
            {
                Feng<DeltaSteppingStatic, gt_undirected, 4, true> feng4(G_d01, k);
                feng_paths4 = feng4.compute(source, target);

                Yen<DeltaSteppingStatic, gt_undirected, 4, true> yen4(G_d01, k);
                yen_paths4 = yen4.compute(source, target);

                OptYen<DeltaSteppingStatic, gt_undirected, 4, true> opt_yen4(G_d01, k);
                opt_yen_paths4 = opt_yen4.compute(source, target);

                Katoh<DeltaSteppingStatic, gt_undirected, 4, true> katoh4(G_d01, k);
                katoh_paths4 = katoh4.compute(source, target);

                break;
            }
            catch(NoPathException& e)
            {
                std::cerr << "no path from s to t -> retry" << std::endl;
                continue;
            }
        }
        SECTION("Yen == Katoh, 4 threads")
        {
            assert_path_lists_are_equal(yen_paths4, katoh_paths4, source, target);
        }

        SECTION("Yen == OptYen, 4 threads")
        {
            assert_path_lists_are_equal(yen_paths4, opt_yen_paths4, source, target);
        }

        SECTION("Yen == Feng, 4 threads")
        {
            assert_path_lists_are_equal(yen_paths4, feng_paths4, source, target);
        }

        SECTION("Katoh == OptYen, 4 threads")
        {
            assert_path_lists_are_equal(katoh_paths4, opt_yen_paths4, source, target);
        }

        SECTION("Katoh == Feng, 4 threads")
        {
            assert_path_lists_are_equal(katoh_paths4, feng_paths4, source, target);
        }

        SECTION("OptYen == Feng, 4 threads")
        {
            assert_path_lists_are_equal(opt_yen_paths4, feng_paths4, source, target);
        }

        SECTION("Paths are sorted by length, 4 threads")
        {
            REQUIRE(feng_paths4.size() == yen_paths4.size());
            REQUIRE(feng_paths4.size() == opt_yen_paths4.size());
            REQUIRE(feng_paths4.size() == katoh_paths4.size());

            for(unsigned int i = 1; i < yen_paths4.size(); i++)
            {
                CAPTURE(source);
                CAPTURE(target);
                CAPTURE(i);
                REQUIRE(yen_paths4[i - 1].length <= yen_paths4[i].length);
                REQUIRE(feng_paths4[i - 1].length <= feng_paths4[i].length);
                REQUIRE(katoh_paths4[i - 1].length <= katoh_paths4[i].length);
                REQUIRE(opt_yen_paths4[i - 1].length <= opt_yen_paths4[i].length);
            }
        }

        SECTION("Paths are simple, 4 threads")
        {
            for(unsigned int i = 0; i < yen_paths4.size(); i++)
            {
                REQUIRE(path_is_simple(yen_paths4[i].p) == "yes");
                REQUIRE(path_is_simple(opt_yen_paths4[i].p) == "yes");
                REQUIRE(path_is_simple(katoh_paths4[i].p) == "yes");
                REQUIRE(path_is_simple(feng_paths4[i].p) == "yes");
            }
        }

        SECTION("Paths are unique, 4 threads")
        {
            REQUIRE(paths_are_unique(yen_paths4) == "yes");
            REQUIRE(paths_are_unique(opt_yen_paths4) == "yes");
            REQUIRE(paths_are_unique(katoh_paths4) == "yes");
            REQUIRE(paths_are_unique(feng_paths4) == "yes");
        }
    }
}

TEST_CASE("Cross check all algorithms on directed graphs", "[feng][yen][cross][directed]")
{
    const gt_directed G_dd01 = GraphRW::read_graph<true, true, true>(const_cast<char*>("../resources/directed_test_big.edgelist"), const_cast<char*>("0.1"),
                                                                     GraphRW::file_type::EDGELIST, GraphRW::weight_converting::ORIGINAL);

    const unsigned int k = 10;

    path_list feng_paths1, feng_paths2, feng_paths4;
    path_list yen_paths1, yen_paths2, yen_paths4;
    path_list opt_yen_paths1, opt_yen_paths2, opt_yen_paths4;

    NODE_ID source, target;

    auto seed = static_cast<unsigned int>(time(nullptr));
//    std::cerr << seed << std::endl;

    GIVEN("1 thread")
    {
        srand(seed);

        while(true)
        {
            source = rand() % G_dd01.get_num_nodes();
            target = rand() % G_dd01.get_num_nodes();

            try
            {
                Feng<DeltaSteppingStatic, gt_directed, 1, false> feng(G_dd01, k);
                feng_paths1 = feng.compute(source, target);

                Yen<DeltaSteppingStatic, gt_directed, 1, false> yen(G_dd01, k);
                yen_paths1 = yen.compute(source, target);

                OptYen<DeltaSteppingStatic, gt_directed, 1, false> opt_yen(G_dd01, k);
                opt_yen_paths1 = opt_yen.compute(source, target);
                break;
            }
            catch(NoPathException& e)
            {
                std::cerr << "no path from s to t -> retry" << std::endl;
                continue;
            }
        }

        SECTION("Yen == OptYen")
        {
            assert_path_lists_are_equal(yen_paths1, opt_yen_paths1, source, target);
        }

        SECTION("Yen == Feng")
        {
            assert_path_lists_are_equal(yen_paths1, feng_paths1, source, target);
        }

        SECTION("OptYen == Feng")
        {
            assert_path_lists_are_equal(opt_yen_paths1, feng_paths1, source, target);
        }

        SECTION("Paths are sorted by length, 1 thread")
        {
            REQUIRE(feng_paths1.size() == yen_paths1.size());
            REQUIRE(opt_yen_paths1.size() == yen_paths1.size());
            for(unsigned int i = 1; i < feng_paths1.size(); i++)
            {
                CAPTURE(source);
                CAPTURE(target);
                CAPTURE(i);
                REQUIRE(yen_paths1[i - 1].length <= yen_paths1[i].length);
                REQUIRE(opt_yen_paths1[i - 1].length <= opt_yen_paths1[i].length);
                REQUIRE(feng_paths1[i - 1].length <= feng_paths1[i].length);
            }
        }

        SECTION("Paths are simple, 1 threads")
        {
            for(unsigned int i = 0; i < yen_paths4.size(); i++)
            {
                REQUIRE(path_is_simple(yen_paths1[i].p) == "yes");
                REQUIRE(path_is_simple(opt_yen_paths1[i].p) == "yes");
                REQUIRE(path_is_simple(feng_paths1[i].p) == "yes");
            }
        }

        SECTION("Paths are unique, 1 threads")
        {
            REQUIRE(paths_are_unique(yen_paths1) == "yes");
            REQUIRE(paths_are_unique(opt_yen_paths1) == "yes");
            REQUIRE(paths_are_unique(feng_paths1) == "yes");
        }
    }

    GIVEN("2 threads")
    {
        srand(seed);

        while(true)
        {
            source = rand() % G_dd01.get_num_nodes();
            target = rand() % G_dd01.get_num_nodes();

            try
            {
                Feng<DeltaSteppingStatic, gt_directed, 2, false> feng(G_dd01, k);
                feng_paths2 = feng.compute(source, target);

                Yen<DeltaSteppingStatic, gt_directed, 2, false> yen(G_dd01, k);
                yen_paths2 = yen.compute(source, target);

                OptYen<DeltaSteppingStatic, gt_directed, 2, false> opt_yen(G_dd01, k);
                opt_yen_paths2 = opt_yen.compute(source, target);
                break;
            }
            catch(NoPathException& e)
            {
                std::cerr << "no path from s to t -> retry" << std::endl;
                continue;
            }
        }

        SECTION("Yen == OptYen")
        {
            assert_path_lists_are_equal(yen_paths2, opt_yen_paths2, source, target);
        }

        SECTION("Yen == Feng")
        {
            assert_path_lists_are_equal(yen_paths2, feng_paths2, source, target);
        }

        SECTION("OptYen == Feng")
        {
            assert_path_lists_are_equal(opt_yen_paths2, feng_paths2, source, target);
        }

        SECTION("Paths are sorted by length, 2 threads")
        {
            REQUIRE(feng_paths2.size() == yen_paths2.size());
            REQUIRE(opt_yen_paths2.size() == yen_paths2.size());
            for(unsigned int i = 1; i < feng_paths2.size(); i++)
            {
                CAPTURE(source);
                CAPTURE(target);
                CAPTURE(i);
                REQUIRE(yen_paths2[i - 1].length <= yen_paths2[i].length);
                REQUIRE(opt_yen_paths2[i - 1].length <= opt_yen_paths2[i].length);
                REQUIRE(feng_paths2[i - 1].length <= feng_paths2[i].length);
            }
        }

        SECTION("Paths are simple, 2 threads")
        {
            for(unsigned int i = 0; i < yen_paths4.size(); i++)
            {
                REQUIRE(path_is_simple(yen_paths2[i].p) == "yes");
                REQUIRE(path_is_simple(opt_yen_paths2[i].p) == "yes");
                REQUIRE(path_is_simple(feng_paths2[i].p) == "yes");
            }
        }

        SECTION("Paths are unique, 2 threads")
        {
            REQUIRE(paths_are_unique(yen_paths2) == "yes");
            REQUIRE(paths_are_unique(opt_yen_paths2) == "yes");
            REQUIRE(paths_are_unique(feng_paths2) == "yes");
        }
    }

    GIVEN("4 threads")
    {
        srand(seed);

        while(true)
        {
            source = rand() % G_dd01.get_num_nodes();
            target = rand() % G_dd01.get_num_nodes();

            try
            {
                Feng<DeltaSteppingStatic, gt_directed, 4, true> feng(G_dd01, k);
                feng_paths4 = feng.compute(source, target);

                Yen<DeltaSteppingStatic, gt_directed, 4, true> yen(G_dd01, k);
                yen_paths4 = yen.compute(source, target);

                OptYen<DeltaSteppingStatic, gt_directed, 4, true> opt_yen(G_dd01, k);
                opt_yen_paths4 = opt_yen.compute(source, target);
                break;
            }
            catch(NoPathException& e)
            {
                std::cerr << "no path from s to t -> retry" << std::endl;
                continue;
            }
        }

        SECTION("Yen == OptYen")
        {
            assert_path_lists_are_equal(yen_paths4, opt_yen_paths4, source, target);
        }

        SECTION("Yen == Feng")
        {
            assert_path_lists_are_equal(yen_paths4, feng_paths4, source, target);
        }

        SECTION("OptYen == Feng")
        {
            assert_path_lists_are_equal(opt_yen_paths4, feng_paths4, source, target);
        }

        SECTION("Paths are sorted by , 4 threads")
        {
            REQUIRE(feng_paths4.size() == yen_paths4.size());
            REQUIRE(opt_yen_paths4.size() == yen_paths4.size());
            for(unsigned int i = 1; i < feng_paths4.size(); i++)
            {
                CAPTURE(source);
                CAPTURE(target);
                CAPTURE(i);
                REQUIRE(yen_paths4[i - 1].length <= yen_paths4[i].length);
                REQUIRE(opt_yen_paths4[i - 1].length <= opt_yen_paths4[i].length);
                REQUIRE(feng_paths4[i - 1].length <= feng_paths4[i].length);
            }
        }

        SECTION("Paths are simple, 1 threads")
        {
            for(unsigned int i = 0; i < yen_paths4.size(); i++)
            {
                REQUIRE(path_is_simple(yen_paths4[i].p) == "yes");
                REQUIRE(path_is_simple(opt_yen_paths4[i].p) == "yes");
                REQUIRE(path_is_simple(feng_paths4[i].p) == "yes");
            }
        }

        SECTION("Paths are unique, 1 threads")
        {
            REQUIRE(paths_are_unique(yen_paths4) == "yes");
            REQUIRE(paths_are_unique(opt_yen_paths4) == "yes");
            REQUIRE(paths_are_unique(feng_paths4) == "yes");
        }
    }
}

TEST_CASE("Cross check all algorithms on undirected unweighted graphs", "[feng][yen][opt_yen][katoh][cross][undirected]")
{
    using gt_undirected = BasicGraph<false, false>;

    const gt_undirected G_d01 = GraphRW::read_graph<false, false>(const_cast<char*>("../resources/big_metis_file.graph"), const_cast<char*>("0.1"),
                                                    GraphRW::file_type::METIS, GraphRW::weight_converting::ORIGINAL);

    const unsigned int k = 10;

    path_list feng_paths1, feng_paths2, feng_paths4;
    path_list yen_paths1, yen_paths2, yen_paths4;
    path_list opt_yen_paths1, opt_yen_paths2, opt_yen_paths4;
    path_list katoh_paths1, katoh_paths2, katoh_paths4;

    NODE_ID source, target;

    const auto seed = static_cast<unsigned int>(time(nullptr));
    srand(seed);

    GIVEN("1 thread")
    {
        srand(seed);
        while(true)
        {
            source = rand() % G_d01.get_num_nodes();
            target = rand() % G_d01.get_num_nodes();

            try
            {
                Feng<DeltaSteppingStatic, gt_undirected, 1, false> feng1(G_d01, k);
                feng_paths1 = feng1.compute(source, target);

                Yen<DeltaSteppingStatic, gt_undirected, 1, false> yen1(G_d01, k);
                yen_paths1 = yen1.compute(source, target);

                OptYen<DeltaSteppingStatic, gt_undirected, 1, false> opt_yen1(G_d01, k);
                opt_yen_paths1 = opt_yen1.compute(source, target);

                Katoh<DeltaSteppingStatic, gt_undirected, 1, false> katoh1(G_d01, k);
                katoh_paths1 = katoh1.compute(source, target);

                break;
            }
            catch(NoPathException& e)
            {
                std::cerr << "no path from s to t -> retry" << std::endl;
                continue;
            }
        }

        SECTION("Yen == Katoh, 1 thread")
        {
            assert_path_lists_are_equal(yen_paths1, katoh_paths1, source, target);
        }

        SECTION("Yen == OptYen, 1 thread")
        {
            assert_path_lists_are_equal(yen_paths1, opt_yen_paths1, source, target);
        }

        SECTION("Yen == Feng, 1 thread")
        {
            assert_path_lists_are_equal(yen_paths1, feng_paths1, source, target);
        }

        SECTION("Katoh == OptYen, 1 thread")
        {
            assert_path_lists_are_equal(katoh_paths1, opt_yen_paths1, source, target);
        }

        SECTION("Katoh == Feng, 1 thread")
        {
            assert_path_lists_are_equal(katoh_paths1, feng_paths1, source, target);
        }

        SECTION("OptYen == Feng, 1 thread")
        {
            assert_path_lists_are_equal(opt_yen_paths1, feng_paths1, source, target);
        }

        SECTION("Paths are sorted by length, 1 thread")
        {
            REQUIRE(feng_paths1.size() == yen_paths1.size());
            REQUIRE(feng_paths1.size() == opt_yen_paths1.size());
            REQUIRE(feng_paths1.size() == katoh_paths1.size());

            for(unsigned int i = 1; i < yen_paths1.size(); i++)
            {
                CAPTURE(source);
                CAPTURE(target);
                CAPTURE(i);
                REQUIRE(yen_paths1[i - 1].length <= yen_paths1[i].length);
                REQUIRE(feng_paths1[i - 1].length <= feng_paths1[i].length);
                REQUIRE(katoh_paths1[i - 1].length <= katoh_paths1[i].length);
                REQUIRE(opt_yen_paths1[i - 1].length <= opt_yen_paths1[i].length);
            }
        }

        SECTION("Paths are simple, 1 thread")
        {
            for(unsigned int i = 0; i < yen_paths1.size(); i++)
            {
                REQUIRE(path_is_simple(yen_paths1[i].p) == "yes");
                REQUIRE(path_is_simple(opt_yen_paths1[i].p) == "yes");
                REQUIRE(path_is_simple(katoh_paths1[i].p) == "yes");
                REQUIRE(path_is_simple(feng_paths1[i].p) == "yes");
            }
        }

        SECTION("Paths are unique, 1 threads")
        {
            REQUIRE(paths_are_unique(yen_paths1) == "yes");
            REQUIRE(paths_are_unique(opt_yen_paths1) == "yes");
            REQUIRE(paths_are_unique(katoh_paths1) == "yes");
            REQUIRE(paths_are_unique(feng_paths1) == "yes");
        }
    }
    GIVEN("2 threads")
    {
        srand(seed);
        while(true)
        {
            source = rand() % G_d01.get_num_nodes();
            target = rand() % G_d01.get_num_nodes();

            try
            {
                Feng<DeltaSteppingStatic, gt_undirected, 2, false> feng2(G_d01, k);
                feng_paths2 = feng2.compute(source, target);

                Yen<DeltaSteppingStatic, gt_undirected, 2, false> yen2(G_d01, k);
                yen_paths2 = yen2.compute(source, target);

                OptYen<DeltaSteppingStatic, gt_undirected, 2, false> opt_yen2(G_d01, k);
                opt_yen_paths2 = opt_yen2.compute(source, target);

                Katoh<DeltaSteppingStatic, gt_undirected, 2, false> katoh2(G_d01, k);
                katoh_paths2 = katoh2.compute(source, target);

                break;
            }
            catch(NoPathException& e)
            {
                std::cerr << "no path from s to t -> retry" << std::endl;
                continue;
            }
        }
        SECTION("Yen == Katoh, 2 threads")
        {
            assert_path_lists_are_equal(yen_paths2, katoh_paths2, source, target);
        }

        SECTION("Yen == OptYen, 2 threads")
        {
            assert_path_lists_are_equal(yen_paths2, opt_yen_paths2, source, target);
        }

        SECTION("Yen == Feng, 2 threads")
        {
            assert_path_lists_are_equal(yen_paths2, feng_paths2, source, target);
        }

        SECTION("Katoh == OptYen, 2 threads")
        {
            assert_path_lists_are_equal(katoh_paths2, opt_yen_paths2, source, target);
        }

        SECTION("Katoh == Feng, 2 threads")
        {
            assert_path_lists_are_equal(katoh_paths2, feng_paths2, source, target);
        }

        SECTION("OptYen == Feng, 2 threads")
        {
            assert_path_lists_are_equal(opt_yen_paths2, feng_paths2, source, target);
        }

        SECTION("Paths are sorted by length, 2 threads")
        {
            REQUIRE(feng_paths2.size() == yen_paths2.size());
            REQUIRE(feng_paths2.size() == opt_yen_paths2.size());
            REQUIRE(feng_paths2.size() == katoh_paths2.size());

            for(unsigned int i = 1; i < yen_paths2.size(); i++)
            {
                CAPTURE(source);
                CAPTURE(target);
                CAPTURE(i);
                REQUIRE(yen_paths2[i - 1].length <= yen_paths2[i].length);
                REQUIRE(feng_paths2[i - 1].length <= feng_paths2[i].length);
                REQUIRE(katoh_paths2[i - 1].length <= katoh_paths2[i].length);
                REQUIRE(opt_yen_paths2[i - 1].length <= opt_yen_paths2[i].length);
            }
        }

        SECTION("Paths are simple, 2 threads")
        {
            for(unsigned int i = 0; i < yen_paths2.size(); i++)
            {
                REQUIRE(path_is_simple(yen_paths2[i].p) == "yes");
                REQUIRE(path_is_simple(opt_yen_paths2[i].p) == "yes");
                REQUIRE(path_is_simple(katoh_paths2[i].p) == "yes");
                REQUIRE(path_is_simple(feng_paths2[i].p) == "yes");
            }
        }
        SECTION("Paths are unique, 2 threads")
        {
            REQUIRE(paths_are_unique(yen_paths2) == "yes");
            REQUIRE(paths_are_unique(opt_yen_paths2) == "yes");
            REQUIRE(paths_are_unique(katoh_paths2) == "yes");
            REQUIRE(paths_are_unique(feng_paths2) == "yes");
        }
    }

    GIVEN("4 threads")
    {
        srand(seed);
        while(true)
        {
            source = rand() % G_d01.get_num_nodes();
            target = rand() % G_d01.get_num_nodes();

            try
            {
                Feng<DeltaSteppingStatic, gt_undirected, 4, true> feng4(G_d01, k);
                feng_paths4 = feng4.compute(source, target);

                Yen<DeltaSteppingStatic, gt_undirected, 4, true> yen4(G_d01, k);
                yen_paths4 = yen4.compute(source, target);

                OptYen<DeltaSteppingStatic, gt_undirected, 4, true> opt_yen4(G_d01, k);
                opt_yen_paths4 = opt_yen4.compute(source, target);

                Katoh<DeltaSteppingStatic, gt_undirected, 4, true> katoh4(G_d01, k);
                katoh_paths4 = katoh4.compute(source, target);

                break;
            }
            catch(NoPathException& e)
            {
                std::cerr << "no path from s to t -> retry" << std::endl;
                continue;
            }
        }
        SECTION("Yen == Katoh, 4 threads")
        {
            assert_path_lists_are_equal(yen_paths4, katoh_paths4, source, target);
        }

        SECTION("Yen == OptYen, 4 threads")
        {
            assert_path_lists_are_equal(yen_paths4, opt_yen_paths4, source, target);
        }

        SECTION("Yen == Feng, 4 threads")
        {
            assert_path_lists_are_equal(yen_paths4, feng_paths4, source, target);
        }

        SECTION("Katoh == OptYen, 4 threads")
        {
            assert_path_lists_are_equal(katoh_paths4, opt_yen_paths4, source, target);
        }

        SECTION("Katoh == Feng, 4 threads")
        {
            assert_path_lists_are_equal(katoh_paths4, feng_paths4, source, target);
        }

        SECTION("OptYen == Feng, 4 threads")
        {
            assert_path_lists_are_equal(opt_yen_paths4, feng_paths4, source, target);
        }

        SECTION("Paths are sorted by length, 4 threads")
        {
            REQUIRE(feng_paths4.size() == yen_paths4.size());
            REQUIRE(feng_paths4.size() == opt_yen_paths4.size());
            REQUIRE(feng_paths4.size() == katoh_paths4.size());

            for(unsigned int i = 1; i < yen_paths4.size(); i++)
            {
                CAPTURE(source);
                CAPTURE(target);
                CAPTURE(i);
                REQUIRE(yen_paths4[i - 1].length <= yen_paths4[i].length);
                REQUIRE(feng_paths4[i - 1].length <= feng_paths4[i].length);
                REQUIRE(katoh_paths4[i - 1].length <= katoh_paths4[i].length);
                REQUIRE(opt_yen_paths4[i - 1].length <= opt_yen_paths4[i].length);
            }
        }

        SECTION("Paths are simple, 4 threads")
        {
            for(unsigned int i = 0; i < yen_paths4.size(); i++)
            {
                REQUIRE(path_is_simple(yen_paths4[i].p) == "yes");
                REQUIRE(path_is_simple(opt_yen_paths4[i].p) == "yes");
                REQUIRE(path_is_simple(katoh_paths4[i].p) == "yes");
                REQUIRE(path_is_simple(feng_paths4[i].p) == "yes");
            }
        }

        SECTION("Paths are unique, 4 threads")
        {
            REQUIRE(paths_are_unique(yen_paths4) == "yes");
            REQUIRE(paths_are_unique(opt_yen_paths4) == "yes");
            REQUIRE(paths_are_unique(katoh_paths4) == "yes");
            REQUIRE(paths_are_unique(feng_paths4) == "yes");
        }
    }
}

TEST_CASE("Cross check all algorithms on directed unweighted graphs", "[feng][yen][cross][directed]")
{
    using gt_directed = BasicGraph<true, false>;

    const gt_directed G_dd01 = GraphRW::read_graph<true, false, true>(const_cast<char*>("../resources/directed_test_big.edgelist"), const_cast<char*>("0.1"),
                                                                     GraphRW::file_type::EDGELIST, GraphRW::weight_converting::ORIGINAL);

    const unsigned int k = 10;

    path_list feng_paths1, feng_paths2, feng_paths4;
    path_list yen_paths1, yen_paths2, yen_paths4;
    path_list opt_yen_paths1, opt_yen_paths2, opt_yen_paths4;

    NODE_ID source, target;

    auto seed = static_cast<unsigned int>(time(nullptr));
//    std::cerr << seed << std::endl;

    GIVEN("1 thread")
    {
        srand(seed);

        while(true)
        {
            source = rand() % G_dd01.get_num_nodes();
            target = rand() % G_dd01.get_num_nodes();

            try
            {
                Feng<DeltaSteppingStatic, gt_directed, 1, false> feng(G_dd01, k);
                feng_paths1 = feng.compute(source, target);

                Yen<DeltaSteppingStatic, gt_directed, 1, false> yen(G_dd01, k);
                yen_paths1 = yen.compute(source, target);

                OptYen<DeltaSteppingStatic, gt_directed, 1, false> opt_yen(G_dd01, k);
                opt_yen_paths1 = opt_yen.compute(source, target);
                break;
            }
            catch(NoPathException& e)
            {
                std::cerr << "no path from s to t -> retry" << std::endl;
                continue;
            }
        }

        SECTION("Yen == OptYen")
        {
            assert_path_lists_are_equal(yen_paths1, opt_yen_paths1, source, target);
        }

        SECTION("Yen == Feng")
        {
            assert_path_lists_are_equal(yen_paths1, feng_paths1, source, target);
        }

        SECTION("OptYen == Feng")
        {
            assert_path_lists_are_equal(opt_yen_paths1, feng_paths1, source, target);
        }

        SECTION("Paths are sorted by length, 1 thread")
        {
            REQUIRE(feng_paths1.size() == yen_paths1.size());
            REQUIRE(opt_yen_paths1.size() == yen_paths1.size());
            for(unsigned int i = 1; i < feng_paths1.size(); i++)
            {
                CAPTURE(source);
                CAPTURE(target);
                CAPTURE(i);
                REQUIRE(yen_paths1[i - 1].length <= yen_paths1[i].length);
                REQUIRE(opt_yen_paths1[i - 1].length <= opt_yen_paths1[i].length);
                REQUIRE(feng_paths1[i - 1].length <= feng_paths1[i].length);
            }
        }

        SECTION("Paths are simple, 1 threads")
        {
            for(unsigned int i = 0; i < yen_paths4.size(); i++)
            {
                REQUIRE(path_is_simple(yen_paths1[i].p) == "yes");
                REQUIRE(path_is_simple(opt_yen_paths1[i].p) == "yes");
                REQUIRE(path_is_simple(feng_paths1[i].p) == "yes");
            }
        }

        SECTION("Paths are unique, 1 threads")
        {
            REQUIRE(paths_are_unique(yen_paths1) == "yes");
            REQUIRE(paths_are_unique(opt_yen_paths1) == "yes");
            REQUIRE(paths_are_unique(feng_paths1) == "yes");
        }
    }

    GIVEN("2 threads")
    {
        srand(seed);

        while(true)
        {
            source = rand() % G_dd01.get_num_nodes();
            target = rand() % G_dd01.get_num_nodes();

            try
            {
                Feng<DeltaSteppingStatic, gt_directed, 2, false> feng(G_dd01, k);
                feng_paths2 = feng.compute(source, target);

                Yen<DeltaSteppingStatic, gt_directed, 2, false> yen(G_dd01, k);
                yen_paths2 = yen.compute(source, target);

                OptYen<DeltaSteppingStatic, gt_directed, 2, false> opt_yen(G_dd01, k);
                opt_yen_paths2 = opt_yen.compute(source, target);
                break;
            }
            catch(NoPathException& e)
            {
                std::cerr << "no path from s to t -> retry" << std::endl;
                continue;
            }
        }

        SECTION("Yen == OptYen")
        {
            assert_path_lists_are_equal(yen_paths2, opt_yen_paths2, source, target);
        }

        SECTION("Yen == Feng")
        {
            assert_path_lists_are_equal(yen_paths2, feng_paths2, source, target);
        }

        SECTION("OptYen == Feng")
        {
            assert_path_lists_are_equal(opt_yen_paths2, feng_paths2, source, target);
        }

        SECTION("Paths are sorted by length, 2 threads")
        {
            REQUIRE(feng_paths2.size() == yen_paths2.size());
            REQUIRE(opt_yen_paths2.size() == yen_paths2.size());
            for(unsigned int i = 1; i < feng_paths2.size(); i++)
            {
                CAPTURE(source);
                CAPTURE(target);
                CAPTURE(i);
                REQUIRE(yen_paths2[i - 1].length <= yen_paths2[i].length);
                REQUIRE(opt_yen_paths2[i - 1].length <= opt_yen_paths2[i].length);
                REQUIRE(feng_paths2[i - 1].length <= feng_paths2[i].length);
            }
        }

        SECTION("Paths are simple, 2 threads")
        {
            for(unsigned int i = 0; i < yen_paths4.size(); i++)
            {
                REQUIRE(path_is_simple(yen_paths2[i].p) == "yes");
                REQUIRE(path_is_simple(opt_yen_paths2[i].p) == "yes");
                REQUIRE(path_is_simple(feng_paths2[i].p) == "yes");
            }
        }

        SECTION("Paths are unique, 2 threads")
        {
            REQUIRE(paths_are_unique(yen_paths2) == "yes");
            REQUIRE(paths_are_unique(opt_yen_paths2) == "yes");
            REQUIRE(paths_are_unique(feng_paths2) == "yes");
        }
    }

    GIVEN("4 threads")
    {
        srand(seed);

        while(true)
        {
            source = rand() % G_dd01.get_num_nodes();
            target = rand() % G_dd01.get_num_nodes();

            try
            {
                Feng<DeltaSteppingStatic, gt_directed, 4, true> feng(G_dd01, k);
                feng_paths4 = feng.compute(source, target);

                Yen<DeltaSteppingStatic, gt_directed, 4, true> yen(G_dd01, k);
                yen_paths4 = yen.compute(source, target);

                OptYen<DeltaSteppingStatic, gt_directed, 4, true> opt_yen(G_dd01, k);
                opt_yen_paths4 = opt_yen.compute(source, target);
                break;
            }
            catch(NoPathException& e)
            {
                std::cerr << "no path from s to t -> retry" << std::endl;
                continue;
            }
        }

        SECTION("Yen == OptYen")
        {
            assert_path_lists_are_equal(yen_paths4, opt_yen_paths4, source, target);
        }

        SECTION("Yen == Feng")
        {
            assert_path_lists_are_equal(yen_paths4, feng_paths4, source, target);
        }

        SECTION("OptYen == Feng")
        {
            assert_path_lists_are_equal(opt_yen_paths4, feng_paths4, source, target);
        }

        SECTION("Paths are sorted by length, 4 threads")
        {
            REQUIRE(feng_paths4.size() == yen_paths4.size());
            REQUIRE(opt_yen_paths4.size() == yen_paths4.size());
            for(unsigned int i = 1; i < feng_paths4.size(); i++)
            {
                CAPTURE(source);
                CAPTURE(target);
                CAPTURE(i);
                REQUIRE(yen_paths4[i - 1].length <= yen_paths4[i].length);
                REQUIRE(opt_yen_paths4[i - 1].length <= opt_yen_paths4[i].length);
                REQUIRE(feng_paths4[i - 1].length <= feng_paths4[i].length);
            }
        }

        SECTION("Paths are simple, 4 threads")
        {
            for(unsigned int i = 0; i < yen_paths4.size(); i++)
            {
                REQUIRE(path_is_simple(yen_paths4[i].p) == "yes");
                REQUIRE(path_is_simple(opt_yen_paths4[i].p) == "yes");
                REQUIRE(path_is_simple(feng_paths4[i].p) == "yes");
            }
        }

        SECTION("Paths are unique, 4 threads")
        {
            REQUIRE(paths_are_unique(yen_paths4) == "yes");
            REQUIRE(paths_are_unique(opt_yen_paths4) == "yes");
            REQUIRE(paths_are_unique(feng_paths4) == "yes");
        }
    }
}
