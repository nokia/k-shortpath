//
// Created by Alex Schickedanz <alex@ae.cs.uni-frankfurt.de> on 05.09.17.
//

#include "catch.hpp"
#include "test_tools.h"

#include "GraphRW.h"
#include "Katoh.h"
#include "Yen.h"
#include "OptYen.h"
#include "Feng.h"

using path_list = std::vector<Path>;
using gt_undirected = BasicGraph<false, true>;

const gt_undirected G_d1  = GraphRW::read_graph(const_cast<char*>("../resources/big_metis_file.graph"), const_cast<char*>("1"),
                                                GraphRW::file_type::METIS, GraphRW::weight_converting::ORIGINAL);
const gt_undirected G_d01 = GraphRW::read_graph(const_cast<char*>("../resources/big_metis_file.graph"), const_cast<char*>("0.1"),
                                                GraphRW::file_type::METIS, GraphRW::weight_converting::ORIGINAL);

SCENARIO("Katoh", "[katoh][undirected]")
{
    WHEN("Executed in 1 thread")
    {
        AND_WHEN("delta = 0.1")
        {
            AND_WHEN("Sssp_alg = dynamic")
            {
                testKSP<Katoh, DeltaSteppingDynamic, gt_undirected, 1, false>(G_d01);
            }

            AND_WHEN("Sssp_alg = static")
            {
                testKSP<Katoh, DeltaSteppingStatic, gt_undirected, 1, false>(G_d01);
            }
        }

        AND_WHEN("delta = 1")
        {
            AND_WHEN("Sssp_alg = dynamic")
            {
                testKSP<Katoh, DeltaSteppingDynamic, gt_undirected, 1, false>(G_d1);
            }

            AND_WHEN("Sssp_alg = static")
            {
                testKSP<Katoh, DeltaSteppingStatic, gt_undirected, 1, false>(G_d1);
            }
        }
    }

    WHEN("Executed in 4 threads")
    {
        AND_WHEN("parallel_ps = false")
        {
            AND_WHEN("delta = 0.1")
            {
                AND_WHEN("Sssp_alg = dynamic")
                {
                    testKSP<Katoh, DeltaSteppingDynamic, gt_undirected, 4, false>(G_d01);
                }

                AND_WHEN("Sssp_alg = static")
                {
                    testKSP<Katoh, DeltaSteppingStatic, gt_undirected, 4, false>(G_d01);
                }
            }

            AND_WHEN("delta = 1")
            {
                AND_WHEN("Sssp_alg = dynamic")
                {
                    testKSP<Katoh, DeltaSteppingDynamic, gt_undirected, 4, false>(G_d1);
                }

                AND_WHEN("Sssp_alg = static")
                {
                    testKSP<Katoh, DeltaSteppingStatic, gt_undirected, 4, false>(G_d1);
                }
            }
        }

        AND_WHEN("parallel_ps = true")
        {
            AND_WHEN("delta = 0.1")
            {
                AND_WHEN("Sssp_alg = dynamic")
                {
                    testKSP<Katoh, DeltaSteppingDynamic, gt_undirected, 4, true>(G_d01);
                }

                AND_WHEN("Sssp_alg = static")
                {
                    testKSP<Katoh, DeltaSteppingStatic, gt_undirected, 4, true>(G_d01);
                }
            }

            AND_WHEN("delta = 1")
            {
                AND_WHEN("Sssp_alg = dynamic")
                {
                    testKSP<Katoh, DeltaSteppingDynamic, gt_undirected, 4, true>(G_d1);
                }

                AND_WHEN("Sssp_alg = static")
                {
                    testKSP<Katoh, DeltaSteppingStatic, gt_undirected, 4, true>(G_d1);
                }
            }
        }
    }
}

SCENARIO("Feng", "[feng][undirected]")
{
    std::cerr << "Feng is currently not optimized for sequential use." << std::endl;

    WHEN("Executed in 1 thread")
    {
        AND_WHEN("delta = 0.1")
        {
            AND_WHEN("Sssp_alg = dynamic")
            {
                testKSP<Feng, DeltaSteppingDynamic, gt_undirected, 1, false>(G_d01);
            }

            AND_WHEN("Sssp_alg = static")
            {
                testKSP<Feng, DeltaSteppingStatic, gt_undirected, 1, false>(G_d01);
            }
        }

        AND_WHEN("delta = 1")
        {
            AND_WHEN("Sssp_alg = dynamic")
            {
                testKSP<Feng, DeltaSteppingDynamic, gt_undirected, 1, false>(G_d1);
            }

            AND_WHEN("Sssp_alg = static")
            {
                testKSP<Feng, DeltaSteppingStatic, gt_undirected, 1, false>(G_d1);
            }
        }
    }

    WHEN("Executed in 4 threads")
    {
        AND_WHEN("parallel_ps = false")
        {
            AND_WHEN("delta = 0.1")
            {
                AND_WHEN("Sssp_alg = dynamic")
                {
                    testKSP<Feng, DeltaSteppingDynamic, gt_undirected, 4, false>(G_d01);
                }

                AND_WHEN("Sssp_alg = static")
                {
                    testKSP<Feng, DeltaSteppingStatic, gt_undirected, 4, false>(G_d01);
                }
            }

            AND_WHEN("delta = 1")
            {
                AND_WHEN("Sssp_alg = dynamic")
                {
                    testKSP<Feng, DeltaSteppingDynamic, gt_undirected, 4, false>(G_d1);
                }

                AND_WHEN("Sssp_alg = static")
                {
                    testKSP<Feng, DeltaSteppingStatic, gt_undirected, 4, false>(G_d1);
                }
            }
        }

        AND_WHEN("parallel_ps = true")
        {
            AND_WHEN("delta = 0.1")
            {
                AND_WHEN("Sssp_alg = dynamic")
                {
                    testKSP<Feng, DeltaSteppingDynamic, gt_undirected, 4, true>(G_d01);
                }

                AND_WHEN("Sssp_alg = static")
                {
                    testKSP<Feng, DeltaSteppingStatic, gt_undirected, 4, true>(G_d01);
                }
            }

            AND_WHEN("delta = 1")
            {
                AND_WHEN("Sssp_alg = dynamic")
                {
                    testKSP<Feng, DeltaSteppingDynamic, gt_undirected, 4, true>(G_d1);
                }

                AND_WHEN("Sssp_alg = static")
                {
                    testKSP<Feng, DeltaSteppingStatic, gt_undirected, 4, true>(G_d1);
                }
            }
        }
    }
}

SCENARIO("Yen", "[yen][undirected]")
{
    WHEN("Executed in 1 thread")
    {
        AND_WHEN("delta = 0.1")
        {
            AND_WHEN("Sssp_alg = dynamic")
            {
                testKSP<Yen, DeltaSteppingDynamic, gt_undirected, 1, false>(G_d01);
            }

            AND_WHEN("Sssp_alg = static")
            {
                testKSP<Yen, DeltaSteppingStatic, gt_undirected, 1, false>(G_d01);
            }
        }

        AND_WHEN("delta = 1")
        {
            AND_WHEN("Sssp_alg = dynamic")
            {
                testKSP<Yen, DeltaSteppingDynamic, gt_undirected, 1, false>(G_d1);
            }

            AND_WHEN("Sssp_alg = static")
            {
                testKSP<Yen, DeltaSteppingStatic, gt_undirected, 1, false>(G_d1);
            }
        }
    }

    WHEN("Executed in 4 threads")
    {
        AND_WHEN("parallel_ps = false")
        {
            AND_WHEN("delta = 0.1")
            {
                AND_WHEN("Sssp_alg = dynamic")
                {
                    testKSP<Yen, DeltaSteppingDynamic, gt_undirected, 4, false>(G_d01);
                }

                AND_WHEN("Sssp_alg = static")
                {
                    testKSP<Yen, DeltaSteppingStatic, gt_undirected, 4, false>(G_d01);
                }
            }

            AND_WHEN("delta = 1")
            {
                AND_WHEN("Sssp_alg = dynamic")
                {
                    testKSP<Yen, DeltaSteppingDynamic, gt_undirected, 4, false>(G_d1);
                }

                AND_WHEN("Sssp_alg = static")
                {
                    testKSP<Yen, DeltaSteppingStatic, gt_undirected, 4, false>(G_d1);
                }
            }
        }

        AND_WHEN("parallel_ps = true")
        {
            AND_WHEN("delta = 0.1")
            {
                AND_WHEN("Sssp_alg = dynamic")
                {
                    testKSP<Yen, DeltaSteppingDynamic, gt_undirected, 4, true>(G_d01);
                }

                AND_WHEN("Sssp_alg = static")
                {
                    testKSP<Yen, DeltaSteppingStatic, gt_undirected, 4, true>(G_d01);
                }
            }

            AND_WHEN("delta = 1")
            {
                AND_WHEN("Sssp_alg = dynamic")
                {
                    testKSP<Yen, DeltaSteppingDynamic, gt_undirected, 4, true>(G_d1);
                }

                AND_WHEN("Sssp_alg = static")
                {
                    testKSP<Yen, DeltaSteppingStatic, gt_undirected, 4, true>(G_d1);
                }
            }
        }
    }
}

SCENARIO("OptYen", "[opt_yen][undirected]")
{
    WHEN("Executed in 1 thread")
    {
        AND_WHEN("delta = 0.1")
        {
            AND_WHEN("Sssp_alg = dynamic")
            {
                testKSP<OptYen, DeltaSteppingDynamic, gt_undirected, 1, false>(G_d01);
            }

            AND_WHEN("Sssp_alg = static")
            {
                testKSP<OptYen, DeltaSteppingStatic, gt_undirected, 1, false>(G_d01);
            }
        }

        AND_WHEN("delta = 1")
        {
            AND_WHEN("Sssp_alg = dynamic")
            {
                testKSP<OptYen, DeltaSteppingDynamic, gt_undirected, 1, false>(G_d1);
            }

            AND_WHEN("Sssp_alg = static")
            {
                testKSP<OptYen, DeltaSteppingStatic, gt_undirected, 1, false>(G_d1);
            }
        }
    }

    WHEN("Executed in 4 threads")
    {
        AND_WHEN("parallel_ps = false")
        {
            AND_WHEN("delta = 0.1")
            {
                AND_WHEN("Sssp_alg = dynamic")
                {
                    testKSP<OptYen, DeltaSteppingDynamic, gt_undirected, 4, false>(G_d01);
                }

                AND_WHEN("Sssp_alg = static")
                {
                    testKSP<OptYen, DeltaSteppingStatic, gt_undirected, 4, false>(G_d01);
                }
            }

            AND_WHEN("delta = 1")
            {
                AND_WHEN("Sssp_alg = dynamic")
                {
                    testKSP<OptYen, DeltaSteppingDynamic, gt_undirected, 4, false>(G_d1);
                }

                AND_WHEN("Sssp_alg = static")
                {
                    testKSP<OptYen, DeltaSteppingStatic, gt_undirected, 4, false>(G_d1);
                }
            }
        }

        AND_WHEN("parallel_ps = true")
        {
            AND_WHEN("delta = 0.1")
            {
                AND_WHEN("Sssp_alg = dynamic")
                {
                    testKSP<OptYen, DeltaSteppingDynamic, gt_undirected, 4, true>(G_d01);
                }

                AND_WHEN("Sssp_alg = static")
                {
                    testKSP<OptYen, DeltaSteppingStatic, gt_undirected, 4, true>(G_d01);
                }
            }

            AND_WHEN("delta = 1")
            {
                AND_WHEN("Sssp_alg = dynamic")
                {
                    testKSP<OptYen, DeltaSteppingDynamic, gt_undirected, 4, true>(G_d1);
                }

                AND_WHEN("Sssp_alg = static")
                {
                    testKSP<OptYen, DeltaSteppingStatic, gt_undirected, 4, true>(G_d1);
                }
            }
        }
    }
}