//
// Created by Alex Schickedanz <alex@ae.cs.uni-frankfurt.de> on 05.09.17.
//

#define CATCH_CONFIG_MAIN
#include "../catch/catch.hpp"