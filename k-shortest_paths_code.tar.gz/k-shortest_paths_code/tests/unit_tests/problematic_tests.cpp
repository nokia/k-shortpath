//
// Created by Alex Schickedanz <alex@ae.cs.uni-frankfurt.de> on 05.09.17.
//

#include "catch.hpp"
#include "test_tools.h"

#include "Yen.h"
#include "OptYen.h"
#include "Katoh.h"
#include "Feng.h"

std::vector<std::pair<NODE_ID, NODE_ID>> problematic_source_destination_pairs_undirected = {{6615, 2950}, {4801, 1041}, {4983, 125}, {1936, 5574}, {127, 149}, {127,127}, {7232, 850}};
std::vector<std::pair<NODE_ID, NODE_ID>> problematic_source_destination_pairs_directed = {{1936, 5574}, {2026, 9482}, {3736, 7321}};

TEST_CASE("Problematic Cases")
{
    SECTION("undirected weighted")
    {
        const gt_undirected G_d01 = GraphRW::read_graph(const_cast<char*>("../resources/big_metis_file.graph"),
                                                        const_cast<char*>("0.1"),
                                                        GraphRW::file_type::METIS,
                                                        GraphRW::weight_converting::ORIGINAL);
        SECTION("sequential")
        {
            for(auto source_dest : problematic_source_destination_pairs_undirected)
            {
                const NODE_ID source = source_dest.first;
                const NODE_ID destination = source_dest.second;

                Feng<DeltaSteppingStatic, gt_undirected, 1, false> feng(G_d01, k);
                path_list feng_paths = feng.compute(source, destination);

                Yen<DeltaSteppingStatic, gt_undirected, 1, false> yen(G_d01, k);
                path_list yen_paths = yen.compute(source, destination);

                OptYen<DeltaSteppingStatic, gt_undirected, 1, false> opt_yen(G_d01, k);
                path_list opt_yen_paths = opt_yen.compute(source, destination);

                Katoh<DeltaSteppingStatic, gt_undirected, 1, false> katoh(G_d01, k);
                path_list katoh_paths = katoh.compute(source, destination);

                assert_path_lists_are_equal(feng_paths, yen_paths, source, destination);
                assert_path_lists_are_equal(feng_paths, opt_yen_paths, source, destination);
                assert_path_lists_are_equal(feng_paths, katoh_paths, source, destination);

                assert_paths_are_simple(feng_paths, source, destination);
                assert_paths_are_simple(yen_paths, source, destination);
                assert_paths_are_simple(opt_yen_paths, source, destination);
                assert_paths_are_simple(katoh_paths, source, destination);
            }
        }

        SECTION("parallel")
        {
            for(auto source_dest : problematic_source_destination_pairs_undirected)
            {
                const NODE_ID source = source_dest.first;
                const NODE_ID destination = source_dest.second;

                Feng<DeltaSteppingStatic, gt_undirected, 4, true> feng(G_d01, k);
                path_list feng_paths = feng.compute(source, destination);

                Yen<DeltaSteppingStatic, gt_undirected, 4, true> yen(G_d01, k);
                path_list yen_paths = yen.compute(source, destination);

                OptYen<DeltaSteppingStatic, gt_undirected, 4, true> opt_yen(G_d01, k);
                path_list opt_yen_paths = opt_yen.compute(source, destination);

                Katoh<DeltaSteppingStatic, gt_undirected, 4, true> katoh(G_d01, k);
                path_list katoh_paths = katoh.compute(source, destination);

                assert_path_lists_are_equal(feng_paths, yen_paths, source, destination);
                assert_path_lists_are_equal(feng_paths, opt_yen_paths, source, destination);
                assert_path_lists_are_equal(feng_paths, katoh_paths, source, destination);

                assert_paths_are_simple(feng_paths, source, destination);
                assert_paths_are_simple(yen_paths, source, destination);
                assert_paths_are_simple(opt_yen_paths, source, destination);
                assert_paths_are_simple(katoh_paths, source, destination);
            }
        }
    }

    SECTION("directed weighted")
    {
        const gt_directed G_dd01 = GraphRW::read_graph<true, true, true>(const_cast<char*>("../resources/directed_test_big.edgelist"), const_cast<char*>("0.1"),
                                                                         GraphRW::file_type::EDGELIST, GraphRW::weight_converting::ORIGINAL);
        SECTION("sequential")
        {
            for(auto source_dest : problematic_source_destination_pairs_directed)
            {
                const NODE_ID source = source_dest.first;
                const NODE_ID destination = source_dest.second;

                Feng<DeltaSteppingStatic, gt_directed, 1, false> feng(G_dd01, k);
                path_list feng_paths = feng.compute(source, destination);

                Yen<DeltaSteppingStatic, gt_directed, 1, false> yen(G_dd01, k);
                path_list yen_paths = yen.compute(source, destination);

                OptYen<DeltaSteppingStatic, gt_directed, 1, false> opt_yen(G_dd01, k);
                path_list opt_yen_paths = opt_yen.compute(source, destination);

                assert_path_lists_are_equal(feng_paths, yen_paths, source, destination);
                assert_path_lists_are_equal(feng_paths, opt_yen_paths, source, destination);

                assert_paths_are_simple(feng_paths, source, destination);
                assert_paths_are_simple(yen_paths, source, destination);
                assert_paths_are_simple(opt_yen_paths, source, destination);
            }
        }

        SECTION("parallel")
        {
            for(auto source_dest : problematic_source_destination_pairs_directed)
            {
                const NODE_ID source = source_dest.first;
                const NODE_ID destination = source_dest.second;

                Feng<DeltaSteppingStatic, gt_directed, 4, true> feng(G_dd01, k);
                path_list feng_paths = feng.compute(source, destination);

                Yen<DeltaSteppingStatic, gt_directed, 4, true> yen(G_dd01, k);
                path_list yen_paths = yen.compute(source, destination);

                OptYen<DeltaSteppingStatic, gt_directed, 4, true> opt_yen(G_dd01, k);
                path_list opt_yen_paths = opt_yen.compute(source, destination);

                assert_path_lists_are_equal(feng_paths, yen_paths, source, destination);
                assert_path_lists_are_equal(feng_paths, opt_yen_paths, source, destination);

                assert_paths_are_simple(feng_paths, source, destination);
                assert_paths_are_simple(yen_paths, source, destination);
                assert_paths_are_simple(opt_yen_paths, source, destination);
            }
        }
    }

    SECTION("undirected unweighted")
    {
        const gt_undirected_unweighted G_d01 = GraphRW::read_graph<false, false>(const_cast<char*>("../resources/big_metis_file.graph"),
                                                        const_cast<char*>("0.1"),
                                                        GraphRW::file_type::METIS);
        SECTION("sequential")
        {
            for(auto source_dest : problematic_source_destination_pairs_undirected)
            {
                const NODE_ID source = source_dest.first;
                const NODE_ID destination = source_dest.second;

                Feng<DeltaSteppingStatic, gt_undirected_unweighted, 1, false> feng(G_d01, k);
                path_list feng_paths = feng.compute(source, destination);

                Yen<DeltaSteppingStatic, gt_undirected_unweighted, 1, false> yen(G_d01, k);
                path_list yen_paths = yen.compute(source, destination);

                OptYen<DeltaSteppingStatic, gt_undirected_unweighted, 1, false> opt_yen(G_d01, k);
                path_list opt_yen_paths = opt_yen.compute(source, destination);

                Katoh<DeltaSteppingStatic, gt_undirected_unweighted, 1, false> katoh(G_d01, k);
                path_list katoh_paths = katoh.compute(source, destination);

                assert_path_lists_are_equal(feng_paths, yen_paths, source, destination);
                assert_path_lists_are_equal(feng_paths, opt_yen_paths, source, destination);
                assert_path_lists_are_equal(feng_paths, katoh_paths, source, destination);

                assert_paths_are_simple(feng_paths, source, destination);
                assert_paths_are_simple(yen_paths, source, destination);
                assert_paths_are_simple(opt_yen_paths, source, destination);
                assert_paths_are_simple(katoh_paths, source, destination);
            }
        }

        SECTION("parallel")
        {
            for(auto source_dest : problematic_source_destination_pairs_undirected)
            {
                const NODE_ID source = source_dest.first;
                const NODE_ID destination = source_dest.second;

                Feng<DeltaSteppingStatic, gt_undirected_unweighted, 4, true> feng(G_d01, k);
                path_list feng_paths = feng.compute(source, destination);

                Yen<DeltaSteppingStatic, gt_undirected_unweighted, 4, true> yen(G_d01, k);
                path_list yen_paths = yen.compute(source, destination);

                OptYen<DeltaSteppingStatic, gt_undirected_unweighted, 4, true> opt_yen(G_d01, k);
                path_list opt_yen_paths = opt_yen.compute(source, destination);

                Katoh<DeltaSteppingStatic, gt_undirected_unweighted, 4, true> katoh(G_d01, k);
                path_list katoh_paths = katoh.compute(source, destination);

                assert_path_lists_are_equal(feng_paths, yen_paths, source, destination);
                assert_path_lists_are_equal(feng_paths, opt_yen_paths, source, destination);
                assert_path_lists_are_equal(feng_paths, katoh_paths, source, destination);

                assert_paths_are_simple(feng_paths, source, destination);
                assert_paths_are_simple(yen_paths, source, destination);
                assert_paths_are_simple(opt_yen_paths, source, destination);
                assert_paths_are_simple(katoh_paths, source, destination);
            }
        }
    }

    SECTION("directed unweighted")
    {
        const gt_directed_unweighted G_dd01 = GraphRW::read_graph<true, false, true>(const_cast<char*>("../resources/directed_test_big.edgelist"), const_cast<char*>("0.1"),
                                                                         GraphRW::file_type::EDGELIST);
        SECTION("sequential")
        {
            for(auto source_dest : problematic_source_destination_pairs_directed)
            {
                const NODE_ID source = source_dest.first;
                const NODE_ID destination = source_dest.second;

                Feng<DeltaSteppingStatic, gt_directed_unweighted, 1, false> feng(G_dd01, k);
                path_list feng_paths = feng.compute(source, destination);

                Yen<DeltaSteppingStatic, gt_directed_unweighted, 1, false> yen(G_dd01, k);
                path_list yen_paths = yen.compute(source, destination);

                OptYen<DeltaSteppingStatic, gt_directed_unweighted, 1, false> opt_yen(G_dd01, k);
                path_list opt_yen_paths = opt_yen.compute(source, destination);

                assert_path_lists_are_equal(feng_paths, yen_paths, source, destination);
                assert_path_lists_are_equal(feng_paths, opt_yen_paths, source, destination);

                assert_paths_are_simple(feng_paths, source, destination);
                assert_paths_are_simple(yen_paths, source, destination);
                assert_paths_are_simple(opt_yen_paths, source, destination);
            }
        }

        SECTION("parallel")
        {
            for(auto source_dest : problematic_source_destination_pairs_directed)
            {
                const NODE_ID source = source_dest.first;
                const NODE_ID destination = source_dest.second;

                Feng<DeltaSteppingStatic, gt_directed_unweighted, 4, true> feng(G_dd01, k);
                path_list feng_paths = feng.compute(source, destination);

                Yen<DeltaSteppingStatic, gt_directed_unweighted, 4, true> yen(G_dd01, k);
                path_list yen_paths = yen.compute(source, destination);

                OptYen<DeltaSteppingStatic, gt_directed_unweighted, 4, true> opt_yen(G_dd01, k);
                path_list opt_yen_paths = opt_yen.compute(source, destination);

                assert_path_lists_are_equal(feng_paths, yen_paths, source, destination);
                assert_path_lists_are_equal(feng_paths, opt_yen_paths, source, destination);

                assert_paths_are_simple(feng_paths, source, destination);
                assert_paths_are_simple(yen_paths, source, destination);
                assert_paths_are_simple(opt_yen_paths, source, destination);
            }
        }
    }
}
