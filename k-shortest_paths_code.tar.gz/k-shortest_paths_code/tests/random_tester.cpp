//
// Created by Alex Schickedanz <alex@ae.cs.uni-frankfurt.de> on 18.07.17.
//

#include "GraphRW.h"
#include "DeltaSteppingDynamic.h"
#include "Feng.h"
#include "test_tools.h"
#include "Yen.h"
#include "OptYen.h"
#include "Katoh.h"

using namespace std;

void test_undirected_graphs(const unsigned int n, const unsigned int k)
{
    const gt_undirected G_d01 = GraphRW::read_graph(const_cast<char*>("../resources/big_metis_file.graph"), const_cast<char*>("0.1"),
                                                    GraphRW::file_type::METIS, GraphRW::weight_converting::ORIGINAL);

    unsigned int num_errors = 0;

    for(unsigned int i = 0; i < n; i++)
    {
        NODE_ID source, target;
        path_list feng_paths, yen_paths, opt_yen_paths, katoh_paths;

        while(true)
        {
            source = rand() % G_d01.get_num_nodes();
            target = rand() % G_d01.get_num_nodes();

            try
            {
                Feng<DeltaSteppingStatic, gt_undirected, 2, false> feng(G_d01, k);
                feng_paths = feng.compute(source, target);

                Yen<DeltaSteppingStatic, gt_undirected, 2, false> yen(G_d01, k);
                yen_paths = yen.compute(source, target);

                OptYen<DeltaSteppingStatic, gt_undirected, 2, false> opt_yen(G_d01, k);
                opt_yen_paths = opt_yen.compute(source, target);

                Katoh<DeltaSteppingStatic, gt_undirected, 2, false> katoh(G_d01, k);
                katoh_paths = katoh.compute(source, target);

                break;
            }
            catch(NoPathException& e)
            {
                std::cerr << "no path from s to t -> retry" << std::endl;
                continue;
            }
        }

        if(yen_paths.size() != opt_yen_paths.size()
           || yen_paths.size() != feng_paths.size()
           || yen_paths.size() != katoh_paths.size())
        {
            if(num_errors)
                cout << ",";
            cout << "[" << source << "," << destination << "]";
            num_errors++;
            continue;
        }

        const auto num_paths = yen_paths.size();
        for(unsigned int j = 0; j < num_paths; j++)
        {
            if(yen_paths[j].p != opt_yen_paths[j].p || yen_paths[j].p != feng_paths[j].p || yen_paths[j].p != katoh_paths[j].p)
            {
                cout << "paths not the same:" << endl;
                cout << "feng:" << endl;
                cout << paths_to_string(feng_paths) << endl;
                cout << "katoh:" << endl;
                cout << paths_to_string(katoh_paths) << endl;

                if(num_errors)
                    cout << ",";

                cout << "[" << source << "," << destination << "]";
                num_errors++;
                break;
            }
        }
    }
}

void test_directed_graphs(const unsigned int n, const unsigned int k)
{
    const gt_directed G_dd01 = GraphRW::read_graph<true, true, true>(const_cast<char*>("../resources/directed_test_big.edgelist"), const_cast<char*>("0.1"),
                                                                     GraphRW::file_type::EDGELIST, GraphRW::weight_converting::ORIGINAL);

    unsigned int num_errors = 0;

    for(unsigned int i = 0; i < n; i++)
    {
        NODE_ID source, target;
        path_list feng_paths, yen_paths, opt_yen_paths, katoh_paths;

        while(true)
        {
            source = rand() % G_dd01.get_num_nodes();
            target = rand() % G_dd01.get_num_nodes();

            try
            {
                Feng<DeltaSteppingStatic, gt_directed, 2, false> feng(G_dd01, k);
                feng_paths = feng.compute(source, target);

                Yen<DeltaSteppingStatic, gt_directed, 2, false> yen(G_dd01, k);
                yen_paths = yen.compute(source, target);

                break;
            }
            catch(NoPathException& e)
            {
                std::cerr << "no path from s to t -> retry" << std::endl;
                continue;
            }
        }

        if(yen_paths.size() != feng_paths.size())
        {
            if(num_errors)
                cout << ",";
            cout << "[" << source << "," << destination << "]";
            num_errors++;
            continue;
        }

        const auto num_paths = yen_paths.size();
        for(unsigned int j = 0; j < num_paths; j++)
        {
            if(yen_paths[j].p != feng_paths[j].p)
            {
                if(num_errors)
                    cout << ",";
                cout << "[" << source << "," << destination << "]";
                num_errors++;
                break;
            }
        }
    }
}

int main(int argc, char* argv[])
{
    if(argc < 2)
    {
        cout << "This program runs n random tests on a directed graph comparing all KSP algorithms. The output is a JSON list of all source - destination pairs with wrong results." << endl << endl;
        cout << "Input arguments:" << endl;
        cout << "[1] n, the number of " << endl;
        exit(1);
    }

    const auto n = static_cast<unsigned int>(strtoul(argv[1], nullptr, 0));
    const unsigned int k = 10;

    srand(static_cast<unsigned int>(time(nullptr)));

    cout << "{\"undirected\":[";

    test_undirected_graphs(n, k);

    cout << "], \"directed\":[";

    test_directed_graphs(n, k);

    cout << "]}" << endl;

    exit(0);
}
