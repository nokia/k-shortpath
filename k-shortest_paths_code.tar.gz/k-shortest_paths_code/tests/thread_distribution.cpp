//
// Created by Alex Schickedanz <alex@ae.cs.uni-frankfurt.de> on 28.08.17.
//

#include <omp.h>
#include <iostream>

#define SUNW_MP_MAX_POOL_THREADS = 8

using namespace std;

void print_status(const int outer_thread_id)
{
#pragma omp critical
    {
        cout << outer_thread_id << " - " << omp_get_thread_num() << " | "
             <<  omp_get_num_teams() << " - " << omp_get_team_num() << " | "
             << omp_get_team_size(0) << " - "
             << omp_get_team_size(1) << " - " << omp_get_team_size(2) << " - " << omp_get_team_size(3) << endl;
    }
}

void parallel_test_function(const int outer_thread_id)
{
#pragma omp parallel for num_threads(4)
    for(unsigned int j = 0; j < 4; j++)
    {
        print_status(outer_thread_id);
    }
}

int main()
{
    omp_set_nested(1);

    omp_set_num_threads(16);



#pragma omp parallel for num_threads(4)
    for(unsigned int i = 0;  i < 4; i++)
    {
        const auto outer_thread_id = omp_get_thread_num();
        parallel_test_function(outer_thread_id);
    }

    return 0;
}