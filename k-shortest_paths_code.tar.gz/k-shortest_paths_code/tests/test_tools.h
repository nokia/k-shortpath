//
// Created by Alex Schickedanz <alex@ae.cs.uni-frankfurt.de> on 05.09.17.
//

#ifndef K_SHORTEST_PATHS_CODE_TEST_TOOLS_H
#define K_SHORTEST_PATHS_CODE_TEST_TOOLS_H

#include "catch.hpp"

#include "SsspTree.h"
#include "KSP.h"

using path_list = std::vector<Path>;
using default_graph_type = BasicGraph<false, true>;
using gt_undirected = BasicGraph<false, true>;
using gt_directed = BasicGraph<true, true>;
using gt_undirected_unweighted = BasicGraph<false, false>;
using gt_directed_unweighted = BasicGraph<true, false>;

// todo move this to static_test and use something else for other tests
const NODE_ID source    = 1595,
        destination     = 6325;
const unsigned int k    = 10;

const std::vector<std::vector<NODE_ID>> result = {
        {1595, 1601, 1604, 1608, 1632, 1663, 1719, 1192, 1255, 1333, 1437, 2264, 6284, 6221, 6202, 6357, 6325},
        {1595, 1601, 1604, 1608, 1632, 1663, 1719, 1192, 1409, 1437, 2264, 6284, 6221, 6202, 6357, 6325},
        {1595, 1601, 1604, 1608, 1632, 1663, 1719, 1192, 1255, 1333, 1437, 2264, 6284, 6017, 6244, 6221, 6202, 6357, 6325},
        {1595, 1601, 1604, 1608, 1632, 1663, 1719, 1192, 2264, 6284, 6221, 6202, 6357, 6325},
        {1595, 1601, 1604, 1608, 1632, 1663, 1719, 1192, 1409, 1437, 2264, 6284, 6017, 6244, 6221, 6202, 6357, 6325},
        {1595, 1601, 1604, 1608, 1632, 1663, 1719, 1192, 1255, 1333, 1437, 2264, 6284, 6214, 6225, 5860, 6202, 6357, 6325},
        {1595, 1601, 1604, 1608, 1632, 1663, 1719, 1192, 2264, 6284, 6017, 6244, 6221, 6202, 6357, 6325},
        {1595, 1601, 1604, 1608, 1632, 1663, 1719, 1192, 1255, 1333, 1437, 2264, 6284, 6214, 6221, 6202, 6357, 6325},
        {1595, 1601, 1604, 1608, 1632, 1663, 1719, 1192, 1409, 1437, 2264, 6284, 6214, 6225, 5860, 6202, 6357, 6325},
        {1595, 1601, 1604, 1608, 1632, 1663, 1719, 1192, 2264, 6284, 6214, 6225, 5860, 6202, 6357, 6325}};

inline std::string vector_to_string(std::vector<NODE_ID> const& value) {
    std::string str;
    for(unsigned int i : value)
        str += std::to_string(i) + " ";

    return str;
}

inline std::string paths_to_string(const path_list& paths)
{
    std::string str;
    for(unsigned int i = 0; i < paths.size(); i++)
        str += std::to_string(i) + ". (" + std::to_string(paths[i].length) + ", " + std::to_string(paths[i].parent_index) + ", " + std::to_string(paths[i].alpha) + ") " + vector_to_string(paths[i].p) + "\n";

    return str;
}

inline std::string path_is_simple(const std::vector<NODE_ID>& path)
{
    for(size_t i = 0; i < path.size() - 1; ++i)
    {
        for(size_t j = i + 1; j < path.size(); ++j)
        {
            if(path[i] == path[j])
                return "no (" + std::to_string(path[i]) + ")";
        }
    }

    return "yes";
}
inline void assert_paths_are_simple(const std::vector<Path>& paths, const NODE_ID source, const NODE_ID target)
{
    CAPTURE(source);
    CAPTURE(target);
    for(const auto& path: paths)
    {
        REQUIRE(path_is_simple(path.p) == "yes");
    }
}

inline std::string paths_are_unique(const std::vector<Path>& paths)
{
    for(unsigned int i = 0; i < paths.size(); i++)
    {
        for(unsigned int j = i + 1; j < paths.size(); j++)
        {
            if(paths[i].p == paths[j].p)
                return "no (paths " + std::to_string(i) + " and " + std::to_string(j) + " are equal)";
        }
    }

    return "yes";
}

template<bool check_by_path = false>
inline void assert_path_lists_are_equal(path_list a, path_list b, const NODE_ID source, const NODE_ID target)
{
    CAPTURE(source);
    CAPTURE(target);
    REQUIRE(a.size() == b.size());

    if(check_by_path)
    {
        std::sort(a.begin(), a.end());
        std::sort(b.begin(), b.end());
    }

    for(unsigned int i = 0; i < a.size(); i++)
    {
        CAPTURE(source);
        CAPTURE(target);
        CAPTURE(i);
        INFO(vector_to_string(a[i].p) << " (" << a[i].length << ")\n  " << vector_to_string(b[i].p) << " (" << b[i].length << ")");

        if(check_by_path)
            REQUIRE(a[i].p != b[i].p);
        else
            REQUIRE(std::fabs(a[i].length - b[i].length) < 100 * std::numeric_limits<w_type>::epsilon());
    }
}

template<bool check_by_path = false>
inline bool path_lists_are_equal(path_list a, path_list b)
{
    if(a.size() != b.size())
        return false;

    if(check_by_path)
    {
        std::sort(a.begin(), a.end());
        std::sort(b.begin(), b.end());
    }

    for(unsigned int i = 0; i < a.size(); i++)
    {
        if(check_by_path)
        {
            if(a[i].p != b[i].p)
                return false;
        }
        else
        {
            if(std::fabs(a[i].length - b[i].length) >= 100 * std::numeric_limits<w_type>::epsilon())
                return false;
        }
    }

    return true;
}

template<template<template<typename, template<typename> class> class, typename, unsigned int, bool> class KSPAlgo,
         template<typename, template<typename> class> class DS,
         typename GraphType, unsigned int num_threads, bool parallel_ps>
inline path_list getPaths(const GraphType& G)
{
    // calculate k shortest paths
    omp_set_num_threads(num_threads);

    KSPAlgo<DS, GraphType, num_threads, parallel_ps> ksp(G, k);

    path_list paths = ksp.compute(source, destination);

    return paths;
}

template<template<template<typename, template<typename> class> class, typename, unsigned int, bool> class KSPAlgo,
         template<typename, template<typename> class> class DS,
         typename GraphType, unsigned int num_threads, bool parallel_ps>
inline void testKSP(const GraphType& G)
{
    path_list paths = getPaths<KSPAlgo, DS, GraphType, num_threads, parallel_ps>(G);

    // check the results
    for(unsigned int i = 0; i < k; i++)
    {
        INFO("Paths: ");
        INFO(paths_to_string(paths));
        INFO("Problem with path " << i);
        INFO("Path is simple: " << path_is_simple(paths[i].p));
        INFO("Expected: " << vector_to_string(result[i]));
        REQUIRE(result[i] == paths[i].p);
    }
}

/**
 * Checks if the SSSP tree is correct. Returns true if it is, false if not.
 * @param g         The full graph.
 * @param ssspTree  The SSSP tree to test.
 * @param source    This is the source node the SSSP tree is calculated with.
 * @return true if the SSSP tree is correct, false if it is not.
 */
template<typename graph_type>
inline bool sssp_check(const graph_type& g, const SsspTree& ssspTree, NODE_ID source)
{
    unsigned int num_errors = 0;

    if(ssspTree.get_distance(source) != 0)
        num_errors++;

    for(NODE_ID u = 0; u < g.get_num_nodes(); u++)
    {
        for(auto e_id = g.get_edge_list_begin(u); e_id < g.get_edge_list_end(u); e_id++)
        {
            const auto e = g.get_edge(e_id);
            if(ssspTree.get_distance(u) + e.get_weight() < ssspTree.get_distance(e.get_target()))
            {
                num_errors++;
                std::cerr << "(1) WRONG DISTANCE FOR NODE " << u << std::endl;
            }
        }

        if(u == source)
            continue;

        if(ssspTree.get_distance(u) < INFINITE_DISTANCE)
        {
            const auto v = ssspTree.get_shortest_path(u, true)[1];
            if(g.get_edge_weight(v, u) + ssspTree.get_distance(v) != ssspTree.get_distance(u))
            {
                num_errors++;
                std::cerr << "(2) WRONG DISTANCE FOR NODE " << u << std::endl;
            }
        }
    }

    return num_errors == 0;
}



#endif //K_SHORTEST_PATHS_CODE_TEST_TOOLS_H
