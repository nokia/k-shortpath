//
// Created by Alex Schickedanz <alex@ae.cs.uni-frankfurt.de> on 18.07.17.
//

#include "GraphRW.h"
#include "BasicGraph.h"
#include "DeltaSteppingDynamic.h"
#include "Feng.h"
#include <algorithm>
#include <cassert>
#include <cstring>
#include <sstream>
#include <iostream>
#include <fstream>
#include <string>

using graph_type = BasicGraph<false, true>;

void print_graph(const graph_type& G)
{
    for(NODE_ID u = 0; u < G.get_num_nodes(); u++)
    {
        for(EDGE_ID e_id = G.get_edge_list_begin(u); e_id < G.get_edge_list_end(u); e_id++)
        {
            std::cout << u << " - " << G.get_edge(e_id).get_target() << "  ( " << G.get_edge(e_id).get_weight() << " )" << std::endl;
        }
    }
}

void check_distances(const unsigned int num_nodes, const SsspTree& tree, const char* dists_file_path)
{
    std::ifstream dists_file(dists_file_path);
    std::string line;
    unsigned int error_counter = 0;
    const w_type epsilon = 2e-6;

    for(NODE_ID u = 0; u < num_nodes; u++)
    {
        std::getline(dists_file, line);
        std::stringstream ss(line);
        w_type dist;
        ss >> dist;

        if(tree.get_distance(u) - dist > epsilon)
        {
            error_counter++;
            std::cerr << dist << " != " << tree.get_distance(u) << "  (diff ~ " << (tree.get_distance(u) - dist) <<  ")" << std::endl;
        }
    }

    if(error_counter == 0)
    {
        std::cerr << "All distances right" << std::endl;
    }
    else
    {
        std::cerr << error_counter << " wrong distances" << std::endl;
        exit(1);
    }
}

int main(int /*argc*/, char* argv[])
{
    omp_set_dynamic(0);
    omp_set_num_threads(1);

    // TESTS SETS
    // Test Set 1
//    const char* graph_file = "../resources/big_metis_file.graph";
    char graph_file[40];
    char dists_file[40];
    sprintf(graph_file, "resources/small_instance_%s.metis", argv[1]);
    sprintf(dists_file, "resources/small_instance_%s.dists", argv[1]);
    std::cout<< graph_file << std::endl;
//    const char* graph_file = "resources/small_instance_.metis";
//    const NODE_ID source = 1595;
//    const NODE_ID target = 6325;
    // Test Set 2
//    const char* graph_file = "../resources/debug_34.metis";
//    const NODE_ID source = 1;

    const NODE_ID target = 0;

    graph_type G = GraphRW::read_graph(const_cast<char*>(graph_file), const_cast<char*>("0.1"),
                                       GraphRW::file_type::METIS, GraphRW::weight_converting::ORIGINAL);

//    print_graph(G);

    KSPGraph<graph_type> ksp(G);
    auto ds = DeltaSteppingDynamic<graph_type>(ksp, 1);

    ds.compute(target);

    // print sssp tree
//    ds.get_sssp_tree().print_tree();      // debug distances are wrong
    check_distances(G.get_num_nodes(), ds.get_sssp_tree(), dists_file);

    exit(0);
}
