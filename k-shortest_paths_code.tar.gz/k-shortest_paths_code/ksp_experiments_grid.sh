#!/usr/bin/env bash

#prepare resources and results
cd resources
mkdir grid
cd ../results
mkdir parallel_ksp_performance
cd parallel_ksp_performance
mkdir grid
cd ..
mkdir parallel_ds
cd parallel_ds
mkdir grid
cd ../..

mkdir build
cd build

#build ksp code
mkdir build
cmake -DCMAKE_C_COMPILER=/usr/bin/gcc-5 -DCMAKE_CXX_COMPILER=/usr/bin/g++-5 -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DUNDIRECTED" ..
cmake --build . --target add_float_weights
cmake --build . --target connected
cmake --build . --target generate_g_nm
cmake --build . --target makePacManMap 

#create grids
./makePacManMap ../resources/grid/n22_square.edgelist 2048 2048
./makePacManMap ../resources/grid/n22_rect.edgelist 128 32768

#add random weights to RMAT graphs
./add_float_weights ../resources/grid/n22_square.edgelist > ../resources/grid/n22_square.weighted.edgelist
./add_float_weights ../resources/grid/n22_rect.edgelist > ../resources/grid/n22_rect.weighted.edgelist

#extract connected component
./connected ../resources/grid/n22_square.weighted.edgelist EDGELIST > ../resources/grid/n22_square.weighted.connected.edgelist
./connected ../resources/grid/n22_rect.weighted.edgelist EDGELIST > ../resources/grid/n22_rect.weighted.connected.edgelist

#################
#run experiments#
#################
g_grid=("grid/n22_square.weighted.connected.edgelist" "grid/n22_rect.weighted.connected.edgelist")
threads=(2 4 6 8 10)
ks=(10 15 20 40)

#collect machine info
for g in ${g_grid[@]}
do
  log="../results/parallel_ksp_performance/$g""_early_stopping.log"
  lscpu >> $log
done 

run=(0 1)

for r in ${run[@]}
do
  for g in ${g_grid[@]}
  do
    #(1) use early stopping
    log="../results/parallel_ksp_performance/$g""_early_stopping.log"
    #first run using 1 thread
    cmake -DCMAKE_C_COMPILER=/usr/bin/gcc-5 -DCMAKE_CXX_COMPILER=/usr/bin/g++-5 -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=1" ..
    cmake --build . --target ksp_performance
    numactl --cpunodebind=1 --membind=1 ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
    #run on using the rest of threads
    for t in ${threads[@]}
    do
      #use psp
      cmake -DCMAKE_C_COMPILER=/usr/bin/gcc-5 -DCMAKE_CXX_COMPILER=/usr/bin/g++-5 -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=$t" ..
      cmake --build . --target ksp_performance
      numactl --cpunodebind=1 --membind=1 ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
      #use L1 pd
      cmake -DCMAKE_C_COMPILER=/usr/bin/gcc-5 -DCMAKE_CXX_COMPILER=/usr/bin/g++-5 -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=$t -DKSP_PARALLEL_DEVIATIONS_L1" ..
      cmake --build . --target ksp_performance
      numactl --cpunodebind=1 --membind=1 ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
      #use L2 pd
      cmake -DCMAKE_C_COMPILER=/usr/bin/gcc-5 -DCMAKE_CXX_COMPILER=/usr/bin/g++-5 -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=$t -DKSP_PARALLEL_DEVIATIONS_L2" ..
      cmake --build . --target ksp_performance
      numactl --cpunodebind=1 --membind=1 ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
    done
    #iterate over K using 10 threads
    for k in ${ks[@]}
    do
      cmake -DCMAKE_C_COMPILER=/usr/bin/gcc-5 -DCMAKE_CXX_COMPILER=/usr/bin/g++-5 -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=8" ..
      cmake --build . --target ksp_performance
      numactl --cpunodebind=1 --membind=1 ./ksp_performance ../resources/$g $r EDGELIST $k All static 0.01 >> $log
      #use L1 pd
      cmake -DCMAKE_C_COMPILER=/usr/bin/gcc-5 -DCMAKE_CXX_COMPILER=/usr/bin/g++-5 -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=8 -DKSP_PARALLEL_DEVIATIONS_L1" ..
      cmake --build . --target ksp_performance
      ./ksp_performance ../resources/$g $r EDGELIST $k All static 0.01 >> $log
      #use L2 pd
      cmake -DCMAKE_C_COMPILER=/usr/bin/gcc-5 -DCMAKE_CXX_COMPILER=/usr/bin/g++-5 -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=8 -DKSP_PARALLEL_DEVIATIONS_L2" ..
      cmake --build . --target ksp_performance
      numactl --cpunodebind=1 --membind=1 ./ksp_performance ../resources/$g $r EDGELIST $k All static 0.01 >> $log
    done
  done
done

#################
#run experiments#
#################
threads=(1 2 4 6 8 10)

#collect machine info
for g in ${g_grid[@]}
do
  log="../results/parallel_ds/$g""_static.log"
  lscpu >> $log
done

for r in ${run[@]}
do
  for g in ${g_grid[@]}
  do
    #(1) use early stopping
    log="../results/parallel_ds/$g""_static.log"
    for t in ${threads[@]}
    do
      #use psp
      cmake -DCMAKE_C_COMPILER=/usr/bin/gcc-5 -DCMAKE_CXX_COMPILER=/usr/bin/g++-5 -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=$t" ..
      cmake --build . --target static-delta-stepping
      numactl --cpunodebind=1 --membind=1 ./static-delta-stepping ../resources/$g $r 0.01 $t >> $log
    done
  done
done
