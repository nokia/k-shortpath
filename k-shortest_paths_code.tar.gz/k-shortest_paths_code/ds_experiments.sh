#!/usr/bin/env bash

cd results
mkdir parallel_ds
cd parallel_ds
mkdir random
mkdir RMAT
cd ../..

mkdir build
cd build

#################
#run experiments#
#################
g_rmat=("RMAT/n20_128.weighted.connected.edgelist" "RMAT/n22_4.weighted.connected.edgelist")
g_random=("random/n20_128.connected.edgelist" "random/n22_4.connected.edgelist")
threads=(1 2 4 6 8 10 16)

#collect machine info
for g in ${g_rmat[@]}
do
  log="../results/parallel_ds/$g""_static.log"
  lscpu >> $log
done 

for g in ${g_random[@]}
do
  log="../results/parallel_ds/$g""_static.log"
  lscpu >> $log
done

run=(0 1)

#merge later
for r in ${run[@]}
do
  #use RMAT graphs
  for g in ${g_rmat[@]}
  do
    #(1) use early stopping
    log="../results/parallel_ds/$g""_static.log"
    for t in ${threads[@]}
    do
      #use psp
      cmake -DCMAKE_C_COMPILER=/usr/bin/gcc-5 -DCMAKE_CXX_COMPILER=/usr/bin/g++-5 -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=$t" ..
      cmake --build . --target static-delta-stepping
      ./static-delta-stepping ../resources/$g $r 0.01 $t >> $log
    done
  done

  #use random graphs
  for g in ${g_random[@]}
  do
    #(1) use early stopping
    log="../results/parallel_ds/$g""_static.log"
    for t in ${threads[@]}
    do
      #use psp
      cmake -DCMAKE_C_COMPILER=/usr/bin/gcc-5 -DCMAKE_CXX_COMPILER=/usr/bin/g++-5 -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=$t" ..
      cmake --build . --target static-delta-stepping
      ./static-delta-stepping ../resources/$g $r 0.01 $t >> $log
    done
  done
done
