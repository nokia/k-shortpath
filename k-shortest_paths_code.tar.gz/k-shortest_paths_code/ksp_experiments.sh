#!/usr/bin/env bash

#prepare resources and results
cd resources
mkdir RMAT
mkdir random
cd ../results
mkdir parallel_ksp_performance
cd parallel_ksp_performance
mkdir RMAT
mkdir random
cd ../..

#build PaRMAT
git submodule update --init --recursive
cd PaRMAT/Release
make

#create RMAT
#n20_128
./PaRMAT -nVertices 1048576 -nEdges 134217728 -output ../../resources/RMAT/n20_128.edgelist -threads 10 -sorted -noEdgeToSelf -noDuplicateEdges -undirected

#n22_4
./PaRMAT -nVertices 4194304 -nEdges 16777216 -output ../../resources/RMAT/n22_4.edgelist -threads 10 -sorted -noEdgeToSelf -noDuplicateEdges -undirected

#build ksp code
cd ../..
mkdir build
cd build
cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DUNDIRECTED" ..
cmake --build . --target add_float_weights
cmake --build . --target connected
cmake --build . --target generate_g_nm

#add random weights to RMAT graphs
./add_float_weights ../resources/RMAT/n20_128.edgelist > ../resources/RMAT/n20_128.weighted.edgelist
./add_float_weights ../resources/RMAT/n22_4.edgelist > ../resources/RMAT/n22_4.weighted.edgelist

#extract connected component
./connected ../resources/RMAT/n20_128.weighted.edgelist EDGELIST > ../resources/RMAT/n20_128.weighted.connected.edgelist
./connected ../resources/RMAT/n22_4.weighted.edgelist EDGELIST > ../resources/RMAT/n22_4.weighted.connected.edgelist

#create random graphs
./generate_g_nm 1048576 134217728 ../resources/random/n20_128.metis 123456
./generate_g_nm 4194304 16777216 ../resources/random/n22_4.metis 123456

#extract connected component
./connected ../resources/random/n20_128.metis METIS > ../resources/random/n20_128.connected.edgelist
./connected ../resources/random/n22_4.metis METIS > ../resources/random/n22_4.connected.edgelist

#################
#run experiments#
#################
g_rmat=("RMAT/n20_128.weighted.connected.edgelist" "RMAT/n22_4.weighted.connected.edgelist")
g_random=("random/n20_128.connected.edgelist" "random/n22_4.connected.edgelist")
threads=(2 4 6 8 10)
ks=(10 15 20 40)

#collect machine info
for g in ${g_rmat[@]}
do
  log="../results/parallel_ksp_performance/$g""_early_stopping.log"
  lscpu >> $log
  log="../results/parallel_ksp_performance/$g""_no_early_stopping.log"
  lscpu >> $log
done 

for g in ${g_random[@]}
do
  log="../results/parallel_ksp_performance/$g""_early_stopping.log"
  lscpu >> $log
  log="../results/parallel_ksp_performance/$g""_no_early_stopping.log"
  lscpu >> $log
done

run=(0 1)

#merge later
for r in ${run[@]}
do
  #use RMAT graphs
  for g in ${g_rmat[@]}
  do
    #(1) use early stopping
    log="../results/parallel_ksp_performance/$g""_early_stopping.log"
    #first run using 1 thread
    cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=1" ..
    cmake --build . --target ksp_performance
    ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
    #run on using the rest of threads
    for t in ${threads[@]}
    do
      #use psp
      cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=$t" ..
      cmake --build . --target ksp_performance
      ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
      #use L1 pd
      cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=$t -DKSP_PARALLEL_DEVIATIONS_L1" ..
      cmake --build . --target ksp_performance
      ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
      #use L2 pd
      cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=$t -DKSP_PARALLEL_DEVIATIONS_L2" ..
      cmake --build . --target ksp_performance
      ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
    done
    #iterate over K using 10 threads
    for k in ${ks[@]}
    do
      cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=10" ..
      cmake --build . --target ksp_performance
      ./ksp_performance ../resources/$g $r EDGELIST $k All static 0.01 >> $log
      #use L1 pd
      cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=10 -DKSP_PARALLEL_DEVIATIONS_L1" ..
      cmake --build . --target ksp_performance
      ./ksp_performance ../resources/$g $r EDGELIST $k All static 0.01 >> $log
      #use L2 pd
      cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=10 -DKSP_PARALLEL_DEVIATIONS_L2" ..
      cmake --build . --target ksp_performance
      ./ksp_performance ../resources/$g $r EDGELIST $k All static 0.01 >> $log
    done
    #(2) don’t use early stopping (do not iterate over K in this case and only use 1 thread)
    log="../results/parallel_ksp_performance/$g""_no_early_stopping.log"
    #first run using 1 thread
    cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=1 -DNO_SSSP_EARLY_STOPPING" ..
    cmake --build . --target ksp_performance
    ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
  done

  #use random graphs
  for g in ${g_random[@]}
  do
    #(1) use early stopping
    log="../results/parallel_ksp_performance/$g""_early_stopping.log"
    #first run using 1 thread
    cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=1" ..
    cmake --build . --target ksp_performance
    ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
    #run on using the rest of threads
    for t in ${threads[@]}
    do
      #use psp
      cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=$t" ..
      cmake --build . --target ksp_performance
      ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
      #use L1 pd
      cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=$t -DKSP_PARALLEL_DEVIATIONS_L1" ..
      cmake --build . --target ksp_performance
      ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
      #use L2 pd
      cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=$t -DKSP_PARALLEL_DEVIATIONS_L2" ..
      cmake --build . --target ksp_performance
      ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
    done
    #iterate over K using 10 threads
    for k in ${ks[@]}
    do
      cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=10" ..
      cmake --build . --target ksp_performance
      ./ksp_performance ../resources/$g $r EDGELIST $k All static 0.01 >> $log
      #use L1 pd
      cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=10 -DKSP_PARALLEL_DEVIATIONS_L1" ..
      cmake --build . --target ksp_performance
      ./ksp_performance ../resources/$g $r EDGELIST $k All static 0.01 >> $log
      #use L2 pd
      cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=10 -DKSP_PARALLEL_DEVIATIONS_L2" ..
      cmake --build . --target ksp_performance
      ./ksp_performance ../resources/$g $r EDGELIST $k All static 0.01 >> $log
    done
    #(2) don’t use early stopping (do not iterate over K in this case and use 1 thread only)
    log="../results/parallel_ksp_performance/$g""_no_early_stopping.log"
    #first run using 1 thread
    cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=1 -DNO_SSSP_EARLY_STOPPING" ..
    cmake --build . --target ksp_performance
    ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
  done
done
