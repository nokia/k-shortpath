Engineering a Parallel k-Shortest Simple Path Algorithm for Multicores
====

[![Build Status](https://travis-ci.com/AbcAeffchen/k-shortest_paths_code.svg?token=ceVtF6qrSY1svJe8s3mc&branch=master)](https://travis-ci.com/AbcAeffchen/k-shortest_paths_code)

Compile
----

Using CMake just go to the project folder and run

```
mkdir build
cd build
cmake -DCMAKE_BUILD_TYPE=<BUILD_TYPE> ..
cmake --build . --target <target>
```

Choose one of the following as `<BUILD_TYPE>`:

- `TESTING_WITH_KSP_PROFILING`: With `-O3` and `-g`. The program collects some KSP statistics.
- `TESTING_WITHOUT_KSP_PROFILING`: With `-O3` and `-g`. The program collects no KSP statistics.
- `PROFILING`: With `-g -pg`. This is very slow. Do not use this for anything but profiling.
TODO The profiling build needs some tuning. Without optimisation it profiles the wrong things, with optimisation it cannot tell you where exactly the program is. Maybe using something other than `-pg`?
- `DEBUGGING`: `-g -O0` and KSP statistics turned on.
- `ADDRESS_SANITIZER`:  With `-g -fsanitize=address` and KSP statistics turned on. Very slow. Do not use this for anything other than address sanitizing.
- `EXPERIMENT`: With `-O3` and assertions removed.

TODO Mabye add an experiment build with KSP statistics activated

`<target>` can be one of the following:

- `all`: builds all executables.
- `unit_testing`: The unit tests to test everything.
- `yellow_graph_size`: Used for the experiments for the size of the yellow graphs.
- `ksp_performance`: Used for experiments about the performance of the different KSP algorithms.

There are more. Just have a look at [CMakeLists.txt](CMakeLists.txt)
file and look for the `add_executable` lines.

To specify compiler flags add `-DCMAKE_CXX_FLAGS="<flags here>"`.

You can use:
- `-DKSP_USE_OLD_CANDIDATE_STRUCT`: Uses the old candidates data structure.
- `-DNO_SSSP_EARLY_STOPPING`: Turns off Early stopping for all SSSP algorithms.
- `-DKSP_PARALLEL_DEVIATIONS_L1`: Uses level 1 parallel deviations.
- `-DKSP_PARALLEL_DEVIATIONS_L2`: Uses level 2 parallel deviations (nested parallelism).

Tests
----
Running `unit_testing` will run Yen, OptYen, Katoh and Feng with different settings and on different graphs.
It is also build and executed every time something gets pushed to this repository.

Experiments
----
- **Yellow Graph & k Shortest Path Statistics**<br>
For this experiment you have to execute the file `yellow_graph_size`.
There is also a test runner `yellow_graph_statistics.sh` and `yellow_graph_statistics_undirected.sh`
in the project root. They both take a graph file in metis format and the number of runs
as arguments. They run three experiments:

 - weighted using the weights in the graph file assuming they are uniform random.
 - weighted with exponential random weights (converted from the weights in the graph file)
 - unweighted (all edges get length 1)

 You need to run `yellow_graph_statistics_compile.sh` first.

TODO


View the results
----

There are some test results in the subdirectory in `results`. Each file contains data in JSON format.
The results are visualized using [Jupyter Notebook](https://jupyter.org/).

You can install Jupyter Notebook using pip.
```
pip3 install jupyter
```

If you have Jupyter installed, you can start it using
```
jupyter notebook
```

This opens a website. Just navigate to the `PROJECT_ROOT/results` and open one of the `.ipynb` files. You can run every cell
by clicking in the navigation on "Kernel -> Restart & Run All".

An alternative way to view the raw data is to use a JSON viewer like this online tool: http://jsonviewer.stack.hu/

Helpers
----
There are some helper scripts in `/helpers`. See the [README](/helpers/) for more details.

