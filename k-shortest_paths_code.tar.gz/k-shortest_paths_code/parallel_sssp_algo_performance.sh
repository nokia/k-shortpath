#!/usr/bin/env bash

file_name_n23="~/storage/rmat/n23/rmat_n_23_128.renumbered.float.bin"
file_name_n26="~/storage/rmat/n26/rmat_n_26.float.renumbered.bin"

printf "$file_name_n23  |";
for delta in 0.05 0.1 0.15 0.2 0.25 0.3
do
    for threads in 1 2 4 8
    do
	for delta in 0.05 0.1 0.15 0.2 0.25 0.3;
        do
            ./build/parallel_shortest_path_performance $file_name_n23 $delta $threads >> ./results/parallel_sssp_performance/$file_name_n23.log;
            printf "=";
        done
    done 
done
echo "|"

printf "$file_name_n26  |";
for delta in 0.05 0.1 0.15 0.2 0.25 0.3
do
    for threads in 1 2 4 8
    do
        for delta in 0.05 0.1 0.15 0.2 0.25 0.3;
        do
            ./build/parallel_shortest_path_performance $file_name_n26 $delta $threads >> ./results/parallel_sssp_performance/$file_name_n26.log;
            printf "=";
        done
    done
done
echo "|"

