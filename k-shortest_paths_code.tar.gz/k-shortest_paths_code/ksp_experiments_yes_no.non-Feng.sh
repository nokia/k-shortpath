#!/usr/bin/env bash

#################
#run experiments#
#################
g_rmat=("RMAT/n20_128.weighted.connected.edgelist" "RMAT/n22_4.weighted.connected.edgelist")
g_random=("random/n20_128.connected.edgelist" "random/n22_4.connected.edgelist")

cd build

#change this accordingly
t=8

#collect machine info
for g in ${g_rmat[@]}
do
  log="../results/parallel_ksp_performance/$g""_early_stopping_$t"".log"
  lscpu >> $log
  log="../results/parallel_ksp_performance/$g""_no_early_stopping_$t"".log"
  lscpu >> $log
done 

for g in ${g_random[@]}
do
  log="../results/parallel_ksp_performance/$g""_early_stopping_$t"".log"
  lscpu >> $log
  log="../results/parallel_ksp_performance/$g""_no_early_stopping_$t"".log"
  lscpu >> $log
done

run=(0 1)

#merge later
for r in ${run[@]}
do
  #use RMAT graphs
  for g in ${g_rmat[@]}
  do
    #(1) use early stopping
    log="../results/parallel_ksp_performance/$g""_early_stopping_$t"".log"
    #first run using 1 thread
    cmake -DCMAKE_C_COMPILER=/usr/bin/gcc-5 -DCMAKE_CXX_COMPILER=/usr/bin/g++-5 -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=$t" ..
    cmake --build . --target ksp_performance
    numactl --cpunodebind=1 --membind=1 ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
    #(2) don’t use early stopping (do not iterate over K in this case and only use 1 thread)
    log="../results/parallel_ksp_performance/$g""_no_early_stopping_$t"".log"
    #first run using 1 thread
    cmake -DCMAKE_C_COMPILER=/usr/bin/gcc-5 -DCMAKE_CXX_COMPILER=/usr/bin/g++-5 -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=$t -DNO_SSSP_EARLY_STOPPING" ..
    cmake --build . --target ksp_performance
    numactl --cpunodebind=1 --membind=1 ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
  done

  #use random graphs
  for g in ${g_random[@]}
  do
    #(1) use early stopping
    log="../results/parallel_ksp_performance/$g""_early_stopping_$t"".log"
    #first run using 1 thread
    cmake -DCMAKE_C_COMPILER=/usr/bin/gcc-5 -DCMAKE_CXX_COMPILER=/usr/bin/g++-5 -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=$t" ..
    cmake --build . --target ksp_performance
    numactl --cpunodebind=1 --membind=1 ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
    #(2) don’t use early stopping (do not iterate over K in this case and use 1 thread only)
    log="../results/parallel_ksp_performance/$g""_no_early_stopping_$t"".log"
    #first run using 1 thread
    cmake -DCMAKE_C_COMPILER=/usr/bin/gcc-5 -DCMAKE_CXX_COMPILER=/usr/bin/g++-5 -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=$t -DNO_SSSP_EARLY_STOPPING" ..
    cmake --build . --target ksp_performance
    numactl --cpunodebind=1 --membind=1 ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
  done
done
