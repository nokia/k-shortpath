//
// Created by Alex Schickedanz <alex@ae.cs.uni-frankfurt.de> on 25.03.17.
//

#include <Dijkstra.h>
#include <GraphRW.h>
#include <DeltaSteppingDynamic.h>
#include <DeltaSteppingStatic.h>
#include <ctime>
#include <chrono>

/**
 * Compares the implementations of Dijkstra's algorithm and sequential delta stepping.
 * It prints the results as a JSON object with leading comma. If multiple runs are
 * concatenated in a file one can just remove the first leading comma and add "[" and "]"
 * to the beginning and end of the file to get a JSON list.
 * @param argc
 * @param argv
 * @return
 */
int main(int argc, char** argv)
{
#if defined(PROF) && !defined(KSP_PARALLEL_DEVIATIONS_L2)
    ProfilerStatistics profiler_statistics;
#endif

    // parse input
    if(argc < 2)
    {
        std::cout << "Arguments:" << std::endl
                  << " [1] path to a edgelist file" << std::endl
                  << " [2] delta for delta stepping (default is 0.1)" << std::endl
                  << " [3] number of runs (default is 10)" << std::endl;
        exit(0);
    }

    constexpr double ms = 1000.0;

    auto* delta = const_cast<char*>("0.1");
    if(argc > 2)
        delta = argv[2];

    unsigned int runs = 10;
    if(argc > 3)
        runs = static_cast<unsigned int>(strtol(argv[3], nullptr, 0));

    // read file
    using GraphType = BasicGraph<false, true>;
    const auto G = GraphRW::read_graph<false, true, true>(argv[1], delta, GraphRW::file_type::METIS, GraphRW::weight_converting::ORIGINAL);

    // separate edges into light and heavy edges according to delta.

    KSPGraph<GraphType> K(G);

    srand(static_cast<unsigned int>(time(nullptr)));

    for(unsigned int i = 0; i < runs; ++i)
    {
        // generate random source and target
        NODE_ID source = rand() % G.get_num_nodes(),
                destination = rand() % G.get_num_nodes();

        // make sure source and destination are not the same
        while(source == destination)
            destination = rand() % G.get_num_nodes();

        // run Dijkstra without destination
        Dijkstra<GraphType> d(K.get_original_graph());
        auto start = std::chrono::high_resolution_clock::now();
        d.template compute_sssp<true>(source, destination);
        auto d_time =
                std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::high_resolution_clock::now() - start)
                        .count() / ms;

        K.restore_graph();

        // run Dijkstra without destination
        Dijkstra<GraphType> d2(K.get_original_graph());
        start = std::chrono::high_resolution_clock::now();
        d2.template compute_sssp<false>(source);
        auto d_wod_time =
                std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::high_resolution_clock::now() - start)
                        .count() / ms;

        K.restore_graph();

        // run list delta stepping
        DeltaSteppingStatic<GraphType> lds(K, 1);
        start = std::chrono::high_resolution_clock::now();
        lds.template compute<true>(
#if defined(PROF) && !defined(KSP_PARALLEL_DEVIATIONS_L2)
            profiler_statistics,
#endif
            source, destination);

        auto lds_time =
                std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::high_resolution_clock::now() - start)
                        .count() / ms;

        K.restore_graph();

        // run list delta stepping
        DeltaSteppingStatic<GraphType> lds2(K, 1);
        start = std::chrono::high_resolution_clock::now();
        lds2.template compute<false>(
#if defined(PROF) && !defined(KSP_PARALLEL_DEVIATIONS_L2)
            profiler_statistics,
#endif
            source);

        auto lds_wod_time =
                std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::high_resolution_clock::now() - start)
                        .count() / ms;

        K.restore_graph();

        // run array delta stepping
        DeltaSteppingDynamic<GraphType> ads(K, 1);
        start = std::chrono::high_resolution_clock::now();
        ads.template compute<true>(
#if defined(PROF) && !defined(KSP_PARALLEL_DEVIATIONS_L2)
            profiler_statistics,
#endif
            source, destination);

        auto ads_time =
                std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::high_resolution_clock::now() - start)
                        .count() / ms;

        K.restore_graph();

        // run array delta stepping
        DeltaSteppingDynamic<GraphType> ads2(K, 1);
        start = std::chrono::high_resolution_clock::now();
        ads2.template compute<false>(
#if defined(PROF) && !defined(KSP_PARALLEL_DEVIATIONS_L2)
            profiler_statistics,
#endif
            source);

        auto ads_wod_time =
                std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::high_resolution_clock::now() - start)
                        .count() / ms;

        K.restore_graph();

        // print out the results as a JSON object with leading comma.
        printf(",{\"source\":%u,\"destination\":%u,\"delta\":%s,\"w_time_dijkstra_early_stop\":%.3f,\"w_time_dijkstra\":%.3f,\"w_time_delta_stepping_static_early_stop\":%.3f,\"w_time_delta_stepping_static\":%.3f,\"w_time_delta_stepping_dynamic_early_stop\":%.3f,\"w_time_delta_stepping_dynamic\":%.3f}\n",
               source, destination, delta, d_time, d_wod_time, lds_time, lds_wod_time, ads_time, ads_wod_time);
    }

    return 0;
}
