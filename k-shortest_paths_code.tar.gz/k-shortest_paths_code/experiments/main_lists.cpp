#include <DeltaSteppingStatic.h>
#include <omp.h>
#include <cstring>

/**************************
Arguments:
	[1] edge file
	[2] source
	[3] destination
	[4] delta value, or -max_degree, -avg_edge_weight, -D (for Dijkstra), -BF (for Bellmann-Ford)
	[5] number of threads
***************************/

using namespace std;

int main(int argc, char **argv)
{
    srand(1234567);
    if(argc < 6)
    {
        cout << "Input arguments:" << endl;
        cout << "[1] edge file" << endl;
        cout << "[2] weight type: -orig(for original weights), -float(for floating point type)" << endl;
        cout << "[3] source node" << endl;
        cout << "[4] destination node" << endl;
        cout << "[5] delta value, or -max_degree, -avg_edge_weight, -D (for Dijkstra), -BF (for Bellmann-Ford)" << endl;
        cout << "[6] number of threads" << endl;
        exit(0);
    }

    char *file = argv[1];
    NODE_ID source = static_cast<NODE_ID>(atoi(argv[3]));
    NODE_ID destination = static_cast<NODE_ID>(atoi(argv[4]));
    unsigned int no_threads = static_cast<unsigned int>(atoi(argv[6]));
    char *d = argv[5];

    weight_converting w;
    if(strcmp(argv[2], "-orig") == 0)
    {
        w = ORIGINAL;
        cerr << "using original weights" << endl;
    }
    else if(strcmp(argv[2], "-float") == 0)
    {
        w = FLOATING;
        cerr << "using floating point weights" << endl;
    }
    else
    {
        cerr << "wrong edge type" << endl;
        exit(0);
    }

    cout << "delta value: " << d << endl;
    double t_time = 0;
    unsigned int rounds = 1;
    BasicGraph myGraph(file, BasicGraph::EDGELIST, w, false);
    myGraph.precompute_light_heavy_edges(d);

    KSPGraph ksp_graph(myGraph);
    for(unsigned int i=0; i<rounds; i++){
        DeltaSteppingStatic ds(ksp_graph, no_threads);
        double t1 = omp_get_wtime();
        cout << "Source is " << source << " Destination is " << destination << endl;
        ds.compute(source, destination);
        double t2 = omp_get_wtime() - t1;
        cout << t2 << endl;
        t_time += t2;
        ds.get_sssp_tree().print_path(source, destination);
    }

    cout << "avg time:	" << t_time / rounds << endl;
}
