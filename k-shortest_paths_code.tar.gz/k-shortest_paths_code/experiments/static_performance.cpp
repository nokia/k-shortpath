#include <DeltaSteppingStatic.h>
#include <GraphRW.h>

/**************************
Arguments:
	[1] edge file
	[2] source
	[3] destination
	[4] delta value, or -max_degree, -avg_edge_weight, -D (for Dijkstra), -BF (for Bellmann-Ford)
	[5] number of threads
***************************/

using namespace std;

string generateOutput(const NODE_ID source, const NODE_ID destination, const char* delta, const int threads, const double duration)
{
    return ",{\"source\":" + to_string(source)
            + ",\"destination\":" + to_string(destination)
            + ",\"num_threads\":" + to_string(threads)
            + ",\"sssp_algo\":\"" + "static" + "\""
            + ",\"delta\":\"" + delta + "\""
            + ",\"duration\":" + to_string(duration)
            + "}\n";
}

int main(int argc, char** argv)
{
#ifdef PROF
    ProfilerStatistics profiler_statistics;
#endif
    srand(1234567);
    if(argc < 4)
    {
        cout << "Input arguments:" << endl
             << "[1] edge file" << endl
             << "[2] run number" << endl      // todo remove this option
             << "[3] delta value, or -max_degree, -avg_edge_weight, -D (for Dijkstra), -BF (for Bellmann-Ford)" << endl
             << "[4] number of threads" << endl;
        exit(0);
    }

    constexpr double ms = 1000.0;
    char* file = argv[1];
    int run = atoi(argv[2]);
    char* d = argv[3];
    auto num_threads = static_cast<unsigned int>(strtol(argv[4], nullptr, 0));

    GraphRW::weight_converting w;
    w = GraphRW::weight_converting::ORIGINAL;

    unsigned int runs = 5;
    using GraphType = BasicGraph<false, true>;//(undirected,weighted)
    const auto G = GraphRW::read_graph<false, true>(file, d, GraphRW::file_type::EDGELIST, w);

    std::default_random_engine generator(12345);
    std::uniform_int_distribution<NODE_ID> node_distribution(1, G.get_num_nodes()-1);

    //generate 50 random sources and targets
    vector<NODE_ID> srcs,dests;
    for(unsigned int i=0; i<50; i++){
      srcs.push_back(node_distribution(generator));
      dests.push_back(node_distribution(generator));
    }

    KSPGraph<GraphType> myGraph(G);

    for(unsigned int i = 0; i < runs; i++)
    {
        DeltaSteppingStatic<GraphType> ds(myGraph, num_threads);
        NODE_ID source = srcs[i+(runs*run)];
        NODE_ID destination = dests[i+(runs*run)];
        auto start = std::chrono::high_resolution_clock::now();
        ds.compute(
#ifdef PROF
            profiler_statistics,
#endif
            source, destination);

        auto d_time = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::high_resolution_clock::now() - start)
                        .count() / ms;

	cout << generateOutput(source, destination,d,num_threads,d_time);
    }
}
