#ifdef KSP_PARALLEL_DEVIATIONS_L1
    #define KSP_PD_L1 true
#else
    #define KSP_PD_L1 false
#endif

#include "Katoh.h"
#include "Yen.h"
#include "OptYen.h"
#include "Feng.h"
#include "GraphRW.h"
#include "test_tools.h"
#include <cstring>

using namespace std;

#ifndef KSP_NUM_THREADS
    #define KSP_NUM_THREADS 1
#endif

#if defined(KSP_PARALLEL_DEVIATIONS_L2) || defined(KSP_PARALLEL_DEVIATIONS_L1)
    #define KSP_PD true
#else
    #define KSP_PD false
#endif

#ifdef PROF
string generateOutputProf(const NODE_ID source, const NODE_ID destination, const string& ksp_algo, const string& sssp_algo,
                          const char* delta, const unsigned int k, const string& profiling)
{
    return ",{\"source\":" + to_string(source)
           + ",\"destination\":" + to_string(destination)
           + ",\"ksp_algo\":\"" + ksp_algo + "\""
           + ",\"sssp_algo\":\"" + sssp_algo + "\""
           + ",\"delta\":\"" + delta + "\""
           + ",\"k\":" + to_string(k)
           + "," + profiling
           + "}\n";
}
#endif

string generateOutput(const NODE_ID source, const NODE_ID destination, const string& ksp_algo, const string& sssp_algo, const char* delta, const unsigned int k, const double duration)
{
    return ",{\"source\":" + to_string(source)
            + ",\"destination\":" + to_string(destination)
            + ",\"num_threads\":" + to_string(KSP_NUM_THREADS)
#ifdef KSP_PARALLEL_DEVIATIONS_L2
            + ",\"L2 parallel_deviations\":true"
#else
            + ",\"L2 parallel_deviations\":false"
#endif
#if KSP_PD_L1
            + ",\"L1 parallel deviations\":true"
#else
            + ",\"L1 parallel deviations\":false"
#endif
            + ",\"ksp_algo\":\"" + ksp_algo + "\""
            + ",\"sssp_algo\":\"" + sssp_algo + "\""
            + ",\"delta\":\"" + delta + "\""
            + ",\"k\":" + to_string(k)
            + ",\"duration\":" + to_string(duration)
            + "}\n";
}

int main(int argc, char** argv)
{
    if(argc < 5)
    {
        cout << "input arguments:" << endl
             << "[ 1] edge file in metis format" << endl
             << "[ 2] run number" << endl    // todo add other weight converting options and check if they are working right.
             << "[ 3] graph file type: METIS or EDGELIST" << endl
             << "[ 4] num of paths" << endl
             << "optional: (if not included default is all ksps using dynamic delta stepping with delta = 0.1 and psp parallelisation)"
             << endl
             << "[ 5] ksp algo: Katoh, Yen, OptYen, Feng or All" << endl
             << "[ 6] sssp alg: dynamic (dynamic delta stepping) or static (static delta stepping) or All" << endl
             << "[ 7] delta value" << endl << endl
             << "compiler parameters" << endl
             << "-DKSP_NUM_THREADS=(int): number of threads (default is 1)" << endl
             << "-DKSP_PARALLEL_DEVIATIONS_L1: using level 1 parallel deviations" << endl
             << "-DKSP_PARALLEL_DEVIATIONS_L2: using level 2 parallel deviations" << endl;
        exit(0);
    }

    // parse input
    char* file = argv[1];
    GraphRW::weight_converting w;
    w = GraphRW::weight_converting::ORIGINAL;
    int run = atoi(argv[2]);   

    GraphRW::file_type ft;
    if(strcmp(argv[3], "METIS") == 0)
    {
        ft = GraphRW::file_type::METIS;
    }
    else if(strcmp(argv[3], "EDGELIST") == 0)
    {
        ft = GraphRW::file_type::EDGELIST;
    }
    else
    {
        cerr << "wrong graph file type." << endl;
        exit(1);
    }

    //const auto src = static_cast<NODE_ID>(strtol(argv[3], nullptr, 0));
    //const auto dest = static_cast<NODE_ID>(strtol(argv[4], nullptr, 0));
    const auto num_paths = static_cast<unsigned int>(strtol(argv[4], nullptr, 0));

    char all[] = "All";
    char default_delta[] = "0.1";
    char* ksp = all;    // default_ksp;
    char* sssp = all;   // default_sssp;
    char* delta = default_delta;

    omp_set_num_threads(KSP_NUM_THREADS);

    if(argc > 7)
    {
        ksp = argv[5];
        sssp = argv[6];

        if(argc < 8)
        {
            exit(0);
        }

        delta = argv[7];
    }

    // This is undirected and weighted. Since this are templates it cannot be changed by a commandline argument.
    using GraphType = BasicGraph<false, true>;
    auto G = GraphRW::read_graph<false, true>(file, delta, ft, w);

    std::default_random_engine generator(12345);
    std::uniform_int_distribution<NODE_ID> node_distribution(1, G.get_num_nodes()-1);

    //generate 50 random sources and targets
    vector<NODE_ID> srcs,dests;
    for(unsigned int i=0; i<50; i++){
      srcs.push_back(node_distribution(generator));
      dests.push_back(node_distribution(generator));
    }

    unsigned int runs = 5;
    string out;
    for(unsigned int i = 0; i < runs; i++)
    {
#ifndef PROF
        double start;
#endif
        NODE_ID src = srcs[i+(runs*run)];
        NODE_ID dest = dests[i+(runs*run)];

        if(!strcmp(sssp, all) || !strcmp(sssp, "dynamic"))
        {
            if(!GraphType::is_directed && (!strcmp(ksp, all) || !strcmp(ksp, "Katoh")))
            {
                Katoh<DeltaSteppingDynamic, GraphType, KSP_NUM_THREADS, KSP_PD> katoh(G, num_paths);
#ifndef PROF
                start = omp_get_wtime();
#endif

                katoh.compute(src, dest);
#ifdef PROF
                cout << generateOutputProf(src, dest, "Katoh", "dynamic", delta, num_paths, katoh.return_stats());
#else
                cout << generateOutput(src, dest, "Katoh", "dynamic", delta, num_paths, omp_get_wtime() - start);
#endif
            }

            if(!strcmp(ksp, all) || !strcmp(ksp, "Yen"))
            {
                Yen<DeltaSteppingDynamic, GraphType, KSP_NUM_THREADS, KSP_PD> yen(G, num_paths);

#ifndef PROF
                start = omp_get_wtime();
#endif

                yen.compute(src, dest);
#ifdef PROF
                cout << generateOutputProf(src, dest, "Yen", "dynamic", delta, num_paths, yen.return_stats());
#else
                cout << generateOutput(src, dest, "Yen", "dynamic", delta, num_paths, omp_get_wtime() - start);
#endif
            }

            if(!strcmp(ksp, all) || !strcmp(ksp, "OptYen"))
            {
                OptYen<DeltaSteppingDynamic, GraphType, KSP_NUM_THREADS, KSP_PD> optyen(G, num_paths);
#ifndef PROF
                start = omp_get_wtime();
#endif

                optyen.compute(src, dest);
#ifdef PROF
                cout << generateOutputProf(src, dest, "OptYen", "dynamic", delta, num_paths, optyen.return_stats());
#else
                cout << generateOutput(src, dest, "OptYen", "dynamic", delta, num_paths, omp_get_wtime() - start);
#endif
            }

            if(!strcmp(ksp, all) || !strcmp(ksp, "Feng"))
            {
                Feng<DeltaSteppingDynamic, GraphType, KSP_NUM_THREADS, KSP_PD> feng(G, num_paths);
#ifndef PROF
                start = omp_get_wtime();
#endif
                feng.compute(src, dest);
#ifdef PROF
                cout << generateOutputProf(src, dest, "Feng", "dynamic", delta, num_paths, feng.return_stats());
#else
                cout << generateOutput(src, dest, "Feng", "dynamic", delta, num_paths, omp_get_wtime() - start);
#endif
            }
        }
        if(!strcmp(sssp, all) || !strcmp(sssp, "static"))
        {
            if(!GraphType::is_directed && (!strcmp(ksp, all) || !strcmp(ksp, "Katoh")))
            {
                Katoh<DeltaSteppingStatic, GraphType, KSP_NUM_THREADS, KSP_PD> katoh(G, num_paths);
#ifndef PROF
                start = omp_get_wtime();
#endif

                katoh.compute(src, dest);
#ifdef PROF
                cout << generateOutputProf(src, dest, "Katoh", "static", delta, num_paths, katoh.return_stats());
#else
                cout << generateOutput(src, dest, "Katoh", "static", delta, num_paths, omp_get_wtime() - start);
#endif
            }

            if(!strcmp(ksp, all) || !strcmp(ksp, "Yen"))
            {
                Yen<DeltaSteppingStatic, GraphType, KSP_NUM_THREADS, KSP_PD> yen(G, num_paths);
#ifndef PROF
                start = omp_get_wtime();
#endif

                yen.compute(src, dest);
#ifdef PROF
                cout << generateOutputProf(src, dest, "Yen", "static", delta, num_paths, yen.return_stats());
#else
                cout << generateOutput(src, dest, "Yen", "static", delta, num_paths, omp_get_wtime() - start);
#endif
            }

            if(!strcmp(ksp, all) || !strcmp(ksp, "OptYen"))
            {
                OptYen<DeltaSteppingStatic, GraphType, KSP_NUM_THREADS, KSP_PD> optyen(G, num_paths);
#ifndef PROF
                start = omp_get_wtime();
#endif

                optyen.compute(src, dest);
#ifdef PROF
                cout << generateOutputProf(src, dest, "OptYen", "static", delta, num_paths, optyen.return_stats());
#else
                cout << generateOutput(src, dest, "OptYen", "static", delta, num_paths, omp_get_wtime() - start);
#endif
            }

            if(!strcmp(ksp, all) || !strcmp(ksp, "Feng"))
            {
                Feng<DeltaSteppingStatic, GraphType, KSP_NUM_THREADS, KSP_PD> feng(G, num_paths);
#ifndef PROF
                start = omp_get_wtime();
#endif

                feng.compute(src, dest);

#ifdef PROF
                cout << generateOutputProf(src, dest, "Feng", "static", delta, num_paths, feng.return_stats());
#else
                cout << generateOutput(src, dest, "Feng", "static", delta, num_paths, omp_get_wtime() - start);
#endif
            }
        }
    }
}
