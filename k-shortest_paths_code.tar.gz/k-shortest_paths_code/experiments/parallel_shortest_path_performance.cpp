
#include <GraphRW.h>
#include <DeltaSteppingDynamic.h>
#include <DeltaSteppingStatic.h>
#include <ctime>
#include <chrono>

/**
 * Tests parallel performance of dynamic and static delta stepping.
 * It prints the results as a JSON object with leading comma. If multiple runs are
 * concatenated in a file one can just remove the first leading comma and add "[" and "]"
 * to the beginning and end of the file to get a JSON list.
 * @param argc
 * @param argv
 * @return
 */
int main(int argc, char** argv)
{
    // parse input
    if(argc < 2)
    {
        std::cout << "Arguments:" << std::endl
                  << " [1] path to a edgelist file" << std::endl
                  << " [2] delta for delta stepping (default is 0.1)" << std::endl
		  << " [3] number of threads (default is 1)" << std::endl
                  << " [4] number of runs (default is 10)" << std::endl
		  << " [5] src (default random source)" <<std::endl
		  << " [6] dest (default rnadom dest)" <<std::endl;
        exit(0);
    }

    constexpr double ms = 1000.0;

    char* delta = const_cast<char*>("0.1");
    if(argc > 2)
        delta = argv[2];

    unsigned int t = 1;
    if(argc > 3)
	t = static_cast<unsigned int>(atol(argv[3]));

    unsigned int runs = 10;
    if(argc > 4)
        runs = static_cast<unsigned int>(atol(argv[4]));

    NODE_ID source = 0, destination = 0;
    if(argc > 5) source = static_cast<NODE_ID>(atol(argv[5]));

    if(argc > 6) destination = static_cast<NODE_ID>(atol(argv[6]));

    // read file
    using GraphType = BasicGraph<false, true>;
    const auto G = GraphRW::read_graph<false, true,false>(argv[1], delta, GraphRW::file_type::EDGELIST, GraphRW::weight_converting::ORIGINAL);

    // separate edges into light and heavy edges according to delta.
    auto start = std::chrono::high_resolution_clock::now();
    KSPGraph<GraphType> K(G);
    auto precomputation_time = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::high_resolution_clock::now() - start).count() / ms;


    srand(time(NULL));

    for(unsigned int i = 0; i < runs; ++i)
    {
        // generate random source and target
	if(argc < 6) source = rand() % G.get_num_nodes();
        if(argc < 7) destination = rand() % G.get_num_nodes();

        // make sure source and destination are not the same
        while(source == destination)
            destination = rand() % G.get_num_nodes();

        // run list delta stepping
	DeltaSteppingStatic<GraphType> lds(K, t, K.get_num_nodes());
        start = std::chrono::high_resolution_clock::now();
        lds.compute(source, destination);
        auto lds_time =
                std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::high_resolution_clock::now() - start)
                        .count() / ms;

        K.restore_graph();

        // run array delta stepping
	DeltaSteppingDynamic<GraphType> ads(K, t, K.get_num_nodes());
        start = std::chrono::high_resolution_clock::now();
        ads.compute(source, destination);
        auto ads_time =
                std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::high_resolution_clock::now() - start)
                        .count() / ms;

        // print out the results as a JSON object with leading comma.
        printf(",{\"source\":%u,\"destination\":%u,\"threads\":%u,\"delta\":%s,\"static_delta_stepping\":%.3f,\"dynamic_delta_stepping\":%.3f,\"precomputation_time\":%.3f}\n",
               source, destination, t, delta, lds_time, ads_time, precomputation_time);
    }

    return 0;
}
