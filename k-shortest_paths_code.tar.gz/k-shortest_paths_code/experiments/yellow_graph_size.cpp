//
// Created by Alex Schickedanz <alex@ae.cs.uni-frankfurt.de> on 23.03.17.
//
#include "Feng.h"
#include <ctime>

#ifdef UNDIRECTED
    #define DIRECTED false
#else
    #define DIRECTED true
#endif

#ifdef UNWEIGHTED
    #define WEIGHTED false
#else
    #define WEIGHTED true
#endif

#ifndef POWER_LAW_EXPONENT
    #if WEIGHTED
        #define POWER_LAW_EXPONENT 3
    #else
        #define POWER_LAW_EXPONENT 0
    #endif
#endif

/**
 * Collects some statistics about the size of the yellow graph in Feng's algorithm and
 * and how the shortest paths behave (number of hops, length, shared nodes, ...).
 * The output is formatted as JSON object, with a leading comma. So if multiple runs are
 * concatenated in a file, one can easily make a JSON list out of it by removing just the
 * first comma and adding "[" and "]" to the beginning and end of the file.
 * @param argc
 * @param argv
 * @return
 */
int main(int argc, char** argv)
{
    using GraphType = BasicGraph<DIRECTED, WEIGHTED>;

    // parse input
    if(argc < 2)
    {
        std::cout << "Arguments:" << std::endl
                  << " [1] path to a metis file" << std::endl
                  << " [2] number of runs (optional, default is 1)" << std::endl
                  << " [3] weight distribution: use " << std::endl
                  << "     -orig (default) to change nothing" << std::endl
                  << "     -exp to convert uniform to exponential weights" << std::endl
                  << "     -pl to convert uniform to power law weights" << std::endl
                  << " [4] k (optional, default is 10)" << std::endl << std::endl
                  << "Compile with " << std::endl
                  << "-DUNDIRECTED for undirected graphs" << std::endl
                  << "-UNWEIGHTED for unweighted graphs" << std::endl
                  << "-DPOWER_LAW_EXPONENT <int> to set the power law exponent if the weights are changed to power law distribution (default is 3).";
        exit(0);
    }

    unsigned int runs = 1;
    if(argc > 2)
        runs = static_cast<unsigned int>(strtol(argv[2], nullptr, 0));

    GraphRW::weight_converting w_conv = GraphRW::weight_converting::ORIGINAL;

    if(!WEIGHTED)
    {
        std::cerr << "Unweighted" << std::endl;
    }
    else if(argc > 3)
    {
        if(strcmp(argv[3], "-exp") == 0)
        {
            std::cerr << "Exponential weights" << std::endl;
            w_conv = GraphRW::weight_converting::EXPONENTIAL;
        }
        else if(strcmp(argv[3], "-pl") == 0)
        {
            std::cerr << "Powerlaw weights" << std::endl;
            w_conv = GraphRW::weight_converting::POWER_LAW;
        }
        else
            std::cerr << "Uniform random weights" << std::endl;
    }

    unsigned int k = 10;
    if(argc > 4)
        k = static_cast<unsigned int>(strtol(argv[4], nullptr, 0));

    const GraphType G = GraphRW::read_graph<DIRECTED, WEIGHTED, true, POWER_LAW_EXPONENT>(argv[1], const_cast<char*>("0.1"), GraphRW::file_type::METIS, w_conv);

    srand (static_cast<unsigned int>(time(nullptr)));

    std::cerr << "|";
    for(unsigned int i = 0; i < runs; i++)
    {
        while(true)
        {
            try
            {
                NODE_ID source      = rand() % G.get_num_nodes(),
                        destination = rand() % G.get_num_nodes();

                // make sure source and destination are not the same
                while(source == destination)
                    destination = rand() % G.get_num_nodes();

                Feng<DeltaSteppingDynamic, GraphType, 1, false> ksp(G, k);
                std::vector<Path> paths = ksp.compute(source, destination);

                auto stats = ksp.get_stats();

                stats.print_as_JSON();

                break;
            }
            catch(NoPathException& e)
            {
                std::cerr << "+";
                continue;
            }
        }
        std::cerr << "=";
    }
    std::cerr << "|" << std::endl;

    return 0;
}