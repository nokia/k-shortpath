#include <DeltaSteppingDynamic.h>
#include <GraphRW.h>

/**************************
Arguments:
	[1] edge file
	[2] source
	[3] destination
	[4] delta value, or -max_degree, -avg_edge_weight, -D (for Dijkstra), -BF (for Bellmann-Ford)
	[5] number of threads
***************************/

using namespace std;

int main(int argc, char** argv)
{
#ifdef PROF
    ProfilerStatistics profiler_statistics;
#endif

    srand(1234567);
    if(argc < 5)
    {
        cout << "Input arguments:" << endl
             << "[1] binary file" << endl
             << "[2] weight type, -orig (for original weights)" << endl    // todo remove this option
             << "[3] source node" << endl
             << "[4] destination node" << endl
             << "[5] delta value, or -max_degree, -avg_edge_weight, -D (for Dijkstra), -BF (for Bellmann-Ford)" << endl
             << "[6] number of threads" << endl;
    }
    else
    {

        constexpr double ms = 1000.0;
        char* file = argv[1];
        auto source = static_cast<NODE_ID>(strtol(argv[3], nullptr, 0));
        auto destination = static_cast<NODE_ID>(strtol(argv[4], nullptr, 0));
        auto num_threads = static_cast<unsigned int>(strtol(argv[6], nullptr, 0));
        char* d = argv[5];

        unsigned int rounds = 1;
        GraphRW::weight_converting w;
        if(strcmp(argv[2], "-orig") == 0)
        {
            w = GraphRW::weight_converting::ORIGINAL;
        }
        else
        {
            cerr << "Wrong edge type!" << endl;
            cerr << argv[2] << endl;
            exit(1);
        }

        using GraphType = BasicGraph<false, true>;//(undirected,weighted)
        const auto G = GraphRW::read_graph<false, true>(file, d, GraphRW::file_type::EDGELIST, w);

        auto start = std::chrono::high_resolution_clock::now();
        KSPGraph<GraphType> myGraph(G);
        auto precomputation_time = std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::high_resolution_clock::now() - start).count() / ms;

        for(unsigned int i = 0; i < rounds; i++)
        {
            DeltaSteppingDynamic<GraphType> ds(myGraph, num_threads);
            start = std::chrono::high_resolution_clock::now();
            ds.compute(source, destination);
            auto d_time = std::chrono::duration_cast<std::chrono::milliseconds>(
                            std::chrono::high_resolution_clock::now() - start)
                            .count() / ms;

            ds.get_sssp_tree().print_path(source, destination);

            cout << "precomputation time: " << precomputation_time << endl;
            cout << "ds time: " << d_time << endl;
        }
    }
}
