#include <DeltaSteppingDynamic.h>
#include <cstring>

/**************************
Arguments:
	[1] edge file
	[2] source
	[3] destination
	[4] delta value, or -max_degree, -avg_edge_weight, -D (for Dijkstra), -BF (for Bellmann-Ford)
	[5] number of threads
***************************/

using namespace std;

int main(int argc, char** argv){
  srand(1234567);
  if(argc < 5){
    cout<<"Input arguments:"<<endl;
    cout<<"[1] edge file"<<endl;
    cout<<"[2] weight type, -orig (for original weights), -float (for floating point weights)"<<endl;
    cout<<"[3] source node"<<endl;
    cout<<"[4] destination node"<<endl;
    cout<<"[5] delta value, or -max_degree, -avg_edge_weight, -D (for Dijkstra), -BF (for Bellmann-Ford)"<<endl;
    cout<<"[6] number of threads"<<endl;
  }else{

    char *file = argv[1];
    NODE_ID source = atoi(argv[3]);
    NODE_ID destination = atoi(argv[4]);
    int no_threads = atoi(argv[6]);
    char *d = argv[5];

    double final_time = 0;
    //Graph myGraph;
    unsigned int rounds = 1;
    weight_converting w;
    if(strcmp(argv[2],"-orig") == 0){
	w = ORIGINAL;
	cerr<<"using original weights"<<endl;
    }else if(strcmp(argv[2],"-float") == 0){
	w = FLOATING;
	cerr<<"using floating point weights"<<endl;
    }else{
	cerr<<"Wrong edge type!"<<endl;
	cerr<<argv[2]<<endl;
	exit(0);
    }
    BasicGraph bGraph(file,BasicGraph::EDGELIST,w,false);
    bGraph.precompute_light_heavy_edges(d);

    KSPGraph myGraph(bGraph);
    for(unsigned int i=0; i<rounds; i++){
      DeltaSteppingDynamic ds(myGraph, no_threads);
      double t1 = omp_get_wtime();
      ds.compute(source, destination);
      double t2 = omp_get_wtime()-t1;
      final_time += t2;
      cout<<t2<<endl;
      ds.get_sssp_tree().print_path(source,destination);
    }
    cout<<"avg time:\t"<<final_time/rounds<<endl;
  }
}
