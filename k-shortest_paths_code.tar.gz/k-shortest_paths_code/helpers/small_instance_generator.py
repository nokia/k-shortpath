import networkit as nk
import random
import os
import sys

num_nodes = 15

def extractLargestComponent(G):
    """Extracts largest component from the graph provided and returns
    the induced subgraph. Node ids are mapped to a continuous range."""
    cc = nk.components.ConnectedComponents(G).run()
    index, size = max(cc.getComponentSizes().items(), key=lambda x: x[1])
    subG = G.subgraphFromNodes(cc.getPartition().getMembers(index))
    mapping = nk.graph.GraphTools.getContinuousNodeIds(subG)
    return nk.graph.GraphTools.getCompactedGraph(subG, mapping)


def assignRandomWeights(G):
    """Returns a weighted graph with edge weights drawn iid
    uniformly at random form [0;1]"""
    newG = nk.graph.Graph(weighted=True)
    newG.append(G)
    for u, v in newG.edges():
        newG.setWeight(u, v, (u != v) * random.random())
    return newG

# Generate a hyperbolic network with num_nodes nodes
G = nk.generators.HyperbolicGenerator(random.randint(40, 150)).generate()

# G = nk.generators.ErdosRenyiGenerator(random.randint(6, 30), random.uniform(0.15, 0.4), directed=False).generate()

# Extract its largest connected component and assign uniform random weights
largestCC = extractLargestComponent(G)
weightedGraph = assignRandomWeights(largestCC)


# write graph
graphWriter = nk.graphio.METISGraphWriter()
graphWriter.write(weightedGraph, os.path.dirname(os.path.realpath(__file__)) + "/../resources/small_instance_" + str(sys.argv[1]) + ".metis")
# write distances
f = open(os.path.dirname(os.path.realpath(__file__)) + "/../resources/small_instance_" + str(sys.argv[1]) + ".dists", 'w+')
dists = nk.graph.Dijkstra(weightedGraph, 0)
dists.run()

for dist in dists.getDistances():
    f.write('{0:f}\n'.format(dist))

f.close()