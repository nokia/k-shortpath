import networkit as nk
import random
import os

num_nodes = 2 * int(input('Number of nodes: '))
filename = input('File name: ')

def extractLargestComponent(G):
    """Extracts largest component from the graph provided and returns
    the induced subgraph. Node ids are mapped to a continuous range."""
    cc = nk.components.ConnectedComponents(G).run()
    index, size = max(cc.getComponentSizes().items(), key=lambda x: x[1])
    subG = G.subgraphFromNodes(cc.getPartition().getMembers(index))
    mapping = nk.graph.GraphTools.getContinuousNodeIds(subG)
    return nk.graph.GraphTools.getCompactedGraph(subG, mapping)


def assignRandomWeights(G):
    """Returns a weighted graph with edge weights drawn iid
    uniformly at random form [0;1]"""
    newG = nk.graph.Graph(weighted=True)
    newG.append(G)
    for u, v in newG.edges():
        newG.setWeight(u, v, (u != v) * random.random())
    return newG

# Generate a hyperbolic network with num_nodes nodes
G = nk.generators.HyperbolicGenerator(num_nodes).generate()

# Extract its largest connected component and assign uniform random weights
largestCC = extractLargestComponent(G)
weightedGraph = assignRandomWeights(largestCC)
print("Number of nodes: {0:7d}\nNumber of edges: {1:7d}".format(weightedGraph.numberOfNodes(), weightedGraph.numberOfEdges()))


graphWriter = nk.graphio.METISGraphWriter()
graphWriter.write(weightedGraph, os.path.dirname(os.path.realpath(__file__)) + "/../resources/" + filename)
