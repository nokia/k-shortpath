#include <stdlib.h>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <cstring>
#include <sstream>
#include <limits>

using namespace std;

int main(int argc, char** argv) {
  if(argc < 2){
      cout<<"Input arguments:"<<endl;
      cout<<"./dimacs2edgefile file > output file"<<endl;
      exit(0);
    }

  char *infile = argv[1]; 

  string line;
  ifstream myFile;
  //first find min and max for normalisation
  double min = std::numeric_limits<double>::max();
  double max = 0.0;
  myFile.open(infile);
  if (myFile.is_open()) {
    while(true){
      getline(myFile, line);
      if(myFile.eof()) break;
      if(line[0]=='a'){
        std::stringstream ss(line);
        string ind1;
        long src,dest;
	double w;
        ss >> ind1 >> src >> dest >> w;
        if(w>max) max=w;
        if(w<min) min=w;
      }
    }
  }
  myFile.close();

  myFile.open(infile);
  if (myFile.is_open()) {
    while(true){
      getline(myFile, line);
      if(myFile.eof()) break;
      if(line[0]=='p'){
        std::stringstream ss(line);
        string ind1,ind2;
        long nodes;
        ss >> ind1 >> ind2 >> nodes;
        cout<<nodes<<endl;
      }else if(line[0]=='a'){
        std::stringstream ss(line);
        string ind1;
        long src,dest;
	double w;
        ss >> ind1 >> src >> dest >> w;
        double norm_w = (w-min)/(max-min);
        if(norm_w==1) norm_w = 0.99999999;
        //node ids start from 1 in dimacs format
        //we need to start from 0
        cout<<src-1<<" "<<dest-1<<" "<<norm_w<<endl;
        //this will remove the duplicate line
        getline(myFile, line);
        if(myFile.eof()) break;
      }
    }
  }
}
