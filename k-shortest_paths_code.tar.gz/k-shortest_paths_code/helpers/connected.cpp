#include "GraphRW.h"
#include <stdlib.h>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <sys/time.h>
#include <iomanip>
#include <cmath>
#include <cstring>
#include <vector>
#include <queue>

using namespace std;
//using GraphType = BasicGraph<false, true>;

template<typename GraphType>
class largest_comp{
  //using GraphType = BasicGraph<false, rue>;
  const GraphType& G;
  vector<NODE_ID> comp_size;
  long* c;
public:
  largest_comp(const GraphType& g)
	: G(g){
    //using GraphType = BasicGraph<false, true>;
    //G = GraphRW::read_graph<false, true>(file, 0.1, EDGELIST, GraphRW::weight_converting::ORIGINAL);
    c = new long[G.get_num_nodes()];
    for(NODE_ID i=0; i<G.get_num_nodes(); i++) c[i] = -1;

    int curr = -1;
    for(NODE_ID i=0; i<G.get_num_nodes(); i++){
      if(c[i] < 0){
	curr++;
	comp_size.push_back(0);
	//c[i] = curr;
	//comp_size[curr]++;
 	compute(i,curr);
      }
    }
    int l = find_largest();
    write_largest_comp(l);
  }

  ~largest_comp(){
    delete[] c;
    c = 0;
  }

  void compute(NODE_ID node, NODE_ID component){
    queue<NODE_ID> curr_comp;
    curr_comp.push(node);
    while(!curr_comp.empty()){
      int n = curr_comp.front();
      curr_comp.pop();
      if(c[n] != component){
        c[n] = component;
        comp_size[component]++;
        for(EDGE_ID i=G.get_edge_list_begin(n); i<G.get_edge_list_end(n); i++){
          NODE_ID ngh = G.get_edge(i).get_target();
          if(c[ngh] < 0) curr_comp.push(ngh);//compute(ngh,component);
        }
      }
    }
  }

  NODE_ID find_largest(){
    NODE_ID lc=0, largest=0;
    for(NODE_ID i=0; i<comp_size.size(); i++){
      if(comp_size[i] > largest){
	largest = comp_size[i];
    	lc = i;
      }
    }
    return lc;
  }

  vector<NODE_ID> renumber_nodes(int lc){
    vector<NODE_ID> dict(G.get_num_nodes(),0);
    NODE_ID val = 0;
    for(NODE_ID i=0 ; i<G.get_num_nodes(); i++){
      if(c[i] == lc){
 	dict[i] = val;
	val++;
      }
    }
    return dict;
  }

  void write_largest_comp(int lc){
    vector<NODE_ID> dictionary;
    if(comp_size[lc] < G.get_num_nodes())
      dictionary = renumber_nodes(lc);
    cout<<comp_size[lc]<<endl;
    vector<bool> written (G.get_num_edges(),false);
    for(NODE_ID i=0 ; i<G.get_num_nodes(); i++){
      if(c[i] == lc){
	for(EDGE_ID edge=G.get_edge_list_begin(i); edge< G.get_edge_list_end(i); edge++){
	  if(!written[edge]){
	    written[edge] = true;
	    written[G.get_backwards_edge_id(edge)] = true;
	    NODE_ID src = i;
	    NODE_ID dest = G.get_edge(edge).get_target();
	    if(comp_size[lc] < G.get_num_nodes()){
	      src = dictionary[src];
	      dest = dictionary[dest];
	    }
	    cout<<src<<" "<<dest<<" "<<G.get_edge(edge).get_weight()<<endl;
	  }
	}
      }
    }
  }
};

//input arguments input_filename output_filename
int main(int argc, char** argv) {
  if(argc < 2){
    cout<<"to run: ./connected <edge file> <METIS or EDGELIST> > <output location>"<<endl;
    return 0;
  }else{
    char *file = argv[1];
    GraphRW::file_type ft;
    if(strcmp(argv[2], "METIS") == 0)
    {
        ft = GraphRW::file_type::METIS;
    }
    else if(strcmp(argv[2], "EDGELIST") == 0)
    {
        ft = GraphRW::file_type::EDGELIST;
    }
    else
    {
        cerr << "wrong graph file type." << endl;
        exit(1);
    }

    char *delta = (char *) "0.1";
    using GraphType = BasicGraph<false, true>;
    auto g = GraphRW::read_graph<false, true>(file, delta, ft, GraphRW::weight_converting::ORIGINAL);
    largest_comp<GraphType> c(g);
  }
}

