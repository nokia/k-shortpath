import networkit as nk
import random
import os


def assignRandomWeights(G):
    """Returns a weighted graph with edge weights drawn id
    uniformly at random form [0;1]"""
    newG = nk.graph.Graph(weighted=True)
    newG.append(G)
    for u, v in newG.edges():
        newG.setWeight(u, v, (u != v) * random.random())
    return newG


def extractLargestComponent(G):
    """Extracts largest component from the graph provided and returns
    the induced subgraph. Node ids are mapped to a continuous range."""
    cc = nk.components.ConnectedComponents(G).run()
    index, size = max(cc.getComponentSizes().items(), key=lambda x: x[1])
    subG = G.subgraphFromNodes(cc.getPartition().getMembers(index))
    mapping = nk.graph.GraphTools.getContinuousNodeIds(subG)
    return nk.graph.GraphTools.getCompactedGraph(subG, mapping)

mio = 1000000

n = int(input('Number of nodes (mio): '))

print("started generating...")
G = nk.generators.HyperbolicGenerator(n * mio, 8, 3, 0).generate()

LargestComponent = extractLargestComponent(G)
print(G.size(), " -> ", LargestComponent.size())

G_weighted = assignRandomWeights(LargestComponent)
print("finished generating.")

path = os.path.dirname(os.path.realpath(__file__)) + "/../graphs/hyperbolic_{0:d}m_4.metis".format(n)
print("started writing the file: " + path)
gw = nk.graphio.METISGraphWriter()
gw.write(G_weighted, path)
print("finished writing the file.")
