import networkit as nk
import os
import copy


def getPathWeight(G, path):
    totalWeight = 0
    for i in range(0, len(path)-1):
        totalWeight += G.weight(path[i], path[i+1])

    return totalWeight


def pathIsSimple(path):
    for node in path:
        if path.count(node) > 1:
            return node

    return True


def getDeviationsOfPath(G_full, path, branchingNode, target, shortestPaths):
    G = copy.deepcopy(G_full)

    # remove all nodes before the branching node
    for u in path[:branchingNode]:
        neighbors = G.neighbors(u)
        for v in neighbors:
            G.removeEdge(u, v)
        G.removeNode(u)

    # find deviations
    deviations = []
    for i in range(branchingNode, len(path)-1):
        G.removeEdge(path[i], path[i+1])
        deviation = []
        while True:
            sssp = nk.graph.Dijkstra(G, path[i], True, False, target)
            sssp.run()
            if sssp.numberOfPaths(target) == 0:
                break

            deviation = path[:i] + sssp.getPath(target)

            newDeviation = True
            for shortestPath in shortestPaths:
                if shortestPath[1] == deviation:
                    G.removeEdge(shortestPath[1][shortestPath[1].index(path[i])], shortestPath[1][shortestPath[1].index(path[i])+1])
                    newDeviation = False
                    break

            if newDeviation or not G.neighbors(path[i]):
                break

        if deviation:
            deviations.append((getPathWeight(G_full, deviation), deviation, i))

    return deviations

graphFile = input("Graph file (METIS) (default: big_metis_file.graph): ") or "/../resources/big_metis_file.graph"
K = int(input("k (default: 10): ") or "10") - 1
source = int(input("Source (default: 1595): ") or "1595")
target = int(input("Target (default: 6325): ") or "6325")

G_full = nk.graphio.readGraph(os.path.dirname(os.path.realpath(__file__)) + "/../resources/big_metis_file.graph", nk.graphio.Format.METIS)

ssspFromSource = nk.graph.Dijkstra(G_full, source, True, False, target)
ssspFromSource.run()

# shortestPaths contains tuples: (distance, path, deviation node (pos in path))
shortestPaths = [(ssspFromSource.distance(target), ssspFromSource.getPath(target), 0, source)]
deviations = []

# k is the current index of shortest paths in shortestPaths
for k in range(0, K):
    # remove all preceding node
    G = copy.deepcopy(G_full)
    for u in shortestPaths[k][1][:shortestPaths[k][2]+1]:
        neighbors = G.neighbors(u)
        for v in neighbors:
            G.removeEdge(u, v)
        G.removeNode(u)

    deviations += getDeviationsOfPath(G_full, shortestPaths[k][1], shortestPaths[k][2], target, shortestPaths)

    if not deviations:
        break

    # find shortest path in deviations
    minDistance = float("inf")
    for x in deviations:
        if x[0] < minDistance:
            # check if path is already found
            new = True
            for path in shortestPaths:
                if path[1] == x[1]:
                    new = False

            if new:
                minDistance = x[0]
                shortestPath = x

    # add k+1 shortest path and remove it from deviations
    shortestPaths.append(shortestPath)
    deviations.remove(shortestPath)

print("\n{0:d} shortest paths:".format(K+1))
i = 0
for path in shortestPaths:
    i += 1
    print("{0:2d}. length: {1:1.5f}, path: {2}".format(i, getPathWeight(G_full, path[1]), path[1]))
