#include <stdlib.h>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <cstring>
#include <sstream>

using namespace std;

int main(int argc, char** argv) {
  if(argc < 2){
      cout<<"Input arguments:"<<endl;
      cout<<"gr file > output file"<<endl;
      exit(0);
    }

  char *infile = argv[1]; 

  string line;
  ifstream myFile;
  myFile.open(infile);
  if (myFile.is_open()) {
    getline(myFile, line);
    cout<<line<<endl;
    long src,dest;
    double w;
    while (true) {
      getline(myFile, line);
      if(myFile.eof()) break;
      std::stringstream ss(line);
      ss >> src >> dest >> w;
      cout<<src-1<<" "<<dest-1<<" "<<w<<endl;
   }
  }
}
