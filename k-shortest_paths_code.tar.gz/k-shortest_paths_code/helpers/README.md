How to use the helpers
====

generate-graph
---

Run
```
python3 ./generate-graph.py
```
and input the number of nodes the graph should have and the file name.

The script generates a hyperbolic graph and extracts the largest component. So the number of nodes in the largest component
will vary. The generated graph has twice the number of nodes such that the largest component has about the number of
requested nodes. The graph is stored as a METIS file and the file is generated in the resource directory.

metis2edgelist
---

Run
```
python3 ./metis2edgelist.py
```
and input the relative path to the existing METIS file and the edge list file that will be created.

Notice that the edge list file is no typical edge list file, since it is sorted by source and weight and contains the
number of nodes in the first line.

solve-ksp
---

Run
```
python3 ./solve-ksp.py
```
and input the relative path to a graph file in METIS format, the number of shortest path you want to search, the source
node and the target node. By just pressing enter you get the default values.

This script uses Yens algorithm to calculate the k shortest simple paths.