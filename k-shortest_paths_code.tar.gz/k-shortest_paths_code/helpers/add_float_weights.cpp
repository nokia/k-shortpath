#include <iostream>
#include <fstream>
#include <random>
#include <sstream>
#include <chrono>
#include <cstring>

int main(int argc, char** argv)
{
    if(argc < 2)
    {
        std::cout << "./generate_float_weights input > output" << std::endl;
        exit(0);
    }

    long seed = 12345;//std::chrono::high_resolution_clock::now().time_since_epoch().count();

    std::default_random_engine generator(seed);
    std::uniform_real_distribution<float> weight_distribution(0.0, 1.0);

    std::string line;
    std::ifstream graph_file;
    graph_file.open(argv[1]);
    unsigned int largest_node = 0;
    while(std::getline(graph_file, line))
    {
        unsigned int src, dest;
        std::stringstream ss(line);
	if(line[0] == '#') continue;
        ss >> src >> dest;
        if(src > largest_node) largest_node = src;
        if(dest > largest_node) largest_node = dest;
    }

    graph_file.close();
    std::cout << largest_node + 1 << std::endl;

    bool first_line = true;
    graph_file.open(argv[1]);
    while(std::getline(graph_file, line))
    {
        unsigned int src, dest;
        std::stringstream ss(line);
	if(line[0] == '#') continue;
        ss >> src >> dest;
        if(first_line)
        {
            first_line = false;
            std::cout << src << "\t" << dest << "\t" << weight_distribution(generator);
        }
        else
        {
            std::cout << "\n" << src << "\t" << dest << "\t" << weight_distribution(generator);
        }
    }
}
