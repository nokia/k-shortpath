#include <cstdio>
#include <cmath>
#include <cstdlib>

int N = 2048;
int M = 2048;
double const percentblocks = 0.10;
bool permute = false;

void randPerm(int P[], int size);

int main(int argc, char** argv)
{
    if(argc < 3)
    {
        printf("to run: ./makePacManMap <file to save> N M\n");
        exit(0);
    }
    char* file = argv[1];
    N = atoi(argv[2]);
    M = atoi(argv[3]);
    int** D = new int* [N];
    for(int i = 0; i < N; i++) D[i] = new int[M];//[M];
    int** C = new int* [N * M];//[4];
    for(int i = 0; i < N * M; i++) C[i] = new int[4];
    int* P = new int[N * M];
    FILE* fp;
    int i, j, k, p;

    for(i = 0; i < N; i++)
        for(j = 0; j < M; j++)
            D[i][j] = i * M + j;

    if(permute)
        randPerm(P, N * M);
    else
        for(i = 0; i < N * M; i++)
            P[i] = i;

    for(i = 0; i < N; i++)
        for(j = 0; j < M; j++)
            D[i][j] = P[D[i][j]];


    for(i = 0; i < N; i++)
        for(j = 0; j < M; j++)
            if(drand48() < percentblocks)
                D[i][j] = -1;

    for(i = 0; i < N * M; i++)
        for(j = 0; j < 4; j++)
            C[i][j] = 0;

    p = 0;
    for(i = 0; i < N; i++)
        for(j = 0; j < M; j++)
        {
            k = P[p++];
            if(j == 0)
                C[k][0] = -1;
            else
                C[k][0] = D[i][j - 1];
            if(j == M - 1)
                C[k][1] = -1;
            else
                C[k][1] = D[i][j + 1];
            if(i == 0)
                C[k][2] = -1;
            else
                C[k][2] = D[i - 1][j];
            if(i == N - 1)
                C[k][3] = -1;
            else
                C[k][3] = D[i + 1][j];
        }

    //count edges
    long edges = 0;
    for(i = 0; i < N * M; i++)
    {
        for(j = 0; j < 4; j++)
        {
            if(C[i][j] > -1)
                edges++;;
        }
    }

    fp = fopen(file, "w");
    for(i = 0; i < N * M; i++)
    {
        for(j = 0; j < 4; j++)
        {
            if(C[i][j] > i)
            {
                fprintf(fp, "%d %d\t\n", i, C[i][j]);
            }
        }
    }

    fclose(fp);
    return 0;
}

void randPerm(int P[], int size)
{
    int i;
    int k;
    int tmp;
    for(i = 0; i < size; i++)
        P[i] = i;

    for(i = size - 1; i >= 0; i--)
    {
        k = floor(drand48() * i);
        tmp = P[k];
        P[k] = P[i];
        P[i] = tmp;
    }
}

