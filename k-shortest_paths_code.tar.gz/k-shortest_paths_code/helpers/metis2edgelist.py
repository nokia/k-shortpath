import networkit as nk
import os

# Edge lists for the ksp code needs the number of nodes in the first line and the edges have to be sorted by
# increasing source and weight

sourcePath = input("Path to METIS file: ")
targetPath = input("Path to Edgelist file: ")

G = nk.graphio.readGraph(sourcePath, nk.graphio.Format.METIS)

f = open(os.getcwd() + '/' + targetPath, 'w+')

f.write(str(G.numberOfNodes()) + '\n')

for u in sorted(G.nodes()):
    neighbours = []
    for v in G.neighbors(u):
        neighbours.append((v, G.weight(u, v)))
    for v in sorted(neighbours, key=lambda x: x[1]):
        f.write('{0:d} {1:d} {2:f}\n'.format(u, v[0], v[1]))

f.close()
