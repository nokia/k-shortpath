//
// Created by Alex Schickedanz <alex@ae.cs.uni-frankfurt.de> on 05.09.17.
//

#include "GraphRW.h"

#ifdef UNDIRECTED
    #define DIRECTED false
#else
    #define DIRECTED true
#endif

int main(int argc, char** argv)
{
    std::cout<<"max node id: "<<std::numeric_limits<NODE_ID>::max()<<std::endl;
    std::cout<<"max edge id: "<<std::numeric_limits<EDGE_ID>::max()<<std::endl;
    if(argc < 4)
    {
        std::cout << "Generates a directed G(n,m) graph." << std::endl << std::endl;
        std::cout << "Input arguments:" << std::endl
                  << "[1] Number of nodes" << std::endl
                  << "[2] Number of edges" << std::endl
                  << "[3] Path to output file" << std::endl
                  << "[4] Integer Seed (optional)" << std::endl
                  << "Compile with -DUNDIRECTED to generate undirected Graphs" << std::endl;
        exit(1);
    }

    auto seed = argc > 4 ? strtol(argv[4], nullptr, 0) : 0;
    GraphRW::generate_G_n_m<DIRECTED>(static_cast<NODE_ID>(strtol(argv[1], nullptr, 0)),
                            static_cast<EDGE_ID>(strtol(argv[2], nullptr, 0)),
                            argv[3], seed);
}
