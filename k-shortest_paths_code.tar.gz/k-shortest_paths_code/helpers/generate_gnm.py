import networkx
import os
from operator import itemgetter
import random

mio = 1000000

n = int(input('Number of nodes in million: '))
# weighted = bool(input('weighted graph?'))

print("started generating...")
# gnm_random_graph generates a random graph without self loops or multi edges.
G = networkx.gnm_random_graph(n * mio, 4 * n * mio, directed=True)
print("finished generating.")

print("started writing the file...")
f = open(os.getcwd() + '/resources/gnm_{0:d}m_{1:d}m.edgelist'.format(n, 4*n), 'w+')
f.write(str(G.number_of_nodes()) + '\n')
for e in sorted(G.edges(), key=itemgetter(0)):
    # f.write('{0:d} {1:d} {2:f}\n'.format(e[0], e[1], 1))
    f.write('{0:d} {1:d} {2:f}\n'.format(e[0], e[1], random.uniform(0.0, 1.0)))
print("finished writing the file.")
