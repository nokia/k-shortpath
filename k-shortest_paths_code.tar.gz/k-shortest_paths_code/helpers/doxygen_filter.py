from sys import argv

script, input_file_name = argv

f = open(input_file_name)

# replace DS by DeltaSteppingStatic and GraphType by BasicGraph
print(f.read().replace('DS', 'DeltaSteppingStatic').replace('GraphType', 'BasicGraph'))