#!/usr/bin/env bash
# Pass the path where the files should be stored as first argument.

echo "|";
for n in 1 2 4 8 16 32 64 128;
do
    file_name=gnm_${n}m_$((4*$n))m;
    ./build/generate_g_nm $((1000000*$n)) $((4000000*$n)) $1/$file_name.metis
    printf "=";
done
echo "|";
