#!/usr/bin/env bash

# Inputs:
# 1. path to the metis file of the graph
# 2. number of runs
# 3. output file path without file ending
#

# build code for testing directed weighted graphs with uniform and exponential weight
echo "start compiling..."

#remove all build folders
rm -R build_* &> /dev/null

# build code for testing directed weighted graphs
printf "build_1 ..."
mkdir build_1
cd build_1
cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="" .. &> /dev/null
cmake --build . --target yellow_graph_size &> /dev/null
cd ..
echo " finished"

# build code for testing directed unweighted graphs
printf "build_2 ..."
mkdir build_2
cd build_2
cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DUNWEIGHTED" .. &> /dev/null
cmake --build . --target yellow_graph_size &> /dev/null
cd ..
echo " finished"

# build code for testing undirected weighted graphs
printf "build_3 ..."
mkdir build_3
cd build_3
cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DUNDIRECTED" .. &> /dev/null
cmake --build . --target yellow_graph_size &> /dev/null
cd ..
echo " finished"

# build code for testing undirected unweighted graphs
printf "build_4 ..."
mkdir build_4
cd build_4
cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DUNWEIGHTED -DUNDIRECTED" .. &> /dev/null
cmake --build . --target yellow_graph_size &> /dev/null
cd ..
echo  "finished"

echo "...end compiling"



