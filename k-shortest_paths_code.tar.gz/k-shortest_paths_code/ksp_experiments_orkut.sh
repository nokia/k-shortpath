#################
#run experiments#
#################
cd resources
wget https://snap.stanford.edu/data/bigdata/communities/com-orkut.ungraph.txt.gz  
gunzip com-orkut.ungraph.txt.gz
cd ..
mkdir build
cd build
cmake -DCMAKE_BUILD_TYPE=EXPERIMENT ..
cmake --build . --target all
./add_float_weights ../resources/com-orkut.ungraph.txt > ../resources/com-orkut.ungraph_w.txt
./renumber_nodes ../resources/com-orkut.ungraph_w.txt > ../resources/com-orkut.ungraph_w_renumbered.txt

g="com-orkut.ungraph_w_renumbered.txt"
threads=(2 4 6 8 10)

log="../results/parallel_ksp_performance/$g""_early_stopping.log"
lscpu >> $log

run=(0 1)

#merge later
for r in ${run[@]}
do
    cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=1" ..
    cmake --build . --target ksp_performance
    ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
    for t in ${threads[@]}
    do
      #use L2 pd
      cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=$t -DKSP_PARALLEL_DEVIATIONS_L2" ..
      cmake --build . --target ksp_performance
      ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
    done
done
