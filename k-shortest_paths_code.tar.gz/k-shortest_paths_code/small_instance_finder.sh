#!/usr/bin/env bash

# generate a random graph
python3 ./helpers/small_instance_generator.py $1

# generate a new one as long as it does not fail
./cmake-build-debug/small_instance_tester $1 &>/dev/null
until [ $? -ne 0 ]
do
    python3 ./helpers/small_instance_generator.py $1
    ./cmake-build-debug/small_instance_tester $1  &>/dev/null
    printf "."
done

echo "Found a small instance!"