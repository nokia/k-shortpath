#!/usr/bin/env bash

# Inputs:
# 1. path to the metis file of the graph
# 2. number of runs
# 3. output file path without file ending
#

# run the experiments with uniform edge weights
./build_3/yellow_graph_size $1 $2 >> $3.ud.log

# fix the JSON formatting
echo "[$(cat $3.ud.log | tail -c +2)]" > $3.ud.log;

# run the experiments with exponential edge weights
./build_3/yellow_graph_size $1 $2 -exp >> $3.ud.exp.log

# fix the JSON formatting
echo "[$(cat $3.ud.exp.log | tail -c +2)]" > $3.ud.exp.log;

# run the experiments
./build_4/yellow_graph_size $1 $2 >> $3.ud.uw.log

# fix the JSON formatting
echo "[$(cat $3.ud.uw.log | tail -c +2)]" > $3.ud.uw.log;


