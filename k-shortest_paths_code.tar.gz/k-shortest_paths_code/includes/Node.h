#ifndef _NODE_H
#define _NODE_H

#include <ostream>
#include <limits>

// Node types
using NODE_ID = unsigned int;
constexpr NODE_ID NULL_NODE = std::numeric_limits<NODE_ID>::max();

// Edge types
using EDGE_ID = size_t;
constexpr EDGE_ID NULL_EDGE = std::numeric_limits<EDGE_ID>::max();

using w_type = double;      // Can be double or float
static_assert(std::numeric_limits<w_type>::has_infinity, "w_type needs to support numeric_limits<w_type>::infinity()");

// distances
constexpr w_type INFINITE_DISTANCE = std::numeric_limits<w_type>::infinity();

/**
 * Stores an edge as a target node with an edge weight and the ID of the backward edge.
 * To get the edge, you need to know in which nodes neighbor list this edge is.
 *
 * IMPORTANT: IF THIS STRUCTURE CHANGES THE BINARY GRAPHS CANNOT BE READ ANYMORE
 */
template<bool directed = false, bool weighted = true>
class Edge;

template<>
class Edge<false, false>
{
    /**
     * Id of the target node of this edge
     */
    NODE_ID target;
    /**
     * Id of the backwards edge in the adjacency list (of all nodes)
     */
    EDGE_ID backwards_edge_id = NULL_EDGE;

public:
    explicit Edge(NODE_ID target, w_type /*weight*/ = 0) noexcept
        : target(target)
    {}

    NODE_ID get_target() const noexcept
    {
        return target;
    }

    w_type get_weight() const noexcept
    {
        return 1.0;
    }

    void set_weight(w_type /*new_weight*/) const {}   // is needed because the other instantiations also have one

    EDGE_ID get_backwards_edge_id() const noexcept
    {
        return backwards_edge_id;
    }

    void set_backwards_edge_id(EDGE_ID new_backwards_edge) noexcept
    {
        backwards_edge_id = new_backwards_edge;
    }

    friend std::ostream &operator<<(std::ostream &output, const Edge& e) noexcept
    {
        output << "[target " << e.target << ", backwards edge id " << e.backwards_edge_id << "]" << std::endl;
        return output;
    }

    template<bool directed_out, bool weighted_out>
    explicit operator Edge<directed_out, weighted_out>() const noexcept
    {
        return Edge<directed_out, weighted_out>(get_target(), get_weight());
    }
};

template<>
class Edge<false, true>
{
    /**
     * Id of the target node of this edge
     */
    NODE_ID target;
    /**
     * Id of the backwards edge in the adjacency list (of all nodes)
     */
    EDGE_ID backwards_edge_id = NULL_EDGE;
    /**
     * Weight of the edge
     */
    w_type weight;

public:
    explicit Edge(NODE_ID target, w_type weight = 0) noexcept
            : target(target),
              weight(weight)
    {}

    NODE_ID get_target() const noexcept
    {
        return target;
    }

    w_type get_weight() const noexcept
    {
        return weight;
    }

    void set_weight(w_type new_weight) noexcept
    {
        weight = new_weight;
    }

    EDGE_ID get_backwards_edge_id() const noexcept
    {
        return backwards_edge_id;
    }

    void set_backwards_edge_id(EDGE_ID new_backwards_edge) noexcept
    {
        backwards_edge_id = new_backwards_edge;
    }

    friend std::ostream &operator<<(std::ostream &output, const Edge& e) noexcept
    {
        output << "[target " << e.target << ", weight " << e.weight <<
               ", backwards edge id " << e.backwards_edge_id << "]" << std::endl;
        return output;
    }

    template<bool directed_out, bool weighted_out>
    explicit operator Edge<directed_out, weighted_out>() const noexcept
    {
        return Edge<directed_out, weighted_out>(get_target(), get_weight());
    }
};

template<>
class Edge<true, false>
{
    /**
     * Id of the target node of this edge
     */
    NODE_ID target;

public:
    explicit Edge(NODE_ID target, w_type /*weight*/ = 0) noexcept
            : target(target)
    {}

    NODE_ID get_target() const noexcept
    {
        return target;
    }

    w_type get_weight() const noexcept
    {
        return 1.0;
    }

    void set_weight(w_type /*new_weight*/) const noexcept {}   // is needed because the other instantiations also have one

    EDGE_ID get_backwards_edge_id() const noexcept       // is needed because the other instantiations also have one
    {
        return NULL_EDGE;
    }

    void set_backwards_edge_id(EDGE_ID /*new_backwards_edge*/) const noexcept {}  // is needed because the other instantiations also have one

    friend std::ostream &operator<<(std::ostream &output, const Edge& e) noexcept
    {
        return output << "[target " << e.target << "]" << std::endl;
    }

    template<bool directed_out, bool weighted_out>
    explicit operator Edge<directed_out, weighted_out>() const noexcept
    {
        return Edge<directed_out, weighted_out>(get_target(), get_weight());
    }
};

template<>
class Edge<true, true>
{
    /**
     * Id of the target node of this edge
     */
    NODE_ID target;
    /**
     * Weight of the edge
     */
    w_type weight;

public:
    explicit Edge(NODE_ID target, w_type weight = 0) noexcept
            : target(target),
              weight(weight)
    {}

    NODE_ID get_target() const noexcept
    {
        return target;
    }

    w_type get_weight() const noexcept
    {
        return weight;
    }

    void set_weight(w_type new_weight) noexcept
    {
        weight = new_weight;
    }

    EDGE_ID get_backwards_edge_id() const noexcept       // is needed because the other instantiations also have one
    {
        return NULL_EDGE;
    }

    void set_backwards_edge_id(EDGE_ID /*new_backwards_edge*/) const noexcept {}  // is needed because the other instantiations also have one

    friend std::ostream &operator<<(std::ostream &output, const Edge& e) noexcept
    {
        output << "[target " << e.target << ", weight " << e.weight << "]" << std::endl;
        return output;
    }

    template<bool directed_out, bool weighted_out>
    explicit operator Edge<directed_out, weighted_out>() const noexcept
    {
        return Edge<directed_out, weighted_out>(get_target(), get_weight());
    }
};

/**
 * Stores a Id of the first edge in its adjacency list and how many of the edges are light.
 *
 * IMPORTANT: IF THIS STRUCTURE CHANGES THE BINARY GRAPHS CANNOT BE READ ANYMORE
 */
struct Node
{
    /**
     * Id of the first edge in the adjacency list (of all nodes)
     */
    EDGE_ID start_edge = 0;
    /**
     * The number of light edges in the adjacency list of this node
     */
    NODE_ID num_light_edges = 0;

    Node() = default;

    explicit Node(const EDGE_ID start_edge) noexcept : start_edge(start_edge) {}

    friend std::ostream &operator<<(std::ostream& output, const Node& n) noexcept
    {
        output << "[start_edge = " << n.start_edge << "; num_light_edges = " << n.num_light_edges << "]" << std::endl;
        return output;
    }
};

#endif  // _NODE_H
