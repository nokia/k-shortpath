//
// Created by Alex Schickedanz <alex@ae.cs.uni-frankfurt.de> on 10.03.17.
//

#ifndef _PRIORITY_QUEUE_H
#define _PRIORITY_QUEUE_H

#include <set>

auto default_key_updater = [](auto& el, auto new_key) -> void { el = new_key; };

/**
 * A priority queue supporting update key (aka decrease key) build on top of a std::set.
 * See std::set for details about the template parameters. NOTICE: since this is build
 * on top of a std::set, there are no duplicate elements allowed.
 * @tparam ElementType
 * @tparam Compare
 * @tparam Alloc
 */
template<typename ElementType,
         typename Compare = std::less<ElementType>,
         typename KeyType = ElementType,
         typename KeyUpdater = decltype(default_key_updater),
         typename Alloc = std::allocator<ElementType>>
class PriorityQueue
{

    using queue_type = std::set<ElementType, Compare, Alloc>;

    queue_type queue;

    KeyUpdater key_updater;

public:

    PriorityQueue() : key_updater(default_key_updater) {};

    explicit PriorityQueue(Compare cmp, KeyUpdater key_updater = default_key_updater)
        : queue(cmp),
          key_updater(key_updater)
    {};

    /**
     * Inserts an element in O(log n) time.
     * @param el
     */
    void push(const ElementType el)
    {
        queue.insert(el);
    }

    /**
     * Inserts an element after setting its key.
     * @param el
     * @param key
     */
    void push(ElementType el, const KeyType key)
    {
        key_updater(el, key);
        queue.insert(el);
    }

    /**
     * Emplaces a new element. The element is constructed in place in O(log n) time.
     * @tparam Args
     * @param args
     * @return
     */
    template < typename ... Args >
    std::pair<typename queue_type::iterator, bool> emplace(Args&&... args)
    {
        return queue.emplace(std::forward<Args>(args)...);
    }

    /**
     * Updates the key an element. It removes the old element and inserts the new element.
     * The overall complexity is O(log n)
     * @param old_el
     * @param new_el
     */
    void update_key(ElementType el, const KeyType new_key)
    {
        queue.erase(el);
        key_updater(el, new_key);
        queue.insert(el);
    }

    /**
     * Returns the minimal value
     * @return
     */
    ElementType top() const
    {
        return *queue.begin();
    }

    /**
     * Deletes the element with the highest priority
     */
    void pop()
    {
        queue.erase(queue.begin());
    }

    /**
     * Checks if the priority queue is empty
     * @return
     */
    bool empty() const
    {
        return queue.empty();
    }

    /**
     * returns the size of the priority queue
     * @return
     */
    typename queue_type::size_type size() const
    {
        return queue.size();
    }

};

#endif  // _PRIORITY_QUEUE_H
