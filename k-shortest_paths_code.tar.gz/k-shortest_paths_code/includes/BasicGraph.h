#ifndef _BASIC_GRAPH_H
#define _BASIC_GRAPH_H

#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include <Node.h>
#include <omp.h>
#include <cassert>
#include <memory>

/**
 * Stores nodes and edges of a graph
 */
template<bool directed, bool weighted>
class BasicGraph
{
    friend class GraphRW;

public:
    using node_list_type = std::vector<Node>;
    using edge_list_type = std::vector<Edge<directed, weighted>>;

private:
    const NODE_ID num_nodes;        // holds the number of actual nodes, without the sentinel
    const EDGE_ID num_edges;        // holds the number of edges (edges.size())

    const node_list_type nodes;     // list of all nodes including a sentinel
    const edge_list_type edges;

    const w_type heaviest_weight;
    const w_type delta;

    std::unique_ptr<const BasicGraph<directed, weighted>> reverse_graph;

public:
    static constexpr bool is_directed = directed;
    static constexpr bool is_weighted = weighted;

    /**
     * @param nodes             A list of nodes containing a sentinel at the end. This node is just for holding the
     *                          edge list end for the last actual node
     * @param edges             A list of edges
     * @param heaviest_weight   The heaviest weighed a edge in the list has
     * @param delta             The delta for delta stepping, the edges got classified
     * @param reverse_graph     A pointer to the reverse graph. This is only required if the graph is used in an algorithm
     *                          that needs the reverse graph. For undirected graphs this is never required.
     */
    BasicGraph(node_list_type nodes, edge_list_type edges, w_type heaviest_weight, w_type delta,
               std::unique_ptr<const BasicGraph<directed, weighted>>&& reverse_graph = std::unique_ptr<const BasicGraph<directed, weighted>>(nullptr))
        : num_nodes(static_cast<NODE_ID>(nodes.size() - 1)),
          num_edges(edges.size()),
          nodes(std::move(nodes)),
          edges(std::move(edges)),
          heaviest_weight(heaviest_weight),
          delta(delta),
          reverse_graph(std::move(reverse_graph))
    {}

    /**
     * Returns the reverse graph. This is for undirected graphs the original graph.
     * For the directed case the reverse graph needs to be computed explicitly and provided to the constructor.
     * @return
     */
    const BasicGraph<directed, weighted>& get_reverse_graph() const noexcept
    {
        if(!directed)
            return *this;

        assert(reverse_graph != nullptr);

        return *reverse_graph;
    }

    /**
     * Returns the number of actual nodes without the sentinel.
     * @return The number of actual nodes without the sentinel.
     */
    NODE_ID get_num_nodes() const noexcept
    {
        return num_nodes;
    }

    /**
     * Returns the number of edges.
     * @return The number of edges.
     */
    EDGE_ID get_num_edges() const noexcept
    {
        return num_edges;
    }

    /**
     * Returns the number of outgoing edges of node.
     * @param node_id
     * @return The number of outgoing edges of node.
     */
    NODE_ID get_num_neighbors(const NODE_ID node_id) const noexcept
    {
        return static_cast<NODE_ID>(nodes[node_id + 1].start_edge - nodes[node_id].start_edge);   // works thanks to the sentinel
    }

    /**
     * Returns the weight of the edge (u,v).
     * @param u
     * @param v
     * @return The weight of the edge (u,v). If the edge does not exists, infinity is returned.
     */
    w_type get_edge_weight(const NODE_ID u, const NODE_ID v) const noexcept
    {
        for(auto e = get_edge_list_begin_iter(u), end = get_edge_list_end_iter(u); e != end; ++e)
        {
            if(e->get_target() == v)
                return e->get_weight();
        }

        return INFINITE_DISTANCE;
    }


    /**
     * Returns a const reference to a node.
     * @param node_id
     * @return A const reference to a node.
     */
    const Node& get_node(const NODE_ID node_id) const noexcept
    {
        return nodes[node_id];
    }

    /**
     * Returns a const reference to an edge.
     * @param edge_id
     * @return A const reference to an edge.
     */
    const Edge<directed, weighted>& get_edge(const EDGE_ID edge_id) const noexcept
    {
        return edges[edge_id];
    }

    /**
     * Returns an iterator to the first outgoing edge of the node with the id u.
     * @param u
     * @return A iterator to the first outgoing edge of the node with the id u.
     */
    typename edge_list_type::const_iterator get_edge_list_begin_iter(const NODE_ID u) const noexcept
    {
        return edges.cbegin() + nodes[u].start_edge;
    }

    /**
     * Returns an iterator to the first outgoing edge that not belongs to u.
     * @param u
     * @return A iterator to the first outgoing edge that not belongs to u.
     */
    typename edge_list_type::const_iterator get_edge_list_end_iter(const NODE_ID u) const noexcept
    {
        return edges.cbegin() + nodes[u + 1].start_edge;    // works thanks to the sentinel
    }

    /**
     * Returns the begin of the edge list of the node.
     * @param node
     * @return begin, such that all edges starting in node are in [begin, end)
     */
    EDGE_ID get_edge_list_begin(const NODE_ID node) const noexcept
    {
        return nodes[node].start_edge;
    }

    /**
     * Returns the begin of the heavy edge list of the node. (alias for get_light_edge_list_end())
     * @param node
     * @return begin, such that all heavy edges starting in node are in [begin, end)
     */
    EDGE_ID get_heavy_edge_list_begin(const NODE_ID node) const noexcept
    {
        return get_light_edge_list_end(node);
    }

    /**
     * Returns the end of the edge list of the node.
     * @param node
     * @return end, such that all edges starting in node are in [begin, end)
     */
    EDGE_ID get_edge_list_end(const NODE_ID node) const noexcept
    {
        return nodes[node + 1].start_edge;      // works thanks to the sentinel
    }

    /**
     * Returns the end of the light edge list of the node.
     * @param node
     * @return end, such that all light edges starting in node are in [begin, end)
     */
    EDGE_ID get_light_edge_list_end(const NODE_ID node) const noexcept
    {
        return nodes[node].start_edge + nodes[node].num_light_edges;
    }

    /**
     * Retruns the id of the backwards edge.
     * @param edge_id
     * @return The id of the backwards edge.
     */
    EDGE_ID get_backwards_edge_id(const EDGE_ID edge_id) const noexcept
    {
        return edges[edge_id].get_backwards_edge_id();
    }

    /**
     * Returns the delta value the edges were classified with.
     * @return The delta value the edges were classified with.
     */
    w_type get_delta() const noexcept
    {
        return delta;
    }

    /**
     * Returns the bucket size used in DeltaStepping.
     * @return
     */
    unsigned int compute_bucket_size() const noexcept
    {
        return static_cast<unsigned int>(ceil(heaviest_weight / delta)) + 1;
    }

    /**
     * Retruns the average degree calculated as num_edges / num_nodes.
     * @return The average degree.
     */
    double get_avg_degree() const noexcept
    {
        return static_cast<double>(num_edges) / static_cast<double>(num_nodes);
    }

    w_type get_path_length(const std::vector<NODE_ID>& node_list) const noexcept
    {
        return get_path_length(node_list, node_list.size() - 1);
    }

    w_type get_path_length(const std::vector<NODE_ID>& node_list, const size_t end) const noexcept
    {
        if(node_list.empty())
            return 0;

        assert(end < node_list.size());

        w_type length = 0;

        for(size_t i = 0; i < end; i++)
        {
            length += get_edge_weight(node_list[i], node_list[i + 1]);
        }

        return length;
    }

    /**
     * Checks that the reverse graph contains all nodes and the reverse edges and that the edges are sorted by weight for
     * each start node.
     * @return true, if the reverse graph is fine, else false.
     */
    bool check_reverse_graph() const noexcept
    {
        // check that the reverse graph is correct
        bool correct = true;

        if(reverse_graph != nullptr)
        {
            // right number of nodes
            correct = correct && nodes.size() == reverse_graph->nodes.size();

            // right number of edges
            correct = correct && edges.size() == reverse_graph->edges.size();

            // right delta
            correct = correct && delta == reverse_graph->delta;

            for(NODE_ID u_id = 0; u_id < nodes.size() - 1; ++u_id)
            {
                w_type last_weight = 0;
                for(EDGE_ID e_id = nodes[u_id].start_edge; e_id < nodes[u_id+1].start_edge; ++e_id)
                {
                    correct = correct
                            // if (u,v) is in this graph, (v,u) needs to be in its reverse graph with the correct weight.
                              && reverse_graph->get_edge_weight(edges[e_id].get_target(), u_id)
                                 == get_edge_weight(u_id, edges[e_id].get_target())
                            // edges are sorted by weight
                              && last_weight <= reverse_graph->get_edge_weight(edges[e_id].get_target(), u_id);

                    last_weight = reverse_graph->get_edge_weight(edges[e_id].get_target(), u_id);
                }

                const auto first_heavy_edge = reverse_graph->nodes[u_id].start_edge + reverse_graph->nodes[u_id].num_light_edges;
                if(first_heavy_edge < reverse_graph->nodes[u_id+1].start_edge)
                    assert(reverse_graph->edges[first_heavy_edge].get_weight() >= delta);

                if(first_heavy_edge > reverse_graph->nodes[u_id+1].start_edge)
                    assert(reverse_graph->edges[first_heavy_edge-1].get_weight() < delta);
            }
        }

        return correct;
    }
};

#endif  // _BASIC_GRAPH_H
