#ifndef _BUCKET_LIST_DYNAMIC_H
#define _BUCKET_LIST_DYNAMIC_H

#include <Partition.h>
#include <Node.h>
#include <ostream>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <omp.h>

template<typename Partition>
class BucketListDynamic
{
public:
    static constexpr unsigned int NULL_BUCKET = std::numeric_limits<unsigned int>::max();

    BucketListDynamic(const Partition& p, const unsigned int num_buckets, const unsigned int num_entries) noexcept
        : partition(p),
          num_threads(p.get_num_threads()),
          num_buckets(num_buckets),
          num_entries(num_entries),
          b_min_len(init_bucket_length(num_entries, num_buckets)),
          buckets(num_buckets, std::vector<NODE_ID>(b_min_len)),
          bucket_end(num_buckets, 0),
          id_to_bucket(num_entries, NULL_BUCKET),
          id_to_bucket_pos(num_entries, NULL_BUCKET),
          insert_to_buckets(num_threads, std::vector<BucketListDynamic::b_insert>(b_min_len)),
          insert_to_buckets_pos(num_threads, 0),
          buckets_to_insert(num_buckets),
          buckets_to_insert_pos(0),
          bucket_locks(num_buckets, false),
          buckets_prefix_sum(num_buckets, std::vector<unsigned int>(num_threads + 1, 0)),
          b_end(num_buckets, std::vector<unsigned int>(num_threads, 0)),
          delete_b_locks(num_buckets, false),
          delete_nodes(num_buckets, std::vector<unsigned int>(num_threads)),
          delete_b_nodes(num_buckets),
          delete_b_nodes_pos(0),
          b_temp(num_threads, std::vector<NODE_ID>(b_min_len)),
          b_temp_end(num_threads),
          prefix_sum(num_threads)
    {}

    unsigned int get_bucket(const unsigned int node) const noexcept
    {
        return id_to_bucket[node];
    }

    bool is_empty(const unsigned int bucket_id) const noexcept
    {
        return bucket_end[bucket_id] == 0;
    }

    void reset(const unsigned int new_num_threads) noexcept
    {
        num_threads = new_num_threads;  // todo does not work, if new_num_threads is bigger than the old number...
        delete_b_nodes_pos = 0;
        buckets_to_insert_pos = 0;

        std::fill(bucket_end.begin(), bucket_end.end(), 0);
        std::fill(delete_b_locks.begin(), delete_b_locks.end(), false);
        std::fill(bucket_locks.begin(), bucket_locks.end(), false);

        std::fill(insert_to_buckets_pos.begin(), insert_to_buckets_pos.end(), 0);

        for(unsigned int b = 0; b < num_buckets; b++)
        {
            std::fill(buckets_prefix_sum[b].begin(), buckets_prefix_sum[b].end(), 0);
            std::fill(b_end[b].begin(), b_end[b].end(), 0);
        }

        std::fill(id_to_bucket.begin(), id_to_bucket.end(), NULL_BUCKET);
        std::fill(id_to_bucket_pos.begin(), id_to_bucket_pos.end(), NULL_BUCKET);
    }

    void move(const unsigned int node, const unsigned int new_bucket) noexcept
    {
        const unsigned int old_bucket = get_bucket(node);

        if(new_bucket == old_bucket)    // bucket did not change => do nothing
            return;

        const auto t_id = static_cast<unsigned int>(omp_get_thread_num());

        if(old_bucket != NULL_BUCKET)
        {
            buckets[old_bucket][id_to_bucket_pos[node]] = NULL_NODE;
            id_to_bucket[node] = NULL_BUCKET;
            id_to_bucket_pos[node] = NULL_BUCKET;

            if(!delete_b_locks[old_bucket])
                update_delete_bucket(old_bucket);

            delete_nodes[old_bucket][t_id]++;
        }

        // prepare the node node to be added to a bucket
        if(!bucket_locks[new_bucket])   // bypass the critical
        {
#pragma omp critical    // move()
            {
                if(!bucket_locks[new_bucket])   // check again, maybe more than one thread passed the first if before the flag was set
                {
                    bucket_locks[new_bucket] = true;
                    buckets_to_insert[buckets_to_insert_pos++] = new_bucket;
                }
            }
        }

        id_to_bucket[node] = new_bucket;
        update_local_bucket_list({node, new_bucket}, t_id);
    }

    /**
     * Returns the id of the next non-empty bucket.
     * @param last_bucket The last processed bucket.
     * @return
     */
    unsigned int find_smallest_bucket(const unsigned int last_bucket = NULL_BUCKET) const noexcept
    {
        const unsigned int start = (last_bucket + 1) * static_cast<int>(last_bucket < num_buckets);

        for(unsigned int i = start; i < num_buckets; i++)
        {
            if(bucket_end[i] > 0)
                return i;
        }

        for(unsigned int i = 0; i < start; i++)
        {
            if(bucket_end[i] > 0)
                return i;
        }

        return NULL_BUCKET;
    }

    /**
     * Adds node to the bucket with the bucket_id
     * @param bucket_id
     * @param node
     */
    void insert_to_bucket_list(const unsigned int bucket_id, const NODE_ID node) noexcept
    {
        buckets[bucket_id][bucket_end[bucket_id]] = node;
        id_to_bucket[node] = bucket_id;
        id_to_bucket_pos[node] = bucket_end[bucket_id];
        bucket_end[bucket_id]++;
    }

    unsigned int length(const unsigned int bucket_id) const noexcept
    {
        return bucket_end[bucket_id];
    }

    NODE_ID remove_node_at(const unsigned int bucket_id, const unsigned int pos) noexcept
    {
        const NODE_ID node = buckets[bucket_id][pos];

        if(node != NULL_NODE)
        {
            id_to_bucket_pos[node] = NULL_BUCKET;
            buckets[bucket_id][pos] = NULL_NODE;
            id_to_bucket[node] = NULL_BUCKET;
        }

        return node;
    }

    void update_buckets() noexcept
    {
        for(unsigned int i = 0; i < delete_b_nodes_pos; i++)
        {
            const unsigned int this_b = delete_b_nodes[i];
            unsigned int b_del = 0;

            for(unsigned int j = 0; j < num_threads; j++)
            {
                b_del += delete_nodes[this_b][j];
            }

            // check if bucket needs to be collapsed
            if(bucket_end[this_b] > 0 && b_del > (bucket_end[this_b] - b_del) / 3)
            {
                collapse_bucket(this_b);
                // reset b_del count
                for(unsigned int j = 0; j < num_threads; j++)
                    delete_nodes[this_b][j] = 0;
            }

            delete_b_locks[this_b] = false;
        }

        delete_b_nodes_pos = 0;

        // add nodes into the buckets in parallel
        add_nodes_to_buckets();
    }

    void reset_bucket(const unsigned int bucket_id) noexcept
    {
        bucket_end[bucket_id] = 0;
    }

    bool contains_entry(const unsigned int n) const
    {
        return id_to_bucket[n] != NULL_BUCKET;
    }

    template<typename P>
    friend std::ostream &operator<<(std::ostream &o, const BucketListDynamic<P> &b);

private:
    // private structures
    struct b_insert
    {
        NODE_ID node;
        unsigned int b_id;

        b_insert() noexcept : node(NULL_NODE), b_id(BucketListDynamic::NULL_BUCKET) {}
        b_insert(NODE_ID node, unsigned int b_id) noexcept : node(node), b_id(b_id) {}
    };

    static unsigned int init_bucket_length(const unsigned int num_entries, const unsigned int num_buckets) noexcept
    {
        return (4 * num_buckets * num_buckets > num_entries)
               ? static_cast<unsigned int>(4 * ceil(sqrt(num_entries)))
               : (2 * num_entries) / num_buckets;
    }

    void expand_bucket(const unsigned int b_id, const unsigned int req_size) noexcept
    {
        unsigned long new_size = buckets[b_id].size();
        while(new_size <= req_size)
            new_size <<= 1;     // doubling

        buckets[b_id].resize(new_size);
    }

    void collapse_bucket(const unsigned int b_id) noexcept
    {
        const unsigned int num_threads = partition.get_num_threads();
        for(unsigned int t = 0; t < num_threads; t++)
        {
            b_temp_end[t] = 0;
        }

        if(bucket_end[b_id] > 29)
        {

#pragma omp parallel for num_threads(num_threads)   // collapse_bucket()
            for(unsigned int i = 0; i < bucket_end[b_id]; i++)
            {
                if(buckets[b_id][i] != NULL_NODE)
                {
                    const auto tid = static_cast<unsigned int>(omp_get_thread_num());
                    increase_b_temp_size(tid);
                    b_temp[tid][b_temp_end[tid]] = buckets[b_id][i];
                    b_temp_end[tid]++;
                }
            }

            unsigned int sum = 0;

            for(unsigned int t = 0; t < num_threads; t++)
            {
                prefix_sum[t] = sum;
                sum += b_temp_end[t];
            }

#pragma omp parallel for num_threads(num_threads)   // collapse_bucket()
            for(unsigned int i = 0; i < num_threads; i++)
            {
                unsigned int pos = prefix_sum[i];

                for(unsigned int j = 0; j < b_temp_end[i]; j++, pos++)
                {
                    buckets[b_id][pos] = b_temp[i][j];
                    id_to_bucket_pos[b_temp[i][j]] = pos;
                }
            }

            bucket_end[b_id] = prefix_sum[num_threads - 1] + b_temp_end[num_threads - 1];
        }
        else
        {
            for(unsigned int i = 0; i < bucket_end[b_id]; i++)
            {
                if(buckets[b_id][i] != NULL_NODE)
                {
                    b_temp[0][b_temp_end[0]] = buckets[b_id][i];
                    b_temp_end[0]++;
                }
            }

            for(unsigned int i = 0; i < b_temp_end[0]; i++)
            {
                buckets[b_id][i] = b_temp[0][i];
                id_to_bucket_pos[b_temp[0][i]] = i;
            }

            bucket_end[b_id] = b_temp_end[0];
        }
    }

    void increase_insert_to_buckets_size(const unsigned int t) noexcept
    {
        if(insert_to_buckets_pos[t] == insert_to_buckets[t].size())
        {
            insert_to_buckets[t].resize(insert_to_buckets[t].size() << 1);
        }
    }

    void reset_insert_bucket_data() noexcept
    {
        const unsigned int num_threads = partition.get_num_threads();
        for(unsigned int i = 0; i < buckets_to_insert_pos; i++)
        {
            const unsigned int b = buckets_to_insert[i];
            bucket_locks[b] = false;
            bucket_end[b] += buckets_prefix_sum[b][num_threads];

            for(unsigned int t = 0; t < num_threads; t++)
            {
                b_end[b][t] = 0;
                buckets_prefix_sum[b][t] = 0;
            }
            buckets_prefix_sum[b][num_threads] = 0;
        }

        for(unsigned int i = 0; i < num_threads; i++)
        {
            insert_to_buckets_pos[i] = 0;
        }

        buckets_to_insert_pos = 0;
    }

    void add_nodes_to_buckets() noexcept
    {
        const unsigned int num_threads = partition.get_num_threads();

        for(unsigned int i = 0; i < buckets_to_insert_pos; i++)
        {
            const unsigned int curr_b = buckets_to_insert[i];
            for(unsigned int j = 1; j < num_threads; j++)
            {
                buckets_prefix_sum[curr_b][j+1] += buckets_prefix_sum[curr_b][j];
            }

            if(buckets_prefix_sum[curr_b][num_threads] + bucket_end[curr_b] >= buckets[curr_b].size())
            {
                expand_bucket(curr_b, buckets_prefix_sum[curr_b][num_threads] + bucket_end[curr_b]);
            }
        }

        // each thread will insert its nodes into the bucket data structure
#pragma omp parallel for num_threads(num_threads)   // add_nodes_to_buckets()
        for(unsigned int t = 0; t < num_threads; t++)
        {
            if(insert_to_buckets_pos[t] > 0)
            {
                for(unsigned int j = 0; j < insert_to_buckets_pos[t]; j++)
                {
                    const NODE_ID node = insert_to_buckets[t][j].node;
                    const unsigned int curr_bucket = insert_to_buckets[t][j].b_id;

                    b_end[curr_bucket][t]++;
                    const unsigned int new_pos = bucket_end[curr_bucket] - 1 + buckets_prefix_sum[curr_bucket][t] + b_end[curr_bucket][t];
                    buckets[curr_bucket][new_pos] = node;
                    id_to_bucket_pos[node] = new_pos;
                }
            }
        }

        reset_insert_bucket_data();
    }

    void update_local_bucket_list(const b_insert& temp, const unsigned int t_id) noexcept
    {
        increase_insert_to_buckets_size(t_id);
        insert_to_buckets[t_id][insert_to_buckets_pos[t_id]] = temp;
        insert_to_buckets_pos[t_id]++;
        buckets_prefix_sum[temp.b_id][t_id + 1]++;
    }

    void increase_b_temp_size(const unsigned int i) noexcept
    {
        if(b_temp_end[i] == b_temp[i].size())
        {
            b_temp[i].resize(b_temp[i].size() << 1);
        }
    }

    void update_delete_bucket(const unsigned int b_id) noexcept
    {
#pragma omp critical    // update_delete_bucket()
        {
            if(!delete_b_locks[b_id])
            {
                delete_b_nodes[delete_b_nodes_pos++] = b_id;
                delete_b_locks[b_id] = true;
            }
        }
    }

    // private data fields
    const Partition& partition;
    unsigned int num_threads;
    const unsigned int num_buckets;
    const unsigned int num_entries;
    const unsigned int b_min_len;

    std::vector<std::vector<NODE_ID>> buckets;      // [#buckets][sqrt(n)] the bucket data structure
    std::vector<unsigned int> bucket_end;           // pointing to the last location in any given bucket
    std::vector<unsigned int> id_to_bucket;         // mapping from node ID to the current bucket number
    std::vector<unsigned int> id_to_bucket_pos;     // mapping from node ID to the position in its bucket

    // data structures to deal with parallel node insertion
    std::vector<std::vector<b_insert>> insert_to_buckets;           // [#threads][sqrt(n)], requests that have to be inserted into the bucket, each thread builds its own set
    std::vector<unsigned int> insert_to_buckets_pos;                // [#threads]
    std::vector<unsigned int> buckets_to_insert;                    // [#buckets], id of buckets where new nodes will be inserted
    unsigned int buckets_to_insert_pos;                             // current empty position in buckets_to_insert data
    std::vector<bool> bucket_locks;                                 // [#buckets], indicate whether this bucket id has already been inserted into buckets_to_insert data
    std::vector<std::vector<unsigned int>> buckets_prefix_sum;      // [#buckets][#threads], each thread will compute its prefix sum for the given bucket in order to allow for parallel insertion
    std::vector<std::vector<unsigned int>> b_end;                   // [#buckets][#threads]

    // delete bucket
    std::vector<bool> delete_b_locks;                       // [#buckets], buckets that have some deleted nodes
    std::vector<std::vector<unsigned int>> delete_nodes;    // number of nodes that have to be deleted; [#buckets][#threads]
    std::vector<unsigned int> delete_b_nodes;               // [#buckets], bucket ID of buckets who had some nodes removed
    unsigned int delete_b_nodes_pos;                        // current pos in delete_d_nodes

    // reusable data structures
    std::vector<std::vector<NODE_ID>> b_temp;               // [#threads][sqrt(n)]
    std::vector<unsigned int> b_temp_end;
    std::vector<unsigned int> prefix_sum;

};

template<typename Partition>
constexpr unsigned int BucketListDynamic<Partition>::NULL_BUCKET;

template<typename Partition>
std::ostream &operator<<(std::ostream &o, const BucketListDynamic<Partition> &b)
{
    for(unsigned int b_id = 0; b_id < b.num_buckets; b_id++)
    {
        o << "(";
        for(unsigned int i = 0; i < b.bucket_end[b_id]; i++)
        {
            if(b.buckets[b_id][i] != NULL_NODE)
                o << b.buckets[b_id][i];
            if(i < b.bucket_end[b_id] - 1)
                o << ",";
        }
        o << ")";
    }

    return o;
}

#endif  // _BUCKET_LIST_DYNAMIC_H
