//
// Created by Alex Schickedanz (alex@ae.cs.uni-frankfurt.de)
//

#ifndef _FENG_H
#define _FENG_H

#include <KSP.h>
#include <Dijkstra.h>
#include <GraphRW.h>
#include <queue>
#include <deque>
#include <map>
#include <unordered_map>
#include <algorithm>
#include <utility>

using path_type = std::vector<NODE_ID>;

#ifdef DO_YELLOW_GRAPH_STATS

struct Statistics
{
    // helper to find the right place for statistics
    unsigned int current_k = 0;

    // Source and destination to be able to reproduce the results
    NODE_ID source, destination;
    // The k shortest paths them self
    std::vector<path_type> k_shortest_paths;
    // Number of yellow nodes for each of the k shortest paths and each deviation node
    std::vector<std::vector<size_t>> num_yellow_nodes;
    // Number of edges in the yellow graph for each of the k shortest paths and each deviation node
    std::vector<std::vector<size_t>> num_yellow_edges;
    // Number of red nodes for each of the k shortest paths and each deviation node
    std::vector<std::vector<size_t>> num_red_nodes;
    // Number of in edges to all red notes (most of them are not part of the yellow graph)
    std::vector<std::vector<size_t>> num_red_edges;
    // The length of each of each of the shortest paths
    std::vector<w_type> lengths;
    // The number of hops of each of the shortest paths
    std::vector<unsigned int> hops;
    // Number of nodes a path and its parend share
    std::vector<unsigned int> shared_nodes;
    // Number of nodes a path and its parend share
    std::vector<unsigned int> deviation_node_id;
    // Number of nodes a path and its parend share
    std::vector<unsigned int> parent_id;

    explicit Statistics(const NODE_ID source = 0, const NODE_ID destination = 0, const unsigned int k = 0)
        : source(source),
          destination(destination),
          k_shortest_paths(k),
          num_yellow_nodes(k),
          num_yellow_edges(k),
          num_red_nodes(k),
          num_red_edges(k),
          lengths(k, 0),
          hops(k, 0),
          shared_nodes(k, 0),
          deviation_node_id(k, 0),
          parent_id(k, 0)
    {}

    void print_as_JSON()
    {
        printf(R"(,{"source":%u,"destination":%u,"data":[)", source, destination);
        for(unsigned int i = 0; i <= current_k; ++i)
        {
            if(i > 0)
                printf(",");

            printf(R"({"length":%.5f,"hops":%u,"shared_nodes":%u,"deviation_node_id":%u,"parent_path_id":%u)",
                lengths[i], hops[i], shared_nodes[i], deviation_node_id[i], parent_id[i]);
            printf(",\"num_yellow_nodes\":");
            vector_to_JSON(num_yellow_nodes[i]);
            printf(",\"num_yellow_edges\":");
            vector_to_JSON(num_yellow_edges[i]);
            printf(",\"num_red_nodes\":");
            vector_to_JSON(num_red_nodes[i]);
            printf(",\"num_red_edges\":");
            vector_to_JSON(num_red_edges[i]);
            printf(",\"path\":");
            vector_to_JSON(k_shortest_paths[i]);
            printf("}");
        }

        printf("]}");
    }

private:
    template <typename T>
    void vector_to_JSON(const std::vector<T>& vec)
    {
        if(vec.empty())
        {
            printf("[]");
            return;
        }

        printf("[%lu", static_cast<unsigned long>(vec[0]));
        for(unsigned int j = 1; j < vec.size(); j++)
            printf(",%lu", static_cast<unsigned long>(vec[j]));
        printf("]");
    }
};

#endif

template<template<typename, template<typename> class> class DeltaSteppingType, typename GraphType, unsigned int num_threads, bool pps = false>
class Feng : public KSP<GraphType, num_threads, pps>
{
    using ParentType = KSP<GraphType, num_threads, pps>;
    using DS = DeltaSteppingType<GraphType, KSPGraphLight>;
    using ParentType::parallel_ps;
    using ParentType::orig;
    using ParentType::paths;
    using ParentType::candidates;
    using ParentType::k;
#ifdef PROF
    using ParentType::profiler_statistics;
#endif

    NODE_ID destination = NULL_NODE;

#ifdef DO_YELLOW_GRAPH_STATS
    Statistics stats;
#endif

public:
    explicit Feng(const GraphType& g, const unsigned int k) noexcept
        : ParentType(g, k)
    {}

    /**
     * Computes the k shortest paths from source to destination
     * @param source
     * @param destination
     * @param k The number of
     */
    std::vector<Path> compute(const NODE_ID source, const NODE_ID destination)
    {
        this->destination = destination;
        paths.reserve(k);

        // Calculate T: The SSSP tree rooted in t. (actually T is d.sssp_tree)
        KSPGraphLight<GraphType> reverse_ksp_graph(orig.get_original_graph().get_reverse_graph());
        DS d(reverse_ksp_graph, num_threads);
        d.template compute<false>(
#if defined(PROF) && !defined(KSP_PARALLEL_DEVIATIONS_L2)
            profiler_statistics,
#endif
            destination);

        d.compute_sssp_child_array();

        // Take the shortest path from T.
        // Notice: T is rooted in t, so you have to ask for the path from t to s and reverse it.
        paths.emplace_back(d.get_distance(source), 0, 0, d.get_shortest_path_to(source, true));

#ifdef DO_YELLOW_GRAPH_STATS
        if(!parallel_ps)
        {
            stats = Statistics(source, destination, k);
            stats.k_shortest_paths[0] = paths[0].p;
            stats.hops[0] = static_cast<unsigned int>(paths[0].p.size() - 1);
            stats.lengths[0] = paths[0].length;
        }
#endif

        // Generate G'. This graph differs only in edge weights.
        // They are adjusted to tend more to t than to the other direction.
        const BasicGraph<true, true> g_prime = GraphRW::generate_fengs_g_prime(orig.get_original_graph(), d.get_sssp_tree(), true);

        // The edges that are already used for a deviation. They have to be excluded for the next deviations
        // For each path a vector of forbidden neighbors is stored.
        // dev_edges[i] is a vector of nodes such that (u,path[i][0]), ... ,(u,path[i][j]) are edges, that are already
        // used for a deviation. u is the node where the i-th path deviated from an other path.
        std::vector<std::vector<NODE_ID>> dev_edges(k);            // stores the forbidden edges

        // The shortest path is already found. Compute the next k-1 shortest paths.
        for(unsigned int i = 1; i < k; i++)
        {
#ifdef DO_YELLOW_GRAPH_STATS
            if(!parallel_ps)
            {
                stats.current_k = i;
                stats.num_yellow_nodes[stats.current_k] = std::vector<size_t>(paths[i - 1].alpha, 0);
                stats.num_yellow_edges[stats.current_k] = std::vector<size_t>(paths[i - 1].alpha, 0);
            }
#endif
            if(num_threads > 1 && parallel_ps)
                compute_candidates_parallel(i, g_prime, d.get_sssp_tree(), dev_edges[i - 1]);
            else
                compute_candidates_sequential(i, g_prime, d.get_sssp_tree(), dev_edges[i - 1]);

            // if there are no candidates left, there are less than k paths at all.
            if(candidates.empty())
                break;

            // Take the shortest path in the candidates queue
            auto next_shortest_path = candidates.get_best();

            // attach the prefix that was left out before. The length is already correct.
            next_shortest_path.p.insert(next_shortest_path.p.begin(),
                                        paths[next_shortest_path.parent_index].p.begin(),
                                        paths[next_shortest_path.parent_index].p.begin() + next_shortest_path.alpha);
            paths.push_back(next_shortest_path);

#ifdef DO_YELLOW_GRAPH_STATS
            if(!parallel_ps)
            {
                stats.k_shortest_paths[stats.current_k] = next_shortest_path.p;
                stats.hops[stats.current_k] = static_cast<unsigned int>(next_shortest_path.p.size() - 1);
                stats.lengths[stats.current_k] = next_shortest_path.length;
                for(auto u : next_shortest_path.p)
                    if(std::find(paths[next_shortest_path.parent_index].p.begin(),
                                 paths[next_shortest_path.parent_index].p.end(), u) !=
                       paths[next_shortest_path.parent_index].p.end())
                        stats.shared_nodes[stats.current_k]++;
                stats.parent_id[stats.current_k] = next_shortest_path.parent_index;
                stats.deviation_node_id[stats.current_k] = next_shortest_path.alpha;
            }
#endif

            // add the edge it uses to deviate from the previous path to the forbidden edges.
            if(paths[i].alpha == paths[paths[i].parent_index].alpha)
                // remember all edges that where forbidden for this prefix
                dev_edges[i] = dev_edges[paths[i].parent_index];
            // remember also the new edge that shouldn't be taken again.
            dev_edges[i].push_back(paths[paths[i].parent_index].p[paths[i].alpha + 1]);
        }

        return paths;
    }

#ifdef DO_YELLOW_GRAPH_STATS
    Statistics get_stats() const
    {
        return stats;
    }
#endif

private:
    void compute_candidates_sequential(const unsigned int i, const BasicGraph<true, true>& g_prime,
                                       const SsspTree& dest_rooted_sssp_tree, const std::vector<NODE_ID>& dev_edges) noexcept
    {
        const std::vector<NODE_ID> empty_dev_edges;

        // calculate for every node w between v and t the new deviation candidate.
        // v is the node the (i-1)-th path is deviated from, so the nodes before v already
        // have candidates in the priority queue
        std::set<NODE_ID> red_nodes;
        red_nodes.insert(paths[i - 1].p.begin(), paths[i - 1].p.begin() + paths[i - 1].alpha);
        w_type prefix_length = orig.get_original_graph().get_path_length(paths[i - 1].p, paths[i - 1].alpha);

        const auto end = static_cast<NODE_ID>(paths[i - 1].p.size() - 1);
        for(NODE_ID u_pos_in_path = paths[i - 1].alpha; u_pos_in_path < end;
            // update the prefix length
            prefix_length += orig.get_original_graph().get_edge_weight(paths[i - 1].p[u_pos_in_path], paths[i - 1].p[u_pos_in_path + 1]), u_pos_in_path++)
        {
            const NODE_ID u = paths[i - 1].p[u_pos_in_path];
            const NODE_ID u_successor = paths[i - 1].p[u_pos_in_path + 1];
            // update the red nodes
            red_nodes.insert(u);

            Path new_candidate = compute_deviations(g_prime, red_nodes, u, dest_rooted_sssp_tree,
                                                    u_pos_in_path == paths[i-1].alpha ? dev_edges : empty_dev_edges,
                                                    u_successor, num_threads);
            // check if the path is empty
            if(new_candidate.p.empty() || new_candidate.length > candidates.get_length_threshold())
                continue;

            new_candidate.alpha = u_pos_in_path;
            new_candidate.parent_index = i - 1;
            new_candidate.length += prefix_length;   // add the prefix. the suffix weight is already correct

            candidates.insert(std::move(new_candidate));
        }
    }

    void compute_candidates_parallel(const unsigned int i, const BasicGraph<true, true>& g_prime,
                                       const SsspTree& dest_rooted_sssp_tree, const std::vector<NODE_ID>& dev_edges) noexcept
    {
        const std::vector<NODE_ID> empty_dev_edges;

        // calculate for every node w between v and t the new deviation candidate.
        // v is the node the (i-1)-th path is deviated from, so the nodes before v already
        // have candidates in the priority queue

        const auto end = static_cast<NODE_ID>(paths[i - 1].p.size() - 1);
#pragma omp parallel for schedule(dynamic) num_threads(num_threads)
        for(NODE_ID u_pos_in_path = paths[i - 1].alpha; u_pos_in_path < end; u_pos_in_path++)
        {
            const NODE_ID u = paths[i - 1].p[u_pos_in_path];
            const NODE_ID u_successor = paths[i - 1].p[u_pos_in_path + 1];
            // set red nodes
            std::set<NODE_ID> red_nodes;
            red_nodes.insert(paths[i - 1].p.begin(), paths[i - 1].p.begin() + u_pos_in_path + 1);

            Path new_candidate = compute_deviations(g_prime, red_nodes, u, dest_rooted_sssp_tree,
                                                    u_pos_in_path == paths[i-1].alpha ? dev_edges : empty_dev_edges,
                                                    u_successor, 1);
            // check if the path is empty
            if(new_candidate.p.empty() || new_candidate.length > candidates.get_length_threshold())
                continue;

            new_candidate.alpha = u_pos_in_path;
            new_candidate.parent_index = i - 1;
            new_candidate.length += orig.get_original_graph().get_path_length(paths[i - 1].p, u_pos_in_path);   // add the prefix. the suffix weight is already correct

#pragma omp critical
            {
                candidates.insert(std::move(new_candidate));
            }
        }
    }


private:

    struct YellowGraph
    {
        BasicGraph<true, true> G;
        // todo the following cannot be constant, if the yellow graph has to be modified for the optimized version
        const std::vector<NODE_ID> map_new_nodes_to_old_nodes;
        const std::unordered_map<NODE_ID, NODE_ID> map_shortcuts_to_original_target;
        const NODE_ID u_new;
        const NODE_ID destination_new; // todo if destination is always the first node, it can be always set to zero. So it don't have to be stored and checks against zero are fast

        /**
         * @param yellow_graph_nodes                Nodes of the yellow graph also containing a sentinel at the end.
         * @param yellow_graph_edges                Edges of the yellow graph.
         * @param heaviest_weight                   Heaviest weight of any edge of the yellow graph.
         * @param map_new_nodes_to_old_nodes        A map from new node id's to the original node id's.
         * @param map_shortcuts_to_original_target  A map from shortcut edges to the original target of that edge.
         * @param u_new                             The new id of the deviation node.
         * @param destination_new                   The new id if the destination.
         */
        YellowGraph(std::vector<Node>& yellow_graph_nodes, std::vector<Edge<true, true>>& yellow_graph_edges,
                     w_type heaviest_weight, std::vector<NODE_ID> map_new_nodes_to_old_nodes,
                     std::unordered_map<NODE_ID, NODE_ID> map_shortcuts_to_original_target,
                     NODE_ID u_new, NODE_ID destination_new, const w_type delta) noexcept
            : G(yellow_graph_nodes, yellow_graph_edges, heaviest_weight, delta),
              map_new_nodes_to_old_nodes(std::move(map_new_nodes_to_old_nodes)),
              map_shortcuts_to_original_target(std::move(map_shortcuts_to_original_target)),
              u_new(u_new),
              destination_new(destination_new)
        {}

        /**
         * Replaces the nodes in path by their original indexes. This happens in place.
         * It is assumed that the last node in path is the new_destination. So this is part of a shortcut
         * and gets mapped back to the original edge.
         * @param path A path of new named nodes. They get overwritten with the original nodes
         */
        void map_to_original_nodes(path_type& path) const noexcept
        {
            // map the shortcut to the original edge
            path.back() = map_shortcuts_to_original_target.find(path[path.size() - 2])->second;

            for(size_t i = 0; i < path.size() - 1; i++)
            {
                path[i] = map_new_nodes_to_old_nodes[path[i]];
            }
        }
    };

    /**
     * Generates a yellow graph.
     * @param g_prime       The original graph with modified edge weights. Due to the modified weight it is alwalys direccted and weighted.
     * @param red_nodes     The Set of red nodes.
     * @param u             The current deviation node. It is also red
     * @param yellow_nodes  The set of Yellow nodes.
     * @param dev_edges     Edges the deviation path cannot take.
     * @param u_successor   The successor of u in the path the deviation is computed from.
     * @return
     */
    YellowGraph create_yellow_graph(const BasicGraph<true, true>& g_prime, const std::set<NODE_ID>& red_nodes, const NODE_ID u,
                                     const std::vector<NODE_ID>& yellow_nodes, const std::vector<NODE_ID>& dev_edges, const NODE_ID u_successor, bool used_by_delta_stepping) noexcept
    {
        // The yellow graph contains t + all yellow nodes + u + sentinel.
        // Only u is really needed as a red node, but since red nodes only have out-edges the could also be in.
        std::vector<Node> yellow_graph_nodes(yellow_nodes.size() + 3);

        // generate a mapping to get back to the original nodes
        std::vector<NODE_ID> map_new_nodes_to_old_nodes;
        map_new_nodes_to_old_nodes.reserve(yellow_nodes.size() + 2);    // the sentinel don't needs to be mapped anywhere

        // t will be at the front so it has always the node id zero.
        map_new_nodes_to_old_nodes.push_back(destination);
        const NODE_ID new_destination = 0;

        // then all yellow nodes. They stay in the graph, even if it gets updated in the optimized version
        // since t is the first node, the yellow nodes get the id 1 to yellow_nodes.size()
        map_new_nodes_to_old_nodes.insert(map_new_nodes_to_old_nodes.end(), yellow_nodes.begin(), yellow_nodes.end());

        // u is the only red node in the graph. If the graph gets updated it will be removed, so it has to be at the end.
        const auto new_u = static_cast<NODE_ID>(map_new_nodes_to_old_nodes.size());
        map_new_nodes_to_old_nodes.push_back(u);

        // generate map from original nodes to yellow nodes
        std::unordered_map<NODE_ID, NODE_ID> map_old_nodes_to_yellow_nodes;
        for(unsigned int i = 1; i <= yellow_nodes.size(); i++)
            // 0 is the destination so the first yellow node has the ID 1
            map_old_nodes_to_yellow_nodes[map_new_nodes_to_old_nodes[i]] = i;

        // maps shortcuts (y,t) back to the original edge (y,w) by storing only y and w. so v -> w means (v,t) -> (v,w).
        // Notice: y is stored as a new id (y_new in the yellow graph), w is stored as the original node id
        std::unordered_map<NODE_ID, NODE_ID> map_shortcuts_to_original_target;

        // Now the mapping is finished, so we can create the edges.
        // We can skip the destination, since it don't has out-edges.
        // The edges of u are an extra case
        std::vector<Edge<true, true>> yellow_graph_edges;
        w_type heaviest_yellow_edge_weight = 0;

#ifdef DO_YELLOW_GRAPH_STATS
        size_t num_red_edges = 0;
#endif

        NODE_ID y_new = 1;
        for(const auto y_old : yellow_nodes)
        {
            auto shortcut_edge_id = NULL_EDGE;
            yellow_graph_nodes[y_new + 1].start_edge += yellow_graph_nodes[y_new].start_edge;   // works because there is u at the end as a sentinel
            const auto edge_list_end_id = g_prime.get_edge_list_end(y_old);
            for(auto edge_y_to_w_id = g_prime.get_edge_list_begin(y_old); edge_y_to_w_id < edge_list_end_id; ++edge_y_to_w_id)
            {
                const auto& edge_y_to_w = g_prime.get_edge(edge_y_to_w_id);

                if(edge_y_to_w.get_weight() == INFINITE_DISTANCE)
                {
                    // todo add statistics here
                    continue;
                }

                // w is the target node of the edge (y,w), but find returns an pointer to the pair in the map,
                // so the ID of w is in w->second
                const auto new_w = map_old_nodes_to_yellow_nodes.find(edge_y_to_w.get_target());
                if(new_w != map_old_nodes_to_yellow_nodes.end())    // w is yellow
                {
                    yellow_graph_edges.emplace_back(new_w->second, edge_y_to_w.get_weight());
                    heaviest_yellow_edge_weight = std::max(heaviest_yellow_edge_weight, edge_y_to_w.get_weight());
                    yellow_graph_nodes[y_new + 1].start_edge++;
                }
                else if(red_nodes.count(edge_y_to_w.get_target()) == 0)  // we know w is not yellow => check if w is also not red => if "yes", it is green
                {
                    if(shortcut_edge_id == NULL_EDGE)       // if there is no shortcut from this to t yet
                    {
                        shortcut_edge_id = yellow_graph_edges.size();   // just to remember the position of the shortcut edge
                        map_shortcuts_to_original_target[y_new] = edge_y_to_w.get_target();   // this is the original node since there is no corresponding node in the new graph
                        yellow_graph_edges.emplace_back(new_destination, edge_y_to_w.get_weight());  // a shortcut has to have the length of the whole path it shortcuts. The path has the length zero in G'
                        heaviest_yellow_edge_weight = std::max(heaviest_yellow_edge_weight, edge_y_to_w.get_weight());
                        yellow_graph_nodes[y_new + 1].start_edge++;
                    }
                    else    // shortcut already exists
                    {
                        if(yellow_graph_edges[shortcut_edge_id].get_weight() > edge_y_to_w.get_weight())   // is the new shortcut shorter?
                        {
                            yellow_graph_edges[shortcut_edge_id].set_weight(edge_y_to_w.get_weight());
                            map_shortcuts_to_original_target[y_new] = edge_y_to_w.get_target();
                        }
                    }
                }
#ifdef DO_YELLOW_GRAPH_STATS
                else
                {
                    // w is red, so edge_y_to_w is a red edge
                    num_red_edges++;
                }
#endif
            }

            y_new++;
        }

        // add the edges (u,w) which are not forbidden
        auto shortcut_edge_id = NULL_EDGE;
        assert(y_new == yellow_graph_nodes.size() - 2);     // this means u = y_new, be aware of the sentinel
        assert(yellow_graph_nodes[y_new].start_edge == yellow_graph_edges.size()); // this means u has no edges yet
        const auto edge_list_end_id = g_prime.get_edge_list_end(u);
        for(auto edge_u_to_w_id = g_prime.get_edge_list_begin(u); edge_u_to_w_id < edge_list_end_id; ++edge_u_to_w_id)
        {
            const auto& edge_u_to_w = g_prime.get_edge(edge_u_to_w_id);
            // make sure not to use forbidden edges or the next node the path currently deviates from
            if(edge_u_to_w.get_weight() == INFINITE_DISTANCE || std::find(dev_edges.begin(), dev_edges.end(), edge_u_to_w.get_target()) != dev_edges.end() || edge_u_to_w.get_target() == u_successor)
                continue;

            // w is the target node of the edge (u,w), but find returns an pointer to the pair in the map,
            // so the ID of w is in w->second
            auto new_w = map_old_nodes_to_yellow_nodes.find(edge_u_to_w.get_target());
            if(new_w != map_old_nodes_to_yellow_nodes.end())    // w is yellow
            {
                yellow_graph_edges.emplace_back(new_w->second, edge_u_to_w.get_weight());
                heaviest_yellow_edge_weight = std::max(heaviest_yellow_edge_weight, edge_u_to_w.get_weight());
            }
            else if(red_nodes.count(edge_u_to_w.get_target()) == 0)   // we know w is not yellow => check if w is also not red => if "yes", it is green
            {
                if(shortcut_edge_id == NULL_EDGE)   // if there is no shortcut from this node to t yet
                {
                    shortcut_edge_id = yellow_graph_edges.size();   // just to remember the position of the shortcut edge
                    map_shortcuts_to_original_target[y_new] = edge_u_to_w.get_target();   // this is the original node since there is no corresponding node in the new graph
                    yellow_graph_edges.emplace_back(new_destination, edge_u_to_w.get_weight());
                    heaviest_yellow_edge_weight = std::max(heaviest_yellow_edge_weight, edge_u_to_w.get_weight());
                }
                else    // shortcut already exists
                {
                    if(yellow_graph_edges[shortcut_edge_id].get_weight() > edge_u_to_w.get_weight())   // is the new shortcut shorter?
                    {
                        yellow_graph_edges[shortcut_edge_id].set_weight(edge_u_to_w.get_weight());
                        map_shortcuts_to_original_target[y_new] = edge_u_to_w.get_target();
                    }
                }
            }
        }

        // setting he sentinel right
        yellow_graph_nodes.back().start_edge = yellow_graph_edges.size();

#ifdef DO_YELLOW_GRAPH_STATS
        if(!parallel_ps)
        {
            stats.num_yellow_nodes[stats.current_k].push_back(yellow_graph_nodes.size() - 2);   // be aware of the sentinel and the one red node in there
            stats.num_yellow_edges[stats.current_k].push_back(yellow_graph_edges.size());
            stats.num_red_nodes[stats.current_k].push_back(red_nodes.size());
            stats.num_red_edges[stats.current_k].push_back(num_red_edges);
        }
#endif

        // for delta stepping the edges have to be sorted by edge weight and classified into light and heavy edges.
        if(used_by_delta_stepping)
        {
            GraphRW::partition_edges_by_weight<true, true>(yellow_graph_nodes, yellow_graph_edges, g_prime.get_delta());
        }

        return YellowGraph(yellow_graph_nodes, yellow_graph_edges, heaviest_yellow_edge_weight, map_new_nodes_to_old_nodes,
                            map_shortcuts_to_original_target, new_u, new_destination, g_prime.get_delta());
    }

    /**
     * Computes a vector of yellow nodes from the reverse shortest path tree T and the set od red nodes R
     * @param dest_rooted_sssp_tree The reverse shortest path tree with original edge weights and rooted in the destination t
     * @param red_nodes A set of the red nodes
     * @return A vector of yellow nodes
     */
    std::vector<NODE_ID> compute_yellow_nodes(const SsspTree& dest_rooted_sssp_tree, const std::set<NODE_ID>& red_nodes) const noexcept
    {
        std::vector<NODE_ID> Y;
        std::queue<NODE_ID> Q;

        // add all children of red nodes to the queue, als long as they are not red them self
        for(NODE_ID v : red_nodes)
        {
            for(auto c = dest_rooted_sssp_tree.get_children_begin(v), end = dest_rooted_sssp_tree.get_children_end(v); c != end; c++)
            {
                if(red_nodes.find(*c) == red_nodes.end())   // child is not red
                    Q.push(*c);
            }
        }

        while(!Q.empty())
        {
            auto q = Q.front();
            Q.pop();

            // If q is red, it must not be yellow. Its children are already in q, so we have nothing to do.
            if(red_nodes.find(q) != red_nodes.end())
                continue;

            Y.push_back(q);
            for(auto c = dest_rooted_sssp_tree.get_children_begin(q), end = dest_rooted_sssp_tree.get_children_end(q); c != end; c++)
            {
                Q.push(*c);
            }
        }

        return Y;
    }

    /**
     * Computes a deviation from the node u. The path contains only the suffix including the deviation node u.
     * It has the original weight, not the weight it would have in G'.
     * @param g_prime               The graph with modified edge weights
     * @param red_nodes             The Set of red nodes. It contains all nodes of the current path to (and including) the deviation node
     * @param u                     The current deviation node
     * @param dest_rooted_sssp_tree A shortest path tree rooted in the destination t
     * @param dev_edges             A List of all neighbors of u that ar not allowed for deviation
     * @param u_successor           The successor in the path the deviation is calculated from
     * @return                      A new deviation path. If there is no new deviation, an empty path is returned.
     */
    Path compute_deviations(const BasicGraph<true, true>& g_prime, const std::set<NODE_ID>& red_nodes, const NODE_ID u,
                            const SsspTree& dest_rooted_sssp_tree, const std::vector<NODE_ID>& dev_edges, const NODE_ID u_successor,
                            const unsigned int num_sssp_threads) noexcept
    {
        const std::vector<NODE_ID> Y = compute_yellow_nodes(dest_rooted_sssp_tree, red_nodes);
        /* todo for the improved sequential version the yellow graph needs to be updated.
           therefore some edges may have to be removed, red nodes have to be in the graph, shortcuts have to be changed.
           one node becomes red. if it was green the shortcuts need to be updated. if it was yellow the in-edges have to be removed */
//        YellowGraph yellow_graph(create_yellow_graph(g_prime, red_nodes, u, Y, dev_edges, u_successor, true));
        YellowGraph yellow_graph = create_yellow_graph(g_prime, red_nodes, u, Y, dev_edges, u_successor, true);

        // todo add a shortcut: if the shortest edge from u leads to a green node, this is the new shortest path (no sssp call needed)
        path_type sub_path;
        w_type length;

        // if the deviation node has no out-edges or the destination has no in-edges we can stop here.
        if(yellow_graph.G.get_edge_list_begin(yellow_graph.u_new) == yellow_graph.G.get_edge_list_end(yellow_graph.u_new)
            || yellow_graph.map_shortcuts_to_original_target.size() == 0)
            return Path();

        if(skip_sssp(yellow_graph, length))
        {
            // length is already set by skip_sssp()
            sub_path = {yellow_graph.u_new, yellow_graph.destination_new};
        }
        else
        {
            // Compute the path from u to t in the yellow graph.
            // This results in a path from u to v, where v is the first green node, because of the shortcuts.
            KSPGraphLight<BasicGraph<true, true>> yellow_ksp(yellow_graph.G);
            DeltaSteppingType<BasicGraph<true, true>, KSPGraphLight> d(yellow_ksp, num_sssp_threads);   // todo
            d.template compute<SSSP_EARLY_STOPPING>(
#if defined(PROF) && !defined(KSP_PARALLEL_DEVIATIONS_L2)
                profiler_statistics,
#endif
                yellow_graph.u_new, yellow_graph.destination_new);

            // check if the destination is connected to u. If not, there is just no new deviation from u
            if(!d.is_connected_to_source(yellow_graph.destination_new))
                return Path();  // empty path returned

            sub_path = d.get_shortest_path_to(yellow_graph.destination_new);
            length = d.get_distance(yellow_graph.destination_new);
        }

        // Map the sub path back to the original nodes
        yellow_graph.map_to_original_nodes(sub_path);

        // Get the path from t to v. This is hidden in the shortcut
        path_type suffix = dest_rooted_sssp_tree.get_shortest_path(sub_path.back(), true);

        // Put the path together. s to u from the (i-1)-th path, u to v from the yellow graph and v to t from the SSSP tree dest_rooted_sssp_tree
        Path deviation;
        // the prefix gets attached if this candidate gets chosen as a shortest path
        deviation.p.insert(deviation.p.end(), sub_path.begin(), sub_path.end() - 1);    // append the sub path not including the end node
        deviation.p.insert(deviation.p.end(), suffix.begin(), suffix.end());            // append the path from

        // set the length of this sub path in G (not in G')
        deviation.length = length + dest_rooted_sssp_tree.get_distance(u);

        return deviation;
    }

    /**
     * Checks if the closest neighbor of the deviation node u is the destination.
     * In this case we can skip the SSSP call and directly use the path u, dest.
     * It is assumed that u_new has at least one out edge.
     * @param yellow_graph reference to the yellow graph.
     * @param[out] length
     * @return Returns true, if we can skip the sssp call. If true is returned the length will be set to the right value.
     */
    bool skip_sssp(const YellowGraph& yellow_graph, w_type& length)
    {
        const auto edge_list_end = yellow_graph.G.get_edge_list_end_iter(yellow_graph.u_new);
        const auto closest = std::min_element(yellow_graph.G.get_edge_list_begin_iter(yellow_graph.u_new),
                                              edge_list_end,
                                              [](const auto& l, const auto& r) -> bool
                                              {
                                                  return l.get_weight() < r.get_weight();
                                              }
        );

        length = closest->get_weight();
        return closest->get_target() == yellow_graph.destination_new;
    }

};

#endif  // _FENG_H
