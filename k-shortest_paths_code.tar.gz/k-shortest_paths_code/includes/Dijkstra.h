//
// Created by Alex Schickedanz <alex@ae.cs.uni-frankfurt.de> on 09.03.17.
//

#ifndef _DIJKSTRA_H
#define _DIJKSTRA_H

#include "Node.h"
#include "BasicGraph.h"
#include "PriorityQueue.h"

#include <cassert>
#include <algorithm>

template<typename GraphType>
class Dijkstra
{
    struct sssp_tree_node
    {
        w_type tend_distance;
        NODE_ID parend_id;

        explicit sssp_tree_node(w_type tend_distance = INFINITE_DISTANCE)
            : tend_distance(tend_distance),
              parend_id(NULL_NODE)
        {}

        friend bool operator < (const sssp_tree_node& a, const sssp_tree_node& b)
        {
            return a.tend_distance < b.tend_distance;
        }
    };

    const GraphType& g;

    std::vector<sssp_tree_node> m_sssp_tree;

public:
    explicit Dijkstra(const GraphType& g)
        : g(g),
          m_sssp_tree(g.get_num_nodes())
    {}

    /**
     * Runs Dijkstra's algorithm on the graph. If a destination is provided, the algorithm stops as soon as the  shortest path
     * to destination is found.
     * @param source
     * @param destination
     */
    template<bool stop_early = false>
    void compute_sssp(const NODE_ID source, const NODE_ID destination = NULL_NODE)
    {
        const auto* const_this = this;
        auto cmp = [const_this](const NODE_ID a, const NODE_ID b) -> bool {
            return const_this->m_sssp_tree[a].tend_distance < const_this->m_sssp_tree[b].tend_distance
                   || (const_this->m_sssp_tree[a].tend_distance == const_this->m_sssp_tree[b].tend_distance && a < b);
        };

        auto dist_updater = [this](const NODE_ID node, const w_type new_dist){
            m_sssp_tree[node].tend_distance = new_dist;
        };

        PriorityQueue<NODE_ID, decltype(cmp), w_type, decltype(dist_updater)> unvisited_nodes(cmp, dist_updater);

        m_sssp_tree[source].tend_distance = 0;

        unvisited_nodes.push(source);

        while(!unvisited_nodes.empty())
        {
            NODE_ID current_node = unvisited_nodes.top();

            if(stop_early && current_node == destination)
                break;

            unvisited_nodes.pop();

            for(auto neighbor = g.get_edge_list_begin_iter(current_node);
                neighbor != g.get_edge_list_end_iter(current_node); ++neighbor)
            {
                const w_type new_distance = m_sssp_tree[current_node].tend_distance + neighbor->get_weight();

                auto& tree_node = m_sssp_tree[neighbor->get_target()];
                if(tree_node.tend_distance > new_distance) // distance gets updated
                {
                    tree_node.parend_id = current_node;

                    if(tree_node.tend_distance == INFINITE_DISTANCE)
                        unvisited_nodes.push(neighbor->get_target(), new_distance);
                    else
                        unvisited_nodes.update_key(neighbor->get_target(), new_distance);
                }
            }
        }
    }

    /**
     * Checks if the node is connected to the source. Notice: If a destination was provided for compute_sssp, every node
     * with a bigger distance from the source than the destination is "disconnected".
     * @param node
     * @return
     */
    bool is_connected_to_source(const NODE_ID node) const
    {
        assert(node < m_sssp_tree.size());
        return m_sssp_tree[node].tend_distance < INFINITE_DISTANCE;
    }

    /**
     * Returns the distance of the node to the source. If it is not connected, infinity is returned. If a destination was
     * provided for compute_sssp every distance bigger than the distance between source and destination is infinity.
     * @param node
     * @return
     */
    w_type get_distance(const NODE_ID node) const
    {
        return m_sssp_tree[node].tend_distance;
    }

    /**
     * Returns the path from the source to a node as a vector of nodes. It is asserted that the node is connected to
     * the source
     * @param node
     * @return
     */
    std::vector<NODE_ID> get_shortest_path_to(const NODE_ID node, const bool get_reverse_path = false) const
    {
        assert(m_sssp_tree[node].tend_distance < INFINITE_DISTANCE);

        std::vector<NODE_ID> path;

        path.push_back(node);
        NODE_ID current_node = node;

        while(m_sssp_tree[current_node].parend_id != NULL_NODE)
        {
            current_node = m_sssp_tree[current_node].parend_id;
            path.push_back(current_node);
        }

        if(!get_reverse_path)
            std::reverse(path.begin(), path.end());

        return path;
    }
};

#endif  // _DIJKSTRA_H
