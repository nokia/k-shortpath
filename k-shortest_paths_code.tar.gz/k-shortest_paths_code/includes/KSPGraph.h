#ifndef _KSP_GRAPH_H
#define _KSP_GRAPH_H

#include <BasicGraph.h>
#include <vector>
#include <queue>

template<typename GraphType>
class KSPGraph
{
public:
    class const_edge_iterator
    {
    private:
        using edge_type = Edge<GraphType::is_directed, GraphType::is_weighted>;

        const GraphType& g;
        const std::vector<bool>& edge_is_removed;
        const EDGE_ID end_index;

        EDGE_ID index;

    public:
        explicit const_edge_iterator(const KSPGraph<GraphType>* e, const EDGE_ID start_index, const EDGE_ID end_index) noexcept
            : g(e->g), edge_is_removed(e->edge_is_removed), end_index(end_index), index(start_index)
        {
            // fixing the index in case the start_index is already invalid.
            while(edge_is_removed[index] && index < end_index)
                index++;
        }

        bool operator==(const const_edge_iterator& rhs) const noexcept
        {
            return index == rhs.index;
        }

        bool operator!=(const const_edge_iterator& rhs) const noexcept
        {
            return index != rhs.index;
        }

        bool operator<(const const_edge_iterator& rhs) const noexcept
        {
            return index < rhs.index;
        }

        const edge_type& operator*() const noexcept
        {
            return g.get_edge(index);
        }

        const edge_type* operator->() const noexcept
        {
            return &g.get_edge(index);
        }

        const_edge_iterator& operator++() noexcept
        {
            for(++index; index < end_index && edge_is_removed[index]; ++index) {}
            return *this;
        }

        explicit operator EDGE_ID() const noexcept
        {
            return index;
        }
    };

private:
    const GraphType& g;
    std::queue<EDGE_ID> removed;
    std::vector<bool> edge_is_removed;

public:
    explicit KSPGraph(const GraphType& graph) noexcept
        : g(graph),
          edge_is_removed(g.get_num_edges(), false)
    {}

    NODE_ID get_num_nodes() const noexcept { return g.get_num_nodes(); }

    EDGE_ID get_num_edges() const noexcept { return g.get_num_edges(); }

    /**
     * Returns an iterator to the first edge starting in node, that is not removed.
     * @param node
     * @tparam w_class
     * @return
     */
    const_edge_iterator begin(const NODE_ID node) const noexcept
    {
        return const_edge_iterator(this, g.get_edge_list_begin(node), g.get_edge_list_end(node));
    }

    const_edge_iterator begin_light(const NODE_ID node) const noexcept
    {
        return const_edge_iterator(this, g.get_edge_list_begin(node), g.get_light_edge_list_end(node));
    }

    const_edge_iterator begin_heavy(const NODE_ID node) const noexcept
    {
        return const_edge_iterator(this, g.get_heavy_edge_list_begin(node), g.get_edge_list_end(node));
    }

    /**
     * Returns an iterator to the end of the edge list of the node.
     * @param node
     * @return
     */
    const_edge_iterator end(const NODE_ID node) const noexcept
    {
        return const_edge_iterator(this, g.get_edge_list_end(node), g.get_edge_list_end(node));
    }

    /**
     * Returns an iterator to the end of the light edge list of the node.
     * @param node
     * @return
     */
    const_edge_iterator end_light(const NODE_ID node) const noexcept
    {
        return const_edge_iterator(this, g.get_light_edge_list_end(node), g.get_light_edge_list_end(node));
    }

    /**
     * Returns an iterator to the end of the heavy edge list of the node. This is only an alias for end(node) since the
     * end of the heavy edge list and the total edge list is the same.
     * @param node
     * @return
     */
    const_edge_iterator end_heavy(const NODE_ID node) const noexcept
    {
        return end(node);
    }

    /**
     * Returns an iterator to the edge [src,target] or the iterator to end(src) if
     * the edge does not exist. You need to check this!
     * @param src
     * @param target
     * @return
     */
    const_edge_iterator get_edge_iterator(const NODE_ID src, const NODE_ID target) const noexcept
    {
        const auto end_edge = end(src);
        for(auto it = begin(src); it < end_edge; ++it)
        {
            if(it->get_target() == target)
                return it;
        }

        return end_edge;
    }

    void remove_node(const NODE_ID node) noexcept
    {
        const EDGE_ID edge_list_end = g.get_edge_list_end(node);
        for(EDGE_ID e_id = g.get_edge_list_begin(node); e_id < edge_list_end; e_id++)
        {
            if(edge_is_removed[e_id])
                continue;

            removed.push(e_id);

            edge_is_removed[e_id] = true;

            if(!GraphType::is_directed)
                remove_backwards_edge(g.get_backwards_edge_id(e_id));
        }
    }

    void remove_edge(const KSPGraph::const_edge_iterator& it) noexcept
    {
        const auto e_id = static_cast<EDGE_ID>(it);

        if(edge_is_removed[e_id])
            return;

        removed.push(e_id);        // todo can we avoid this?

        edge_is_removed[e_id] = true;

        if(!GraphType::is_directed)
            remove_backwards_edge(g.get_backwards_edge_id(e_id));
    }

    /**
     * Restores every removed edge.
     */
    void restore_graph() noexcept
    {
        while(!removed.empty())
        {
            edge_is_removed[removed.front()] = false;
            removed.pop();
        }
    }

    const GraphType& get_original_graph() const noexcept
    {
        return g;
    }

    w_type get_delta() const noexcept { return g.get_delta(); }

    double get_avg_degree() const noexcept { return g.get_avg_degree(); }

    NODE_ID get_num_neighbors(const NODE_ID node) const noexcept { return g.get_num_neighbors(node); }

    unsigned int compute_bucket_size() const noexcept { return g.compute_bucket_size(); }

    void print_graph() const noexcept
    {
        for(NODE_ID i = 0; i < get_num_nodes(); i++)
        {
            std::cout << "node " << i << std::endl;
            for(auto it = begin(i); it < end(i); ++it)
            {
                std::cout << *it << std::endl;
            }
        }
    }

private:

    /**
     * Removes a backwards edge.
     * @param e
     */
    void remove_backwards_edge(const EDGE_ID e) noexcept
    {
        if(!edge_is_removed[e])
        {
            removed.push(e);   // todo can we avoid this?
            edge_is_removed[e] = true;
        }
    }
};

/**
 * The same as KSPGraph but without the ability to remove edges. So this is just a container providing iterators for delta stepping.
 * @tparam GraphType
 */
template<typename GraphType>
class KSPGraphLight
{
public:
    // todo the edge iterator is actually used to iterate over neighbours of a node only (!). So it is a neighbour iterator.
    class const_edge_iterator
    {
    private:
        using edge_type = Edge<GraphType::is_directed, GraphType::is_weighted>;

        const GraphType& g;
        const EDGE_ID end_index;

        EDGE_ID index;

    public:
        explicit const_edge_iterator(const GraphType& g, const EDGE_ID start_index, const EDGE_ID end_index) noexcept
            : g(g), end_index(end_index), index(start_index)
        {}

        bool operator==(const const_edge_iterator& rhs) const noexcept
        {
            return index == rhs.index;
        }

        bool operator!=(const const_edge_iterator& rhs) const noexcept
        {
            return index != rhs.index;
        }

        bool operator<(const const_edge_iterator& rhs) const noexcept
        {
            return index < rhs.index;
        }

        const edge_type& operator*() const noexcept
        {
            return g.get_edge(index);
        }

        const edge_type* operator->() const noexcept
        {
            return &g.get_edge(index);
        }

        const_edge_iterator& operator++() noexcept
        {
            index++;
            return *this;
        }

        explicit operator EDGE_ID() const noexcept
        {
            return index;
        }
    };

private:
    const GraphType& g;

public:
    explicit KSPGraphLight(const GraphType& graph) noexcept
        : g(graph)
    {}

    NODE_ID get_num_nodes() const noexcept { return g.get_num_nodes(); }

    EDGE_ID get_num_edges() const noexcept { return g.get_num_edges(); }

    /**
     * Returns an iterator to the first edge starting in node, that is not removed.
     * @param node
     * @tparam w_class
     * @return
     */
    const_edge_iterator begin(const NODE_ID node) const noexcept
    {
        return const_edge_iterator(g, g.get_edge_list_begin(node), g.get_edge_list_end(node));
    }

    const_edge_iterator begin_light(const NODE_ID node) const noexcept
    {
        return const_edge_iterator(g, g.get_edge_list_begin(node), g.get_light_edge_list_end(node));
    }

    const_edge_iterator begin_heavy(const NODE_ID node) const noexcept
    {
        return const_edge_iterator(g, g.get_heavy_edge_list_begin(node), g.get_edge_list_end(node));
    }

    /**
     * Returns an iterator to the end of the edge list of the node.
     * @param node
     * @return
     */
    const_edge_iterator end(const NODE_ID node) const noexcept
    {
        return const_edge_iterator(g, g.get_edge_list_end(node), g.get_edge_list_end(node));
    }

    /**
     * Returns an iterator to the end of the light edge list of the node.
     * @param node
     * @return
     */
    const_edge_iterator end_light(const NODE_ID node) const noexcept
    {
        return const_edge_iterator(g, g.get_light_edge_list_end(node), g.get_light_edge_list_end(node));
    }

    /**
     * Returns an iterator to the end of the heavy edge list of the node. This is only an alias for end(node) since the
     * end of the heavy edge list and the total edge list is the same.
     * @param node
     * @return
     */
    const_edge_iterator end_heavy(const NODE_ID node) const noexcept
    {
        return end(node);
    }

    /**
     * Returns an iterator to the edge [src,target] or the iterator to end(src) if
     * the edge does not exist. You need to check this!
     * @param src
     * @param target
     * @return
     */
    const_edge_iterator get_edge_iterator(const NODE_ID src, const NODE_ID target) const noexcept
    {
        const auto end_edge = end(src);
        for(auto it = begin(src); it < end_edge; ++it)
        {
            if(it->get_target() == target)
                return it;
        }

        return end_edge;
    }

    const GraphType& get_original_graph() const noexcept
    {
        return g;
    }

    w_type get_delta() const noexcept { return g.get_delta(); }

    double get_avg_degree() const noexcept { return g.get_avg_degree(); }

    NODE_ID get_num_neighbors(const NODE_ID node) const noexcept { return g.get_num_neighbors(node); }

    unsigned int compute_bucket_size() const noexcept { return g.compute_bucket_size(); }

    void print_graph() const noexcept
    {
        for(NODE_ID i = 0; i < get_num_nodes(); i++)
        {
            std::cout << "node " << i << std::endl;
            for(auto it = begin(i); it < end(i); ++it)
            {
                std::cout << *it << std::endl;
            }
        }
    }
};

#endif  // _KSP_GRAPH_H
