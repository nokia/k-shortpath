#ifndef _SSSP_TREE_H
#define _SSSP_TREE_H

#include <KSPGraph.h>
#include <algorithm>
#include <cassert>

#ifdef DO_YELLOW_GRAPH_STATS
#include <exception>

class NoPathException : public std::exception
{
    const char* what() const throw() override
    {
        return "Source and target are not connected";
    }
};

#endif

class SsspTree
{
public:
    enum class path_direction { s2t, t2s };   // todo is this really needed?

private:
    struct tree_node;   // is defined at the end

    const unsigned int num_nodes;
    std::vector<tree_node> the_tree;
    std::vector<NODE_ID>::iterator parent_start, parent_end;
    path_direction path_type;
    std::vector<NODE_ID> children;
    std::vector<NODE_ID> children_positions;

    NODE_ID destination = NULL_NODE;    // this should only be set if the SSSP tree is only used for SPSP computation.

public:
    /**
     * @param num_nodes The number of nodes in the tree
     */
    explicit SsspTree(const unsigned int num_nodes, const path_direction pt = path_direction::s2t) noexcept
        : num_nodes(num_nodes), the_tree(num_nodes), path_type(pt)
    {}

    /**
     * Set a destination if this SSSP tree is used for SPSP computation.
     * @param destination
     */
    void set_destination(const NODE_ID destination) noexcept
    {
        this->destination = destination;
    }

    tree_node& operator[](const unsigned int i) noexcept
    {
        assert(i < the_tree.size());
        return the_tree[i];
    }

    const tree_node& at(const unsigned int i) const noexcept
    {
        assert(i < the_tree.size());
        return the_tree[i];
    }

    SsspTree& operator=(const SsspTree& to_copy) noexcept
    {
        the_tree = to_copy.the_tree;
        return *this;
    }

    void reset() noexcept
    {
        destination = NULL_NODE;

        for(unsigned int i = 0; i < num_nodes; i++)
        {
            the_tree[i].reset();
        }
    }

    void print_path(const NODE_ID src, const NODE_ID dest) const noexcept
    {
        std::vector<NODE_ID> path;
        path.push_back(dest);

        NODE_ID p1 = dest;

        while(p1 != src)
        {
            const NODE_ID p2 = the_tree[p1].parent;
            if(p2 == NULL_NODE)
            {
                std::cout << "no shortest path in this component!";
                return;
            }

            path.push_back(p2);
            p1 = p2;
        }

        std::cout << "distance = " << the_tree[dest].tent << std::endl;
        std::cout << "shortest path: ";
        for(size_t i = path.size(); i > 0; i--)
        {
            std::cout << path[i-1] << " ";
        }

        std::cout << std::endl;
    }

    void print_tree() const
    {
        for(unsigned int i = 0; i < the_tree.size(); i++)
        {
            std::cout << "node " << i << ", distance " <<  the_tree[i].tent << ", branching node " << the_tree[i].branch << ", parent " << the_tree[i].parent << std::endl;
        }
    }

    std::vector<NODE_ID> get_shortest_path(const NODE_ID dest, const bool get_reverse_path = false) const
    {
        assert(destination == NULL_NODE || destination == dest);    // avoid to ask for shortest paths on incomplete trees

        if(get_distance(dest) == INFINITE_DISTANCE)
        {
#ifdef DO_YELLOW_GRAPH_STATS
            throw NoPathException();        // this is not thread safe!
#else
            std::cerr << "ERROR: no parent for node " << dest << std::endl;
            return std::vector<NODE_ID>();
#endif
        }

        std::vector<NODE_ID> path;
        path.push_back(dest);
        NODE_ID node = dest;

        while(the_tree[node].parent != node)
        {
            node = the_tree[node].parent;
            path.push_back(node);
        }

        if(!get_reverse_path)
            std::reverse(path.begin(), path.end());

        return path;
    }

    /**
     * Returns the distance from the source node to the specified target.
     * @param target
     * @return The distance from the source node to the specified target.
     */
    w_type get_distance(const NODE_ID target) const noexcept
    {
        assert(destination == NULL_NODE || destination == target);    // avoid to ask for shortest paths on incomplete trees

        return the_tree[target].tent;
    }

    void define_parent_path(const std::vector<NODE_ID>::iterator start, const std::vector<NODE_ID>::iterator end, const path_direction pt) noexcept
    {
        parent_start = start;
        parent_end = end;
        path_type = pt;
    }

    void update_branch() noexcept
    {
        amend_shortest_path();
        update_nodes_on_parent();

        const auto tree_size = static_cast<unsigned int>(the_tree.size());
        for(NODE_ID i = 0; i < tree_size; i++)
        {
            if(the_tree[i].branch != NULL_NODE || the_tree[i].parent == NULL_NODE)
                continue;

            if(i != the_tree[i].parent && the_tree[the_tree[i].parent].branch == NULL_NODE)
                update_parents_branching(i);

            // parent has branching node
            const NODE_ID parent = the_tree[i].parent;
            NODE_ID pos = the_tree[parent].branch;

            pos += 1 - 2 * static_cast<unsigned int>(path_type != path_direction::t2s);

            // check if this child is on the parent path
            // to make sure that the node follows parent path check that the branching node
            // of parent of parent is not equal to branching node of parent
            if(pos > 0 && pos < static_cast<NODE_ID>(std::distance(parent_start, parent_end))
               && *(parent_start + pos) == i &&
               (the_tree[parent].parent == parent ||
                the_tree[the_tree[parent].parent].branch != the_tree[parent].branch))
            {
                the_tree[i].branch = pos;
            }
            else
            {
                // if this child is not on parent path
                // then the branching node is the same as parent branching node
                the_tree[i].branch = the_tree[parent].branch;
            }
        }
    }

    void update_parents_branching(NODE_ID node) noexcept
    {
        std::vector<NODE_ID> nodes;
        nodes.push_back(node);

        // work the way up the tree until an updated branching node is reached
        while(node != the_tree[node].parent && the_tree[node].branch == NULL_NODE)
        {
            node = the_tree[node].parent;
            nodes.push_back(node);
        }

        const NODE_ID top = nodes.back();
        NODE_ID pos = the_tree[top].branch;
        bool on_path;

        if(pos == NULL_NODE)
        {
            pos = static_cast<unsigned int>(path_type == path_direction::t2s) * (static_cast<NODE_ID>(std::distance(parent_start, parent_end)));
            pos -= static_cast<unsigned int>(pos > 0);

            the_tree[top].branch = pos;
            on_path = false;
        }
        else
        {
            // if branching node of top node is not equal to
            // the branching node of parent
            // then top node is on parent path
            on_path = the_tree[top].parent == top || the_tree[top].branch != the_tree[the_tree[top].parent].branch;
        }

        for(size_t i = nodes.size() - 2; i > 0; i--)
        {
            if(on_path && *(parent_start + pos) == nodes[i])
            {
                pos += 1 - 2 * static_cast<unsigned int>(path_type == path_direction::t2s);
                the_tree[nodes[i]].branch = pos;
            }
            else
            {
                on_path = false;
                the_tree[nodes[i]].branch = pos;
            }
        }
    }

    void compute_child_array() noexcept
    {
        std::vector<std::pair<NODE_ID,NODE_ID>> children_temp;
        children_temp.reserve(num_nodes);
        children_positions.resize(num_nodes + 1, 0);    // one for each node + a sentinel

        for(NODE_ID u = 0; u < num_nodes; u++)
        {
            children_temp.emplace_back(the_tree[u].parent, u);
            if(the_tree[u].parent != NULL_NODE)
                children_positions[the_tree[u].parent + 1]++;
        }

        std::sort(children_temp.begin(), children_temp.end());
        children.reserve(num_nodes);
        for(const auto& p : children_temp)
            children.push_back(p.second);

        for(NODE_ID u = 1; u < num_nodes; u++)
        {
            children_positions[u + 1] += children_positions[u];
        }
    }

    std::vector<NODE_ID>::const_iterator get_children_begin(const NODE_ID u) const noexcept
    {
        return children.cbegin() + children_positions[u];
    }

    std::vector<NODE_ID>::const_iterator get_children_end(const NODE_ID u) const noexcept
    {
        return children.cbegin() + children_positions[u + 1];
    }

private:
    struct tree_node
    {
        w_type tent;        // distance from source to this node
        NODE_ID parent;     // parent node ID
        NODE_ID branch;     // branching node count in the parent path

        tree_node() noexcept
            : tent(INFINITE_DISTANCE),
              parent(NULL_NODE),
              branch(NULL_NODE)
        {}

        void reset() noexcept
        {
            tent = INFINITE_DISTANCE;
            parent = NULL_NODE;
            branch = NULL_NODE;
        }

        friend std::ostream& operator<<(std::ostream& o, const tree_node& t)
        {
            o << t.parent;
            return o;
        }
    };

    void update_nodes_on_parent()
    {
        std::vector<NODE_ID> path;
        NODE_ID curr, s;

        if(path_type == path_direction::t2s)
        {
            curr = *(parent_start);
            s = *(prev(parent_end));
        }
        else
        {
            curr = *(prev(parent_end));
            s = *parent_start;
        }

        if(curr == s)
        {
            the_tree[curr].branch = 0;
            return;
        }

        path.push_back(curr);

        while(curr != s)
        {
            if(curr == NULL_NODE)
                return;

            const NODE_ID temp = the_tree[curr].parent;
            path.push_back(temp);
            curr = temp;
        }

        if(path_type == path_direction::s2t)
            std::reverse(path.begin(), path.end());

        std::vector<NODE_ID>::iterator it;
        NODE_ID b;
        const std::vector<NODE_ID>::iterator stop = path_type == path_direction::t2s
                                                    ? parent_start : std::prev(parent_end);

        if(path_type == path_direction::t2s)
        {
            b = static_cast<NODE_ID>(std::distance(parent_start, parent_end) - 1);
            it = std::prev(parent_end);
        }
        else
        {
            b = 0;
            it = parent_start;
        }

        while(true)
        {
            the_tree[*it].branch = b;
            if(it == stop)
                break;

            if(path_type == path_direction::t2s)
            {
                b--;
                --it;
            }
            else
            {
                b++;
                ++it;
            }

            if(path[b] != *it)
                break;
        }
    }

    void amend_shortest_path()
    {
        NODE_ID node = path_type == path_direction::s2t ? *prev(parent_end) : *parent_start;

        if(parent_start == parent_end)
            return;

        if(path_type == path_direction::t2s)
        {
            for(auto it = parent_start + 1; it != parent_end; ++it)
            {
                if(the_tree[node].parent != *it)
                {
                    the_tree[node].parent = *it;
                }

                node = the_tree[node].parent;
            }
        }
        else
        {
            for(auto it = parent_end - 1; it >= parent_start; --it)
            {
                if(the_tree[node].parent != *it)
                {
                    the_tree[node].parent = *it;
                }

                node = the_tree[node].parent;
            }
        }
    }
};

#endif  // _SSSP_TREE_H
