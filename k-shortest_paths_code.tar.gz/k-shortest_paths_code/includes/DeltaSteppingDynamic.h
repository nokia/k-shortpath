#ifndef _DELTA_STEPPING_DYNAMIC_H
#define _DELTA_STEPPING_DYNAMIC_H

#include <DeltaStepping.h>
#include <BucketListDynamic.h>
#include <RequestListDynamic.h>
#include <NodeList.h>

template<typename GraphType, template<typename> class KSPGraphType = KSPGraph>
class DeltaSteppingDynamic final : public DeltaStepping<PartitionDynamic, BucketListDynamic, RequestListDynamic, GraphType, KSPGraphType>
{
private:
    using parent_type = DeltaStepping<PartitionDynamic, BucketListDynamic, RequestListDynamic, GraphType, KSPGraphType>;
    using parent_type::g;
    using parent_type::bucket_list;
    using parent_type::request_list;
    using parent_type::node_list;
    using parent_type::node_is_removed;
    using parent_type::relax;
    using parent_type::partition;
    using parent_type::sssp_tree;
#ifdef PROF
    using parent_type::touched;
#endif

public:
    DeltaSteppingDynamic(const KSPGraphType<GraphType>& g, const unsigned int num_threads) noexcept
        : parent_type(g, PartitionDynamic(num_threads))
    {}

    /**
     * todo update comment
     * @param t
     * @param source
     * @param dest
     * @param pt
     * @param start
     * @param end
     */
    template <bool stop_early = false>
    void compute(
#ifdef PROF
            ProfilerStatistics& t,
#endif
            const NODE_ID source, const NODE_ID dest, SsspTree::path_direction pt,
            std::vector<NODE_ID>::iterator start, std::vector<NODE_ID>::iterator end) noexcept
    {
        sssp_tree.define_parent_path(start, end, pt);

        {
#ifdef PROF
            scoped_timer scopedTimer(t.time_sssp_compute);
            compute<stop_early>(t, source, dest);
#else
            compute<stop_early>(source, dest);
#endif
        }

        {
#ifdef PROF
            t.num_branch_updates++;
            scoped_timer scopedTimer(t.time_branch_updates);
#endif
            sssp_tree.update_branch();
        }
    }

#ifdef PROF
    template<bool stop_early = false>
    void compute(ProfilerStatistics& t, const NODE_ID source, const NODE_ID destination = NULL_NODE) noexcept
    {
        touched = 1;
        compute<stop_early>(source, destination);
        t.nodes_touched_in_ds += touched;
    }
#endif

    template <bool stop_early = false>
    void compute(const NODE_ID source, const NODE_ID destination = NULL_NODE) noexcept
    {
        assert(!stop_early || destination != NULL_NODE);

        reset();

        if(stop_early)
            sssp_tree.set_destination(destination);

        // add source node to bucket[0]
        bucket_list.insert_to_bucket_list(0, source);
        sssp_tree[source].tent = 0;
        sssp_tree[source].parent = source;

        unsigned int smallest_bucket = bucket_list.find_smallest_bucket();
        const int threads = partition.get_num_threads();   // used in omp macro

        while(smallest_bucket != BucketListDynamic<PartitionDynamic>::NULL_BUCKET)
        {
            bool destination_in_bucket = false;
            node_list.clear_buffer();
            while(!bucket_list.is_empty(smallest_bucket))
            {
                request_list.reset_buffer();
                const auto smallest_bucket_size = bucket_list.length(smallest_bucket);
#pragma omp parallel for num_threads(threads) reduction(||:destination_in_bucket)   // find_path()
                for(unsigned int i = 0; i < smallest_bucket_size; i++)
                {
                    const NODE_ID node = bucket_list.remove_node_at(smallest_bucket, i);

                    if(node != NULL_NODE)
                    {
                        if(stop_early)
                            destination_in_bucket = destination_in_bucket || node == destination;

                        if(!node_is_removed[node])
                        {
                            node_is_removed[node] = true;
                            node_list.add_node(node);
                        }

                        parent_type::assign_requests_light(node);
                    }
                }

                bucket_list.reset_bucket(smallest_bucket);
                relax_requests();
            }

            request_list.reset_buffer();
#pragma omp parallel num_threads(threads)   // find_path()
            {
                parent_type::assign_request_list();     // here heavy requests get inserted using the node list
            }

            relax_requests();

            if(stop_early && destination_in_bucket)
                break;

            smallest_bucket = bucket_list.find_smallest_bucket(smallest_bucket);
        }
    }

private:
    void reset() noexcept
    {
        parent_type::reset();
        bucket_list.reset(partition.get_num_threads());
        request_list.reset(partition.get_num_threads());
    }

    void relax_requests() noexcept
    {
        const unsigned int num_requests = request_list.length();
        const unsigned int num_threads = request_list.get_num_threads();

#pragma omp parallel for num_threads(num_threads)      // relax_requests()
        for(unsigned int i = 1; i <= num_requests; i++)
        {
            unsigned int sum = 0;
            for(unsigned int t = 0; t < num_threads; t++)
            {
                const unsigned int s = request_list.get_buffer_end(t);

                if(i > sum + s)
                    sum += s;
                else
                {
                    parent_type::relax(request_list.pop_request(t, i - sum - 1));
                    break;
                }
            }
        }

        bucket_list.update_buckets();
    }
};

#endif  // _DELTA_STEPPING_DYNAMIC_H
