#ifndef _KSP_H
#define _KSP_H

#include <KSPGraph.h>
#include <Profiling.h>
#include <limits>
#include <deque>
#include <set>
#include <DeltaSteppingDynamic.h>
#include <DeltaSteppingStatic.h>

#ifndef NO_SSSP_EARLY_STOPPING
    #define SSSP_EARLY_STOPPING true
#else
    #define SSSP_EARLY_STOPPING false
#endif

#ifndef KSP_PD_L1
    #define KSP_PD_L1 false
#endif

constexpr unsigned int INVALID_PATH_PARENT = std::numeric_limits<unsigned int>::max();
constexpr unsigned int INVALID_PATH_ALPHA  = std::numeric_limits<unsigned int>::max();

struct Path
{
    //! The total weight of the path
    w_type length = INFINITE_DISTANCE;
    //! Id of the path, this path is deviated from
    unsigned int parent_index = INVALID_PATH_PARENT;
    //! branching_node_index
    unsigned int alpha = INVALID_PATH_ALPHA;
    //! The actual path as a list of nodes
    std::vector<NODE_ID> p;

    Path() = default;
    Path(const Path& p) = default;
    Path(Path&& p) = default;
    Path& operator=(Path&&) = default;

    Path(const w_type length, const unsigned int parent_index, const unsigned int alpha, std::vector<NODE_ID> p)
        : length(length),
          parent_index(parent_index),
          alpha(alpha),
          p(std::move(p))
    {}

    bool operator<(const Path& r) const
    {
        const auto p_size = p.size();
        const auto r_p_size = r.p.size();
        return std::tie(length, p_size, r.alpha) < std::tie(r.length, r_p_size, alpha);
    }

    void print_path()
    {
        std::cout << "path length: " << length << ", parent index: " << parent_index << ", alpha: " << alpha << std::endl;
        std::cout << "path:";
        for(unsigned int i : p)
            std::cout << " " << i;
        std::cout << std::endl;
    }
};

#ifndef KSP_USE_OLD_CANDIDATE_STRUCT
/**
 * Maintains a sorted set of at most k candidates.
 */
class Candidates
{
private:
    unsigned int paths_left;

    std::multiset<Path> candidates;

public:
    explicit Candidates(const unsigned int k) noexcept
        : paths_left(k)
    {}

    /**
     * Checks if the candidate list is empty.
     * @return True if empty, false otherwise.
     */
    bool empty() const noexcept
    {
        return candidates.empty();
    }

    /**
     * Returns the length of the current k-th candidate.
     * @return The length of the current k-th candidate.
     */
    w_type get_length_threshold() const noexcept
    {
        return candidates.size() < paths_left ? INFINITE_DISTANCE : candidates.crbegin()->length;
    }

    /**
     * Adds path p as a new candidate if it is at least as good as the current k path.
     * The candidate list is than shorted to only contain a many candidates as needed.
     * @param p
     */
    void insert(Path&& p) noexcept
    {
        if(candidates.size() < paths_left || p < *candidates.rbegin())
        {
            if(candidates.size() == paths_left)
                candidates.erase(--candidates.end());

            candidates.insert(std::move(p));
        }
    }

    void insert(std::vector<Path>& paths) noexcept
    {
        for(auto& p : paths)
            insert(std::move(p));
    }

    /**
     * Returns the best candidate and removes it from the list.
     * @return The best candidate from the list.
     */
    Path get_best() noexcept
    {
        assert(!candidates.empty());
        Path temp = *candidates.begin();
        candidates.erase(candidates.begin());
        paths_left--;
        return temp;
    }
};
#else
class Candidates
{
private:
    std::deque<Path> candidates;

public:
    explicit Candidates(const unsigned int /*k*/)
    {}

    /**
     * Checks if the candidate list is empty.
     * @return True if empty, false otherwise.
     */
    bool empty() const
    {
        return candidates.empty();
    }

    /**
     * Returns the length of the current k-th candidate.
     * @return The length of the current k-th candidate.
     */
    w_type get_length_threshold() const
    {
        return INFINITE_DISTANCE;
    }

    /**
     * Adds path p as a new candidate if it is at least as good as the current k path.
     * The candidate list is than shorted to only contain a many candidates as needed.
     * @param p
     */
    void insert(const Path& p)
    {
        if(p.length < get_length_threshold())
            candidates.push_back(p);
    }
    /**
     * Adds all paths as new candidates
     * @param paths
     */
    void insert(const std::vector<Path>& paths)
    {
        for(const auto& p : paths)
            candidates.push_back(p);
    }

    /**
     * Returns the best candidate and removes it from the list.
     * @return The best candidate from the list.
     */
    Path get_best()
    {
        assert(!candidates.empty());

        auto best = candidates.begin();

        for(auto it = ++candidates.begin(); it != candidates.end(); it++)
        {
            if(*it < *best)
                best = it;
        }

        Path temp = *best;
        candidates.erase(best);
        return temp;
    }
};
#endif  // KSP_USE_NEW_CANDIDATES_STRUCT

template<typename GraphType, unsigned int num_threads, bool pps = false>
class KSP
{
protected:
#ifdef PROF
    ProfilerStatistics profiler_statistics;
#endif
    KSPGraph<GraphType> orig;
    std::vector<Path> paths;
    Candidates candidates;
    const unsigned int k;
    static constexpr bool parallel_ps = num_threads > 1 && pps;

public:
    explicit KSP(const GraphType& g, const unsigned int k) noexcept
            : orig(g), paths(0), candidates(k), k(k)
    {}

    void print_paths()
    {
        std::cout << "printing paths" << std::endl;
        for(unsigned int i = 0; i < paths.size(); i++)
        {
            if(paths[i].length == INFINITE_DISTANCE)
                break;

            std::cout << "Path " << i << ":length " << paths[i].length << ":";

            for(unsigned int j = 0; j < paths[i].p.size(); j++)
                std::cout << " " << paths[i].p[j];

            std::cout << std::endl;
        }
    }

    double get_avg_path_size()
    {
        double avg_path_size = 0;

        if(paths.size() > 0)
        {
            for(unsigned int i = 0; i < paths.size(); i++)
            {
                avg_path_size += paths[i].p.size();
            }

            avg_path_size = avg_path_size / paths.size();
        }

        return avg_path_size;
    }


#ifdef PROF
    std::string return_stats()
    {
        return profiler_statistics.return_stats();
    }
#endif
};

#endif  // _KSP_H
