#ifndef _FSP_H
#define _FSP_H

#include <vector>
#include <algorithm>
#include <omp.h>
#include <KSP.h>

template <typename DS, typename GraphType>
class FSP
{
    struct H    // todo very bad name... find a better one...
    {
        NODE_ID u, v;
        w_type length;
    };

    const unsigned int num_threads;
    const KSPGraph<GraphType>& g;
    const std::vector<NODE_ID>::iterator parent_start, parent_end;
    Path p;
    const NODE_ID src, dest;

    SsspTree sssp_s;    // sssp tree viewed from source
    SsspTree sssp_t;    // sssp tree viewed form target

    std::vector<std::vector<NODE_ID>> children;     // stores children of each node as viewed form source (array of arrays)
    std::vector<omp_lock_t> ch_locks;

public:
    FSP(const KSPGraph<GraphType>& g, unsigned int t, const NODE_ID source, const NODE_ID destination,
        const std::vector<NODE_ID>::iterator start, const std::vector<NODE_ID>::iterator end) noexcept
            : num_threads(t), g(g), parent_start(start), parent_end(end),
              src(source), dest(destination),
              sssp_s(g.get_num_nodes()), sssp_t(g.get_num_nodes()),
              children(g.get_num_nodes(), std::vector<NODE_ID>(static_cast<unsigned int>(g.get_avg_degree()) / 2)),
              ch_locks(g.get_num_nodes())
    {
        const NODE_ID G_end = g.get_num_nodes();
#pragma omp parallel for num_threads(num_threads)   // constructor
        for(NODE_ID i = 0; i < G_end; i++)
        {
            omp_init_lock(&(ch_locks[i]));
        }
    }

    Path compute(DS& d
#ifdef PROF
                , ProfilerStatistics& t
#endif
    ) noexcept
    {
        {
#ifdef PROF
            t.num_sssp += 2;    // there will be two of them
            t.num_tree_copy += 2;
            t.num_FSP++;
            scoped_timer t1(t.time_sssp_total);
#endif
            d.template compute<false>(
    #ifdef PROF
                    t,
    #endif
                    src, dest, SsspTree::path_direction::s2t, parent_start, parent_end);

            {
#ifdef PROF
            scoped_timer t2(t.time_tree_copy);
#endif
                sssp_s = d.get_sssp_tree();
            }

            d.template compute<false>(
    #ifdef PROF
                    t,
    #endif
                    dest, src, SsspTree::path_direction::t2s, parent_start, parent_end);

            {
#ifdef PROF
            scoped_timer t3(t.time_tree_copy);
#endif
                sssp_t = d.get_sssp_tree();
            }
        }

        const bool make_children = add_children();

        {
#ifdef PROF
            scoped_timer t4(t.time_FSP);
#endif

            if(make_children)
            {
                H H = SEP();

                if(H.u < g.get_num_nodes())
                {
                    p.length = H.length;
                    p.alpha = sssp_s.at(H.u).branch;
                    NODE_ID temp_n = H.u;
                    p.p.push_back(temp_n);

                    while(temp_n != src)
                    {
                        temp_n = sssp_s.at(temp_n).parent;
                        p.p.push_back(temp_n);
                    }

                    std::reverse(p.p.begin(), p.p.end());

                    if(H.v < g.get_num_nodes())
                    {
                        temp_n = H.v;
                        p.p.push_back(temp_n);
                    }
                    else
                    {
                        temp_n = H.u;
                    }

                    while(temp_n != dest)
                    {
                        temp_n = sssp_t.at(temp_n).parent;
                        p.p.push_back(temp_n);
                    }
                }
            }
        }

        return p;
    }

    void print_path() const
    {
        std::cout << "path length = " << p.length << std::endl;
        for(unsigned int i = 0; i < p.p.size(); i++)
        {
            std::cout << " " << p.p[i];
        }
        std::cout << std::endl;
    }

private:

    bool add_children() noexcept
    {
        bool to_return = true;

        const auto G_end = g.get_num_nodes();

#pragma omp parallel for num_threads(num_threads)   // add_children()
        for(NODE_ID i = 0; i < G_end; i++)
        {
            if(g.get_num_neighbors(i) == 0 || i == src)
                continue;

            if(sssp_s.at(i).parent == NULL_NODE)
            {
                to_return = to_return && i != dest;     // works like if(i == dest)  to_return = false;
            }
            else
            {
                const NODE_ID parent = sssp_s.at(i).parent;
                omp_set_lock(&(ch_locks[parent]));
                children[parent].push_back(i);
                omp_unset_lock(&(ch_locks[parent]));
            }
        }

        return to_return;
    }

    void print_children(const NODE_ID src) const noexcept
    {
        std::cout << src << "no of children " << children[src].size() << ":";
        for(NODE_ID i = 0; i < children[src].size(); i++)
        {
            std::cout << " " << children[src][i];
        }
        std::cout << std::endl;
        for(NODE_ID i = 0; i < children[src].size(); i++)
        {
            print_children(children[src][i]);
        }
    }

    H SEP() const noexcept
    {
        std::vector<H> local_H(num_threads, {g.get_num_nodes(), g.get_num_nodes(), INFINITE_DISTANCE});

        const auto G_end = g.get_num_nodes();

#pragma omp parallel for num_threads(num_threads)   // SEP()
        for(NODE_ID u = 0; u < G_end; u++)
        {
            if(sssp_s.at(u).branch >= parent_end - parent_start - 1 || sssp_s.at(u).branch > sssp_t.at(u).branch)
                continue;

            const auto t_id = static_cast<unsigned int>(omp_get_thread_num());

            if(sssp_s.at(u).branch == sssp_t.at(u).branch)
            {
                for(auto it = g.begin(u), end = g.end(u); it < end; ++it)
                {
                    const NODE_ID v = it->get_target();
                    if(sssp_s.at(u).branch < sssp_t.at(v).branch && !is_child(v, u))
                    {
                        const w_type d = sssp_s.at(u).tent + it->get_weight() + sssp_t.at(v).tent;
                        if(d < local_H[t_id].length)
                        {
                            local_H[t_id].length = d;
                            local_H[t_id].u = u;
                            local_H[t_id].v = v;
                        }
                    }
                }
            }
            else
            {
                const w_type d = sssp_s.at(u).tent + sssp_t.at(u).tent;
                if(d < local_H[t_id].length)
                {
                    local_H[t_id].length = d;
                    local_H[t_id].u = u;
                    local_H[t_id].v = g.get_num_nodes();
                }
            }
        }

        return *std::min_element(local_H.begin(), local_H.end(),
                                 [](const auto& a, const auto& b){ return a.length < b.length; });
    }

    bool is_child(const NODE_ID node, const NODE_ID parent) const noexcept
    {
        return std::find(children[parent].begin(), children[parent].end(), node) != children[parent].end();
    }

};

#endif  // _FSP_H
