//
// Created by Alex Schickedanz <alex@ae.cs.uni-frankfurt.de> on 06.09.17.
//

#include "RequestListDynamic.h"

constexpr unsigned int RequestListDynamic::NOT_ASSIGNED;
