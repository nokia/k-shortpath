#ifndef _REQUEST_LIST_DYNAMIC_H
#define _REQUEST_LIST_DYNAMIC_H

#include <Request.h>
#include <Partition.h>
#include <omp.h>

class RequestListDynamic
{
public:
    RequestListDynamic(const PartitionDynamic& p, const unsigned int num_entries) noexcept
        : num_threads(p.get_num_threads()),
          buffer(num_threads, std::vector<UpdateRequest>(8 * static_cast<unsigned int>(sqrt(num_entries) + 1) / num_threads, UpdateRequest())),
          buffer_t(num_entries, 0),
          buffer_pos(num_entries, NOT_ASSIGNED),
          buffer_end(num_threads, 0),
          buffer_locks(num_entries)
    {
#pragma omp parallel for num_threads(num_threads)   // constructor
        for(unsigned int i = 0; i < num_entries; i++)
        {
            omp_init_lock(&(buffer_locks[i]));
        }
    }

    // todo changing the number of threads is not correctly supported (only if the number decreases) can this be cut out?
    void reset(const unsigned int threads) noexcept
    {
        num_threads = threads;  // todo if num_threads changes, buffer and buffer_end needs to be resized. Or make num_threads constant

        reset_buffer();
        std::fill(buffer_t.begin(), buffer_t.end(), 0);
        std::fill(buffer_pos.begin(), buffer_pos.end(), NOT_ASSIGNED);
    }

    unsigned int get_num_threads() const noexcept
    {
        return num_threads;
    }

    unsigned int get_buffer_end(const unsigned int t) const noexcept
    {
        return buffer_end[t];
    }

    const UpdateRequest& pop_request(const unsigned int t, const unsigned int pos) noexcept
    {
        const NODE_ID n = buffer[t][pos].node;
        buffer_t[n] = 0;
        buffer_pos[n] = NOT_ASSIGNED;
        return buffer[t][pos];
    }

    void insert(const UpdateRequest& curr) noexcept
    {
        omp_set_lock(&(buffer_locks[curr.node]));

        if(buffer_pos[curr.node] == NOT_ASSIGNED)
        {
            const auto t = static_cast<unsigned int>(omp_get_thread_num());
            increase_buffer_size(t, curr.node);
            buffer_pos[curr.node] = buffer_end[t]++;
            buffer_t[curr.node] = t;
            buffer[t][buffer_pos[curr.node]] = curr;
        }
        else if(curr.proposed_tent < buffer[buffer_t[curr.node]][buffer_pos[curr.node]].proposed_tent)
        {
            buffer[buffer_t[curr.node]][buffer_pos[curr.node]] = curr;
        }

        omp_unset_lock(&(buffer_locks[curr.node]));
    }

    void reset_buffer() noexcept
    {
        std::fill(buffer_end.begin(), buffer_end.end(), 0);
    }

    unsigned int length() const noexcept
    {
        unsigned int total_requests = 0;
        for(auto num_requests : buffer_end)
            total_requests += num_requests;

        return total_requests;
    }

private:
    void increase_buffer_size(const unsigned int t, const unsigned int new_node) noexcept
    {
        if(buffer_end[t] != buffer[t].size())
            return;

        // for copying need to lock all locks to avoid racing
        const size_t size = buffer[t].size();
        for(unsigned int j = 0; j < size; j++)
        {
            const NODE_ID node = buffer[t][j].node;
            if(node != new_node)
                omp_set_lock(&(buffer_locks[node]));
        }

        buffer[t].resize(buffer[t].size() << 1);

        // now release all locks
        for(unsigned int j = 0; j < size; j++)
        {
            const NODE_ID node = buffer[t][j].node;
            if(node != new_node)
                omp_unset_lock(&(buffer_locks[node]));
        }
    }

    unsigned int num_threads;

    static constexpr unsigned int NOT_ASSIGNED = std::numeric_limits<unsigned int>::max();

    std::vector<std::vector<UpdateRequest>> buffer;     // [numThreads][sqrt(n)] set of requests
    std::vector<unsigned int> buffer_t;                 // mapping of node to thread ID buffer (1st thread who inserted this node into the bucket)
    std::vector<unsigned int> buffer_pos;               // mapping form node ID to buffer position
    std::vector<unsigned int> buffer_end;               // pointing to the last location of any given buffer
    std::vector<omp_lock_t> buffer_locks;               // lock for the buffer position for all nodes in a graph to prevent races
};

#endif  // _REQUEST_LIST_DYNAMIC_H
