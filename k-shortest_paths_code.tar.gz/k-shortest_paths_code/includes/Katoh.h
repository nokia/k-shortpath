#ifndef _KATOH_H
#define _KATOH_H

#include <KSP.h>
#include <FSP.h>
#include <omp.h>

template<template<typename, template<typename> class> class DeltaSteppingType, typename GraphType, unsigned int num_threads, bool pps = false>
class Katoh : public KSP<GraphType, num_threads, pps>
{
    using ParentType = KSP<GraphType, num_threads, pps>;
    using DS = DeltaSteppingType<GraphType, KSPGraph>;
    using ParentType::parallel_ps;
    using ParentType::orig;
    using ParentType::paths;
    using ParentType::candidates;
    using ParentType::k;
#ifdef PROF
    using ParentType::profiler_statistics;
#endif

public:
    explicit Katoh(const GraphType& g, const unsigned int k)
        : ParentType(g, k), w(0)
    {
        if(GraphType::is_directed)
            throw std::invalid_argument("Katoh's algorithm only works for undirected graphs.");

        if(num_threads > 2 && parallel_ps)
        {
            g_b = std::make_unique<KSPGraph<GraphType>>(g);
            g_c = std::make_unique<KSPGraph<GraphType>>(g);
        }
    }

    /**
     * Computes the k shortest paths from source to destination
     * @param source
     * @param destination
     * @param k_rounds Have to be at least 2
     * @return k shortest paths
     */
    std::vector<Path> compute(const NODE_ID source, const NODE_ID destination)
    {
        assert(k > 1);

        if(source == destination)
        {
            return {Path(0, 0, 0, {source})};
        }

        paths.reserve(k);
        w.resize(k);
        b_set.reserve(k);

        if(num_threads > 2 && parallel_ps)
            return compute_parallel(source, destination);

        return compute_sequential(source, destination);
    }

private:
    /**
     * Computes the k shortest paths from source to destination
     * @param source
     * @param destination
     * @param K_rounds Have to be at least 2
     * @return k shortest paths
     */
    std::vector<Path> compute_sequential(const NODE_ID source, const NODE_ID destination)
    {
#ifdef PROF
        profiler_statistics.num_sssp++;
        double start_sssp_total_timer = omp_get_wtime();
        double construct_time = start_sssp_total_timer;
#endif

        DS d(orig, num_threads);

#ifdef PROF
        double c_start = omp_get_wtime();
        profiler_statistics.time_sssp_constructor += c_start - construct_time;
        d.template compute<SSSP_EARLY_STOPPING>(profiler_statistics, source, destination);
        profiler_statistics.time_sssp_compute += omp_get_wtime() - c_start;
#else
        d.template compute<SSSP_EARLY_STOPPING>(source, destination);
#endif

        paths.push_back({d.get_distance(destination), 0, 0, d.get_shortest_path_to(destination)});

#ifdef PROF
        profiler_statistics.time_sssp_total += omp_get_wtime() - start_sssp_total_timer;
#endif

        w[0].push_back(0);
        w[0].push_back(static_cast<unsigned int>(paths[0].p.size() - 1));
        b_set.emplace_back(0, static_cast<unsigned int>(paths[0].p.size()));
        FSP<DS, GraphType> fsp(orig, num_threads, source, destination, paths[0].p.begin(), paths[0].p.end());

        Path p1 = fsp.compute(d
#ifdef PROF
                , profiler_statistics
#endif
        );

        p1.parent_index = 0;
        candidates.insert(std::move(p1));

        for(unsigned int kp = 1; kp < k && !candidates.empty(); kp++)
        {
            paths.push_back(candidates.get_best());

            if(kp == k - 1)
                break;

            w[kp].push_back(paths[kp].alpha + 1);
            w[kp].push_back(static_cast<unsigned int>(paths[kp].p.size() - 1));
            b_set.emplace_back(paths[kp].alpha + 1, static_cast<unsigned int>(paths[kp].p.size()));
            const NODE_ID n1 = paths[kp].p[paths[kp].alpha];
            const NODE_ID n2 = paths[kp].p[paths[kp].alpha + 1];
            const auto edge_iter = orig.get_edge_iterator(n1, n2);
            if(edge_iter != orig.end(n1))
                b_set[paths[kp].parent_index][paths[kp].alpha].push_back(edge_iter);

            unsigned int delta = 0;
            bool found_max = false;
            const bool in_w = is_in_w(paths[kp].parent_index, paths[kp].alpha);

            if(!in_w)
            {
                w[paths[kp].parent_index].push_back(paths[kp].alpha);
                delta = find_max_in_w(found_max, paths[kp].parent_index, paths[paths[kp].parent_index].alpha + 1,
                                      paths[kp].alpha);
            }

            Path pka, pkb, pkc;

            //Pc
            if(found_max || !in_w)
                pkc = obtain_Pc(d, delta, kp, num_threads);

            //Pb
            const unsigned int gama = find_min_in_w(paths[kp].parent_index, paths[kp].alpha + 1,
                                              static_cast<unsigned int>(paths[paths[kp].parent_index].p.size()));

            pkb = obtain_Pb(d, delta, found_max || !in_w, kp, num_threads, gama);

            //Pa
            if(paths[kp].alpha + 1 != paths[kp].p.size() - 1)
            {
                pka = obtain_Pa(d, delta, found_max || !in_w, kp, num_threads);
            }

            {
#ifdef PROF
                profiler_statistics.num_graph_restore++;
                scoped_timer t1(profiler_statistics.time_graph_restore);
#endif

                orig.restore_graph();
            }

            if(pkc.length < candidates.get_length_threshold())
            {
                if(delta > 0)
                {
                    pkc.length = orig.get_original_graph().get_path_length(pkc.p);
                }

                candidates.insert(std::move(pkc));
            }

            if(pkb.length < candidates.get_length_threshold())
            {
                if(paths[kp].alpha > 0)
                {
                    pkb.length = orig.get_original_graph().get_path_length(pkb.p);
                }

                candidates.insert(std::move(pkb));
            }

            if(pka.length < candidates.get_length_threshold())
            {
                pka.length = orig.get_original_graph().get_path_length(pka.p);
                candidates.insert(std::move(pka));
            }
        }

#ifdef PROF
        profiler_statistics.avg_path_size = this->get_avg_path_size();
#endif
        return paths;
    }

    /**
     * Computes the k shortest paths from source to destination
     * @param source
     * @param destination
     * @param K_rounds Have to be at least 2
     * @return k shortest paths
     */
    std::vector<Path> compute_parallel(const NODE_ID source, const NODE_ID destination)
    {
#if !KSP_PD_L1
        omp_set_nested(1);
#endif

#ifdef PROF
        const double sssp_construction_time_start = omp_get_wtime();
#endif

#if !KSP_PD_L1
        DS d_b(*g_b, num_threads);
        DS d_c(*g_c, num_threads);
#else
	DS d_b(*g_b, 1);
        DS d_c(*g_c, 1);
#endif

#ifdef PROF
        profiler_statistics.time_sssp_constructor += omp_get_wtime() - sssp_construction_time_start;
        const double start = omp_get_wtime();
#endif

        DS d(orig, num_threads);

#ifdef PROF
        profiler_statistics.time_sssp_constructor += omp_get_wtime() - start;
#endif
        {
#ifdef PROF
            profiler_statistics.num_sssp++;
            scoped_timer t1(profiler_statistics.time_sssp_compute);
            d.template compute<SSSP_EARLY_STOPPING>(profiler_statistics, source, destination);
#else
            d.template compute<SSSP_EARLY_STOPPING>(source, destination);
#endif
        }

        paths.push_back({d.get_distance(destination), 0, 0, d.get_shortest_path_to(destination)});

#ifdef PROF
        profiler_statistics.time_sssp_total += omp_get_wtime() - start;
#endif

        w[0].push_back(0);
        w[0].push_back(static_cast<unsigned int>(paths[0].p.size() - 1));
        b_set.emplace_back(0, static_cast<unsigned int>(paths[0].p.size()));
        FSP<DS, GraphType> fsp(orig, num_threads, source, destination, paths[0].p.begin(), paths[0].p.end());

        Path p1 = fsp.compute(d
#ifdef PROF
                , profiler_statistics
#endif
        );

        p1.parent_index = 0;
        candidates.insert(std::move(p1));

#if KSP_PD_L1
	d.reset_num_partition_threads(1);
#endif

#ifdef PROF
        temp_a = profiler_statistics;
        temp_b = profiler_statistics;
        temp_c = profiler_statistics;
#endif

        for(unsigned int kp = 1; kp < k && !candidates.empty(); kp++)
        {
            paths.push_back(candidates.get_best());

            if(kp == k - 1)
                break;

            w[kp].push_back(paths[kp].alpha + 1);
            w[kp].push_back(static_cast<unsigned int>(paths[kp].p.size() - 1));
            b_set.emplace_back(paths[kp].alpha + 1, static_cast<unsigned int>(paths[kp].p.size()));
            const NODE_ID n1 = paths[kp].p[paths[kp].alpha];
            const NODE_ID n2 = paths[kp].p[paths[kp].alpha + 1];
            const auto edge_iter = orig.get_edge_iterator(n1, n2);

            if(edge_iter != orig.end(n1))
                b_set[paths[kp].parent_index][paths[kp].alpha].push_back(edge_iter);

            unsigned int delta = 0;
            bool found_max = false;
            const bool in_w = is_in_w(paths[kp].parent_index, paths[kp].alpha);
            const unsigned int num_subproblems = 1 + static_cast<unsigned int>(!in_w)
                                                 + static_cast<unsigned int>(paths[kp].alpha + 2 != paths[kp].p.size());

            if(!in_w)
            {
                w[paths[kp].parent_index].push_back(paths[kp].alpha);
                delta = find_max_in_w(found_max, paths[kp].parent_index, paths[paths[kp].parent_index].alpha + 1,
                                      paths[kp].alpha);
            }

            Path pka, pkb, pkc;

#if !KSP_PD_L1
            const unsigned int num_sssp_threads = num_threads / num_subproblems;    // works because num_threads >= 3 holds and num_subproblems is in {1,2,3}
#endif

#pragma omp parallel for num_threads(num_subproblems)     // compute_parallel()
            for(unsigned int i = 0; i < num_subproblems; i++)
            {
                if(i == 0)  // looks silly but is useful because the loop runs in parallel
                {
                    // do Pb because this is always present
                    const unsigned int gama = find_min_in_w(paths[kp].parent_index, paths[kp].alpha + 1,
                                                            static_cast<unsigned int>(paths[paths[kp].parent_index].p.size()));
#if !KSP_PD_L1
                    d_b.reset_num_partition_threads(num_sssp_threads + (num_threads % num_subproblems));
#endif
                    pkb = obtain_Pb(d_b, delta, found_max || !in_w, kp
#if KSP_PD_L1
                                    , 1
#else
                                    , num_sssp_threads + (num_threads % num_subproblems)
#endif
                                    , gama);
                }
                else if(i == 1)
                {
                    // case when only 2 or all 3 subproblems are present
                    // try if Pc is possible
                    if(found_max || !in_w)
                    {
#if !KSP_PD_L1
                        d_c.reset_num_partition_threads(num_sssp_threads);
#endif
                        pkc = obtain_Pc(d_c, delta, kp
#if KSP_PD_L1
                                        , 1
#else
                                        , num_sssp_threads
#endif
                        );
                    }
                    else if(paths[kp].alpha + 1 != paths[kp].p.size() - 1)  // or if Pa is possible
                    {
#if !KSP_PD_L1
                        d.reset_num_partition_threads(num_sssp_threads);
#endif
                        pka = obtain_Pa(d, delta, found_max || !in_w, kp
#if KSP_PD_L1
                                        , 1
#else
                                        , num_sssp_threads
#endif
                        );
                    }
                }
                else
                {
                    // case when all 3 subproblems are present
                    // Pa is left to do
                    if(paths[kp].alpha + 1 != paths[kp].p.size() - 1)
                    {
#if !KSP_PD_L1
                        d.reset_num_partition_threads(num_sssp_threads);
#endif
                        pka = obtain_Pa(d, delta, found_max || !in_w, kp
#if KSP_PD_L1
                                        , 1
#else
                                        , num_sssp_threads
#endif
                        );
                    }
                }
            }
#ifdef PROF
            // avoid copying objects
            if(temp_a.time_sssp_total > temp_b.time_sssp_total)
            {
                if(temp_a.time_sssp_total > temp_c.time_sssp_total)
                    profiler_statistics = temp_a;
                else
                    profiler_statistics = temp_c;
            }
            else
            {
                if(temp_b.time_sssp_total > temp_c.time_sssp_total)
                    profiler_statistics = temp_b;
                else
                    profiler_statistics = temp_c;
            }

            temp_a = profiler_statistics;
            temp_b = profiler_statistics;
            temp_c = profiler_statistics;

            profiler_statistics.num_graph_restore += 3;
#endif

            {
#ifdef PROF
            scoped_timer t(profiler_statistics.time_graph_restore);
#endif
                g_b->restore_graph();
                g_c->restore_graph();
                orig.restore_graph();
            }

            if(pkc.length < candidates.get_length_threshold())
            {
                if(delta > 0)
                {
                    pkc.length = orig.get_original_graph().get_path_length(pkc.p);
                }

                candidates.insert(std::move(pkc));
            }

            if(pkb.length < candidates.get_length_threshold())
            {
                if(paths[kp].alpha > 0)
                {
                    pkb.length = orig.get_original_graph().get_path_length(pkb.p);
                }

                candidates.insert(std::move(pkb));
            }

            if(pka.length < candidates.get_length_threshold())
            {
                pka.length = orig.get_original_graph().get_path_length(pka.p);
                candidates.insert(std::move(pka));
            }
        }

#ifdef PROF
        profiler_statistics.avg_path_size = this->get_avg_path_size();
#endif
        return paths;
    }

    Path obtain_Pa(DS& d, const unsigned int delta, const bool do_pc, const unsigned int k, unsigned int num_sssp_threads) noexcept
    {
        if(num_threads > 2 && parallel_ps)  // todo is this still right
        {
            if(do_pc)
                remove_nodes_pc(k, delta, orig);

            remove_nodes_pb(k, delta, orig);
        }

        remove_nodes_pa(k);
        const NODE_ID s = paths[k].p[paths[k].alpha + 1];
        const NODE_ID t = paths[k].p.back();
        FSP<DS, GraphType> fspa(orig, num_sssp_threads, s, t, paths[k].p.begin() + paths[k].alpha + 1, paths[k].p.end());

        Path pka = fspa.compute(d
#ifdef PROF
            , (num_threads > 2 && parallel_ps) ? temp_a : profiler_statistics
#endif
        );

        if(pka.length < candidates.get_length_threshold())
        {
            pka.parent_index = k;
            pka.alpha += paths[k].alpha + 1;
            pka.p.insert(pka.p.begin(), paths[k].p.begin(), paths[k].p.begin() + paths[k].alpha + 1);
        }

        return pka;
    }

    Path obtain_Pb(DS& d, const unsigned int delta, const bool do_pc, const unsigned int k, unsigned int num_sssp_threads, const unsigned int gama) noexcept
    {
        if(num_threads > 2 && parallel_ps)  // todo is this still right
        {
            if(do_pc)
                remove_nodes_pc(k, delta, *g_b);

            remove_nodes_pb(k, delta, *g_b);
        }
        else
        {
            remove_nodes_pb(k, delta, orig);
        }

        std::vector<NODE_ID> R;
        for(unsigned int i = paths[k].alpha; i <= gama; i++)
        {
            R.push_back(paths[paths[k].parent_index].p[i]);
        }

        const NODE_ID s = paths[paths[k].parent_index].p[paths[k].alpha];
        const NODE_ID t = paths[0].p.back();

        FSP<DS, GraphType> fspb((num_threads > 2 && parallel_ps) ? *g_b: orig, num_sssp_threads, s, t, R.begin(), R.end());

        Path pkb = fspb.compute(d
#ifdef PROF
                , (num_threads > 2 && parallel_ps) ? temp_b : profiler_statistics
#endif
        );

        if(pkb.length < candidates.get_length_threshold())
        {
            pkb.parent_index = paths[k].parent_index;
            pkb.alpha = pkb.alpha + paths[k].alpha;
            pkb.p.insert(pkb.p.begin(), paths[paths[k].parent_index].p.begin(),
                         paths[paths[k].parent_index].p.begin() + paths[k].alpha);
        }

        return pkb;
    }

    Path obtain_Pc(DS& d, const unsigned int delta, const unsigned int k, unsigned int num_sssp_threads) noexcept
    {
        if(num_threads > 2 && parallel_ps)  // todo is this still right
        {
            remove_nodes_pc(k, delta, *g_c);
        }
        else
        {
            remove_nodes_pc(k, delta, orig);
        }

        std::vector<NODE_ID> R;
        R.reserve(paths[k].alpha > delta ? paths[k].alpha - delta : 0);
        for(unsigned int i = delta; i <= paths[k].alpha; i++)
        {
            R.push_back(paths[paths[k].parent_index].p[i]);
        }

        const NODE_ID s = paths[paths[k].parent_index].p[delta];
        const NODE_ID t = paths[0].p.back();

        FSP<DS, GraphType> f(num_threads > 2 && parallel_ps ? *g_c : orig, num_sssp_threads, s, t, R.begin(), R.end());

        Path pkc = f.compute(d
#ifdef PROF
                , (num_threads > 2 && parallel_ps) ? temp_c : profiler_statistics
#endif
        );

        if(pkc.length < candidates.get_length_threshold())
        {
            pkc.parent_index = paths[k].parent_index;
            pkc.alpha = delta + pkc.alpha;
            pkc.p.insert(pkc.p.begin(), paths[paths[k].parent_index].p.begin(),
                         paths[paths[k].parent_index].p.begin() + delta);
        }

        return pkc;
    }

    unsigned int find_max_in_w(bool& found_max, const unsigned int j, const unsigned int min_val, const unsigned int max_val) const noexcept
    {
        unsigned int to_return = 0;
        found_max = false;

        for(const auto w_ji : w[j])
        {
            if(w_ji >= to_return && min_val <= w_ji && w_ji < max_val)
            {
                to_return = w_ji;
                found_max = true;
            }
        }

        to_return *= static_cast<unsigned int>(to_return != std::numeric_limits<unsigned int>::max());

        return to_return;
    }

    unsigned int find_min_in_w(const unsigned int j, const unsigned int min_val, const unsigned int max_val) const noexcept
    {
        unsigned int to_return = std::numeric_limits<unsigned int>::max();

        for(const auto w_ji : w[j])
        {
            if(w_ji < to_return && min_val <= w_ji && w_ji < max_val)
                to_return = w_ji;
        }

        return to_return;
    }

    /**
     * Checks if W[j] contains alpha
     * @param j
     * @param alpha
     * @return
     */
    bool is_in_w(const unsigned int j, const unsigned int alpha) const noexcept
    {
        for(const auto w_ji : w[j])
        {
            if(w_ji == alpha)
                return true;
        }

        return false;
    }

    void remove_nodes_pa(const unsigned int k) noexcept
    {
#ifdef PROF
        profiler_statistics.num_removed_edges += (orig.get_num_neighbors(paths[k].p[paths[k].alpha]) * 2);
        scoped_timer t(profiler_statistics.time_remove_edges);
#endif

        orig.remove_node(paths[k].p[paths[k].alpha]);
    }

    void remove_nodes_pb(const unsigned int k, const unsigned int delta, KSPGraph<GraphType>& g) noexcept
    {
        for(unsigned int i = delta; i < paths[k].alpha; i++)
        {
#ifdef PROF
            profiler_statistics.num_removed_edges += g.get_num_neighbors(paths[paths[k].parent_index].p[i]) * 2;
            scoped_timer t(profiler_statistics.time_remove_edges);
#endif

            g.remove_node(paths[paths[k].parent_index].p[i]);
        }

        for(auto edge_iter : b_set[paths[k].parent_index][paths[k].alpha])
        {
#ifdef PROF
            profiler_statistics.num_removed_edges += 2;
            scoped_timer t(profiler_statistics.time_remove_edges);
#endif

            g.remove_edge(edge_iter);
        }
    }

    void remove_nodes_pc(const unsigned int k, const unsigned int delta, KSPGraph<GraphType>& g) noexcept
    {
        for(unsigned int i = 0; i < delta; i++)
        {
#ifdef PROF
            profiler_statistics.num_removed_edges += g.get_num_neighbors(paths[paths[k].parent_index].p[i]) * 2;
            scoped_timer t(profiler_statistics.time_remove_edges);
#endif

            g.remove_node(paths[paths[k].parent_index].p[i]);
        }

        for(auto edge_iter : b_set[paths[k].parent_index][delta])
        {
#ifdef PROF
            profiler_statistics.num_removed_edges += 2;
            scoped_timer t(profiler_statistics.time_remove_edges);
#endif

            g.remove_edge(edge_iter);
        }
    }

    // todo name this thing other than "B"
    struct B
    {
        using Proxy = std::vector<typename KSPGraph<GraphType>::const_edge_iterator>;

        B(unsigned int alpha, unsigned int size) noexcept
            : alpha(alpha), proxies(size - alpha)
        {}

        Proxy& operator[](const unsigned int i) noexcept
        {
            assert(i < alpha + proxies.size() && i >= alpha);
            return proxies[i - alpha];
        }

    private:
        const unsigned int alpha;
        std::vector<Proxy> proxies;
    };

    std::vector<std::vector<unsigned int>> w;
    std::vector<B> b_set;

#ifdef PROF
    ProfilerStatistics temp_a;
    ProfilerStatistics temp_b;
    ProfilerStatistics temp_c;
#endif

    std::unique_ptr<KSPGraph<GraphType>> g_b, g_c;
};

#endif  // _KATOH_H
