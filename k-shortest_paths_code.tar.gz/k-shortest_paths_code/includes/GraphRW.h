//
// Created by Alex Schickedanz <alex@ae.cs.uni-frankfurt.de> on 22.05.17.
//

#ifndef _GRAPH_RW_H
#define _GRAPH_RW_H

#include "BasicGraph.h"
#include "SsspTree.h"
#include <algorithm>
#include <cassert>
#include <cstring>
#include <sstream>
#include <random>
#include <chrono>
#include <tuple>
#include <memory>

#include <parallel/algorithm>

/**
 * Reads and writes graphs from and to files.
 */
class GraphRW
{
    using node_list_type = std::vector<Node>;
    template<bool directed = false, bool weighted = true>
    using edge_list_type = std::vector<Edge<directed, weighted>>;

public:
    enum class file_type{METIS, EDGELIST};
    enum class weight_converting {ORIGINAL, EXPONENTIAL, POWER_LAW};

    /**
     * Copies G (deep copy) and adjust the weight of every edge (u,v) to l(u,v) + d(u) - d(v), where l(u,v) is the weight of the edge
     * and d(x) is the distance from x to t in T. T is a shortest path tree rooted in a target node t.
     * @param g
     * @param dest_rooted_sssp_tree The SSSP tree rooted in the destination node needs to be a full SSSP tree, so you cannot
     *                              end the computation after the source/destination is found. We need everything.
     */
    template<bool directed, bool weighted>  // todo reverse needed?
    static BasicGraph<true, true> generate_fengs_g_prime(const BasicGraph<directed, weighted>& g, const SsspTree& dest_rooted_sssp_tree,
                                                         bool prepare_for_delta_stepping = true)
    {
        const NODE_ID num_nodes = g.get_num_nodes();    // the number of nodes without the sentinel.
        node_list_type nodes;                           // will contain a sentinel
        nodes.reserve(g.nodes.size());
        for(const auto& node: g.nodes)
            nodes.push_back(node);

        edge_list_type<true, true> edges;
        edges.reserve(g.num_edges);

        w_type new_heaviest_weight = 0;

        // adjust edge weights
        for(NODE_ID node_id = 0; node_id < num_nodes; node_id++)
        {
            const auto end = nodes[node_id + 1].start_edge;       // works thanks to the sentinel
            const w_type current_node_dist = dest_rooted_sssp_tree.get_distance(node_id);
            for(auto edge_id = nodes[node_id].start_edge; edge_id < end; edge_id++)
            {
                const w_type new_weight = current_node_dist == INFINITE_DISTANCE
                                          ? INFINITE_DISTANCE
                                          : g.edges[edge_id].get_weight()
                                            + dest_rooted_sssp_tree.get_distance(g.edges[edge_id].get_target())
                                            - current_node_dist;
                assert(new_weight >= 0);

                new_heaviest_weight = std::max(new_heaviest_weight, new_weight * static_cast<unsigned int>(new_weight != INFINITE_DISTANCE));

                edges.emplace_back(g.edges[edge_id].get_target(), new_weight);
            }
        }

        if(prepare_for_delta_stepping)
        {
            GraphRW::partition_edges_by_weight(nodes, edges, g.delta);      // todo better delta?
        }

        assert(g.nodes.size() == nodes.size());
        assert(nodes.size() == g.get_num_nodes() + 1);

        return BasicGraph<true, true>(nodes, edges, new_heaviest_weight, g.delta);
    }

    template<bool directed = false, bool weighted = true, bool add_reverse_graph = false, unsigned int power_law_exponent = 0>
    static BasicGraph<directed, weighted> read_graph(char* path, char* delta_option, file_type ft = file_type::METIS, weight_converting w_type = weight_converting::ORIGINAL)
    {
        static_assert(weighted || power_law_exponent == 0, "Unweighted graphs cannot have power law weights");
        std::ifstream graph_file(path);

        // is the path valid and can the file be opened?
        if(!graph_file.is_open())
            throw std::invalid_argument("Could not open the file.");

        switch(ft)
        {
            case file_type::METIS:
                return load_metis_file<directed, weighted, add_reverse_graph, power_law_exponent>(graph_file, w_type, delta_option);
            default: // file_type::EDGELIST:
                return load_edge_list_file<directed, weighted, add_reverse_graph, power_law_exponent>(graph_file, w_type, delta_option);
        }
    }

    /**
     * Generates a G(n,m) graph and stores it as Metis file with uniform random edge weights.
     * @param n
     * @param m
     * @param path_to_file
     */
    template<bool directed = true>
    static void generate_G_n_m(const NODE_ID n, const EDGE_ID m, const std::string& path_to_file, long seed = 0)
    {
        const EDGE_ID num_edges = directed ? m : 2 * m;

        std::vector<std::tuple<NODE_ID, NODE_ID, float>> edges;
        edges.reserve(num_edges);

        if(seed == 0)
            seed = std::chrono::high_resolution_clock::now().time_since_epoch().count();

        std::default_random_engine generator(seed);
        std::uniform_int_distribution<NODE_ID> node_distribution(1, n);
        std::uniform_real_distribution<float> weight_distribution(0.0, 1.0);

        while(edges.size() < num_edges)
        {
            const auto edges_left = (num_edges - edges.size()) / (static_cast<unsigned int>(!directed) + 1);
            for(size_t i = 0; i < edges_left; i++)
            {
                NODE_ID u = node_distribution(generator),
                        v = node_distribution(generator);

                // prevent loops
                while(u == v)
                    v = node_distribution(generator);

                float weight = weight_distribution(generator);
                edges.emplace_back(u, v, weight);
                if(!directed)
                    edges.emplace_back(v, u, weight);
            }

            // remove multi edges
            __gnu_parallel::sort(edges.begin(), edges.end());
            auto last = std::unique(edges.begin(), edges.end(), [](const auto& l, const auto& r) -> bool {
                return std::get<0>(l) == std::get<0>(r) && std::get<1>(l) == std::get<1>(r);
            });
            edges.erase(last, edges.end());
        }

        // write to file
        std::ofstream metis_file;
        metis_file.open(path_to_file);
        metis_file << "% Seed: " << seed << std::endl;
        metis_file << n << " " << m << " 1" << std::endl; // the 1 is the flag for weighted graphs

        NODE_ID last_node = std::get<0>(edges[0]);
        for(const auto& edge : edges)
        {
            if(last_node != std::get<0>(edge))
            {
                for(unsigned int i = 0; i < std::get<0>(edge) - last_node; i++)
                    metis_file << std::endl;

                last_node = std::get<0>(edge);
            }

            metis_file << std::get<1>(edge) << " " << std::get<2>(edge) << " ";
        }

        // This new lines are needed if the last nodes have no outgoing edges.
        for(unsigned int i = 0; i < std::get<0>(edges.back()) - n; i++)
            metis_file << std::endl;

        metis_file << std::endl;

        metis_file.close();
    }

private:
    /**
     * Reads an edge list file. The file has to have the following format:
     * First line contains the number of nodes.
     * Every other line contains one edge as start node id, target node id, weight (space separated)
     * The nodes have to have the ids from 0 to num_nodes - 1.
     * Empty lines and lines starting with "#" are ignored.
     * @param graph_file Path to a edge list file
     * @param w_conv Keep the original weights or convert them to floats in [0,1]
     */
    template<bool directed = false, bool weighted = true, bool add_reverse_graph = false, unsigned int power_law_exponent = 3>
    static BasicGraph<directed, weighted> load_edge_list_file(std::ifstream &graph_file, const weight_converting w_conv, char* delta_option)
    {
        NODE_ID num_nodes;
        w_type heaviest_weight = weighted ? 0.0 : 1.0;

        std::string line;
        std::getline(graph_file, line);
        std::stringstream s(line);
        s >> num_nodes;

        std::vector<edge_list_type<directed, weighted>> edges_per_node;
        edges_per_node.resize(num_nodes);

        while(std::getline(graph_file, line))
        {
            // Skip comment lines
            if(line.empty() || line.at(0) == '#')
                continue;

            NODE_ID src, dest;
            w_type weight;
            std::stringstream ss(line);
            ss >> src >> dest >> weight;

            if(weighted)
            {
                if(w_conv == weight_converting::POWER_LAW)
                    weight = uniform_to_power_law_weights<power_law_exponent>(weight);
                else if(w_conv == weight_converting::EXPONENTIAL)
                    weight = uniform_to_exponential_weights(weight);

                if(weight > heaviest_weight)
                    heaviest_weight = weight;
            }

            edges_per_node[src].emplace_back(dest, weight);

            // todo this only works for one version of edge ist files. This should be changed to universal edge list file reader.
            if(!directed)
                edges_per_node[dest].emplace_back(src, weight);
        }

        node_list_type nodes(num_nodes + 1);    // adding a sentinel at the end
        edge_list_type<directed, weighted> edges;

        for(NODE_ID i = 0; i < num_nodes; i++)
        {
            nodes[i].start_edge = edges.size();
            edges.insert(edges.end(), edges_per_node[i].begin(), edges_per_node[i].end());
        }

        // set the sentinel
        nodes[num_nodes].start_edge = edges.size();

        w_type delta = GraphRW::get_delta(delta_option, heaviest_weight);
        GraphRW::partition_edges_by_weight(nodes, edges, delta);

        if(!directed)
            GraphRW::link_backward_edges(nodes, edges);

        if(directed && add_reverse_graph)
        {
            auto g_reverse = GraphRW::get_reverse_graph<directed, weighted>(nodes, edges, heaviest_weight, delta);
            return BasicGraph<directed, weighted>(nodes, edges, heaviest_weight, delta, std::move(g_reverse));
        }

        return BasicGraph<directed, weighted>(nodes, edges, heaviest_weight, delta);
    }

    /**
     * Loads a standard METIS file.
     * Currently only weighted graphs are supported.
     * @param graph_file
     */
    template<bool directed = false, bool weighted = true, bool add_reverse_graph = false, unsigned int power_law_exponent = 3>
    static BasicGraph<directed, weighted> load_metis_file(std::ifstream& graph_file, const weight_converting w_conv, char* delta_option)
    {
        /*
         * Little note about METIS:
         * The first line contains the number of nodes, the number of edges and flag
         * The flag can be 0 (= unweighted) or 1 (= weighted)
         * The i-th (not commented) line ( contain a list of the neighbors of the
         * i-th node. Notice that the nodes are numbered from 1 to n (not 0 to n-1).
         * The number of edges does not include backward edges, so this number has
         * to be doubled.
         */
        NODE_ID num_nodes = 0;
        node_list_type nodes;
        EDGE_ID num_edges = 0;
        edge_list_type<directed, weighted> edges;

        w_type heaviest_weight = weighted ? 0.0 : 1.0;

        graph_file.seekg(0);     // move to the beginning of the file
        std::string line;

        // get the head of the file containing the number of nodes and edges and a flag
        // skip comment lines at the beginning
        do
        {
            std::getline(graph_file, line);
        }
        while(line.at(0) == '%');

        std::istringstream fileStream(line);
        int file_type_tmp;
        fileStream >> num_nodes >> num_edges >> file_type_tmp;

        const int file_type = file_type_tmp;    // for better optimization

        if(file_type > 1)
            throw std::invalid_argument("Unknown METIS file type flag.");

        if(weighted && file_type == 0)
            std::cerr << "The file is unweighted but is stored as weighted graph. This needs more memory as needed." << std::endl;

        if(!directed)
            num_edges *= 2;      // undirected edges are stored as two directed edges

        // initialize node and edge lists
        nodes.resize(num_nodes + 1);    // adding a sentinel
        edges.reserve(num_edges);

        // setting the sentinel
        nodes[num_nodes].start_edge = num_edges;

        NODE_ID src = 0, dest;
        w_type weight = 1;      // if weighted it gets overwritten, if not, every weight is either set to 1 or not stored at all

        while(std::getline(graph_file, line) && src < num_nodes)
        {
            // An empty line represents a node with no outgoing edges. Continue with the next node.
            if(line.length() == 0)
            {
                nodes[src].start_edge = edges.size();
                src++;
                continue;
            }

            // skip comment lines
            if(line.at(0) == '%')
                continue;

            std::istringstream lineStream(line);

            // set the current node
            nodes[src].start_edge = edges.size();

            while(lineStream >> dest)       // there is another node
            {
                if(file_type == 1)          // file is weighted
                    lineStream >> weight;   // then there is also another weight

                if(weighted)
                {
                    if(w_conv == weight_converting::POWER_LAW)
                        weight = uniform_to_power_law_weights<power_law_exponent>(weight);
                    else if(w_conv == weight_converting::EXPONENTIAL)
                        weight = uniform_to_exponential_weights(weight);

                    heaviest_weight = std::max(heaviest_weight, weight);
                }

                edges.emplace_back(dest - 1, weight);     // METIS labels nodes from 1 to n, we count nodes from 0 to n - 1
            }

            src++;
        }

        assert(num_nodes == nodes.size() - 1);
        assert(num_edges == edges.size());

        w_type delta = GraphRW::get_delta(delta_option, heaviest_weight);
        GraphRW::partition_edges_by_weight(nodes, edges, delta);

        // link all backward edges to the corresponding forward edges.
        if(!directed)
            GraphRW::link_backward_edges(nodes, edges);

        if(directed && add_reverse_graph)
            return BasicGraph<directed, weighted>(nodes, edges, heaviest_weight, delta,
                                                  GraphRW::get_reverse_graph<directed, weighted>(nodes, edges, heaviest_weight, delta));

        return BasicGraph<directed, weighted>(nodes, edges, heaviest_weight, delta);
    }

    /**
     * Computes the reverse graph that is represented by the nodes_orig and edges_orig.
     * @tparam directed
     * @tparam weighted
     * @param nodes_orig The original node list containing a sentinel.
     * @param edges_orig The original edge list
     * @param heaviest_weight the heaviest weight in the original graph (will not change)
     * @param delta The delta used to classify the edges in light and heavy.
     * @return The reverse graph that is represented by the nodes_orig and edges_orig.
     */
    template<bool directed, bool weighted>
    static std::unique_ptr<const BasicGraph<directed, weighted>> get_reverse_graph(const node_list_type& nodes_orig,
                                                             const edge_list_type<directed, weighted>& edges_orig,
                                                             const w_type heaviest_weight, const w_type delta) noexcept
    {
        if(!directed)
            throw std::invalid_argument("Don't compute the reverse of a undirected graph.");

        node_list_type nodes(nodes_orig.size());        // contains a sentinel
        std::vector<edge_list_type<directed, weighted>> edges_per_node(nodes_orig.size() - 1);      // the sentinel has no edges
        edge_list_type<directed, weighted> edges;
        edges.reserve(edges_orig.size());

        const auto nodes_size = nodes_orig.size() - 1;  // using the sentinel
        for(NODE_ID u_id = 0; u_id < nodes_size; u_id++)
        {
            EDGE_ID end = nodes_orig[u_id + 1].start_edge;
            for(auto e_id = nodes_orig[u_id].start_edge; e_id < end; e_id++)
            {
                edges_per_node[edges_orig[e_id].get_target()].emplace_back(u_id, edges_orig[e_id].get_weight());
            }
        }

        for(NODE_ID u_id = 0; u_id < nodes_size; u_id++)
        {
            nodes[u_id].start_edge = edges.size();
            edges.insert(edges.end(), edges_per_node[u_id].begin(), edges_per_node[u_id].end());
        }

        nodes.back().start_edge = edges.size();    // setting the new sentinel

        assert(nodes_orig.size() == nodes.size());
        assert(edges_orig.size() == edges.size());

        GraphRW::partition_edges_by_weight(nodes, edges, delta);

        // the object gets deleted in the destructor of the original graph.
        return std::make_unique<const BasicGraph<directed, weighted>>(nodes, edges, heaviest_weight, delta);
    }

    /**
     * Sets delta according to delta_option. It does not precompute any edge weights.
     * If delta_option is not valid, delta is set to 0.1
     * @param delta_option Takes one of the following
     *                     "-D" for Dijkstra, which sets delta to 1
     *                     "-BF" for Bellman-Ford which sets delta to the heaviest weight
     *                     "<float>" sets delta to this number, if it is >0
     */
    static w_type get_delta(char* delta_option, w_type heaviest_weight)
    {
        if(delta_option[0] == '-')
        {
            const char dijkstra[] = "-D";
            const char bellman_ford[] = "-BF";

            if(strcmp(delta_option, dijkstra) == 0)
            {
                return 1;  // todo is this correct if edge weights < 1 exist?   this needs to be the lightest weight...
            }

            if(strcmp(delta_option, bellman_ford) == 0)
            {
                return heaviest_weight;
            }

            throw std::invalid_argument("wrong option for delta. Only -D (Dijkstra) and -BF (Bellman Ford) is accepted.");
        }
        else
        {
            w_type delta = strtod(delta_option, nullptr);

            if(delta <= 0)
            {
                std::cerr << "WARNING: delta must be > 0, delta will be set to 0.1" << std::endl;
                return 0.1;
            }

            return delta;
        }
    }

private:
    /**
     * Links edges to their backward edges. This function does nothing if the graph is directed.
     * @tparam directed
     * @tparam weighted
     * @param nodes         List of all nodes including a sentinel at the end.
     * @param[in,out] edges List of all edges.
     */
    template<bool directed, bool weighted>
    static void link_backward_edges(const node_list_type& nodes, edge_list_type<directed, weighted>& edges) noexcept
    {
        // if the graph is directed, then we cannot link backward edges
        if(directed)
            return;

        const auto end = static_cast<NODE_ID>(nodes.size() - 1);

#pragma omp parallel for    // link_backward_edges()
        for(NODE_ID i = 0; i < end; i++)
        {
            for(EDGE_ID j = nodes[i].start_edge, no_nghs = nodes[i + 1].start_edge; j < no_nghs; j++)
            {
                edges[j].set_backwards_edge_id(GraphRW::find_edge_id(edges[j].get_target(), i, nodes, edges));
            }
        }
    }

    /**
     * Converts every edge weight into a float in [0,1], by dividing every weight by the heaviest weight.
     * The function does nothing, if the edges are already in [0,1] or if the graph is unweighted.
     * @tparam directed
     * @tparam weighted
     * @param[in,out] edges
     * @param[in,out] heaviest_weight
     */
    template<bool directed, bool weighted>
    static void make_float_weights(edge_list_type<directed, weighted>& edges, w_type& heaviest_weight)
    {
        // If there are no weights, they cannot be converted.
        if(!weighted)
            return;

        if(heaviest_weight > 1.0)
        {
            for(auto& edge : edges)
            {
                edge.set_weight(edge.get_weight() / heaviest_weight);
            }

            heaviest_weight = static_cast<w_type>(1.0);
        }
        else if(heaviest_weight > 0.0)
        {
            std::cerr << "Weights are already in [0,1] -> weights were not changed" << std::endl;
        }
        else
        {
            throw std::invalid_argument("heaviest weight is zero -> weights cannot be converted to floats.");
        }
    }

    /**
     * Converts a uniform random value y over [0,1] into a power law random value x over [0,1] using x = y^(1/(n+1)).
     * @param y
     * @return a power law random value in [0,1]
     */
    template<unsigned int n>
    static inline w_type uniform_to_power_law_weights(const w_type y) noexcept
    {
        return pow(y, 1.0 / (static_cast<double>(n) + 1.0));
    }

    /**
     * Converts a uniform random value y over [0,1] into a exponential random value x over [0,1] using x = 1 - e^-y.
     * @param y
     * @return a exponential random value in [0,1]
     */
    static inline w_type uniform_to_exponential_weights(const w_type y) noexcept
    {
        return 1 - exp(-static_cast<double>(y));
    }

public:
    /**
     * Partitions the edge list of each node by weight such that every edge with weight at most delta comes before the
     * other edges. It also sets the number of light edges for every node.
     * It is assumed that the nodes contain a sentinel at the end.
     *
     * IMPORTANT!
     * This changes the ID of some edges. So if the graph is directed, the backward edge ids need to be set after the
     * partitioning!
     * @tparam directed
     * @tparam weighted
     * @param nodes         The list of all nodes including a sentinel at the end.
     * @param[in,out] edges The list of all edges.
     * @param delta         The weight threshold to edges gets partitioned by.
     */
    template<bool directed = false, bool weighted = true>
    static void partition_edges_by_weight(node_list_type& nodes, edge_list_type<directed, weighted>& edges, const w_type delta)
    {
        const auto end = static_cast<NODE_ID>(nodes.size() - 1);

        if(!weighted)
        {
            // Every edge has the same weight. If the first edge is light, every edge is. Then each number of light
            // edges needs to be set to the number of neighbors.
            if(edges.front().get_weight() <= delta)
            {
                for(NODE_ID node_id = 0; node_id < end; node_id++)
                {
                    nodes[node_id].num_light_edges = static_cast<NODE_ID>(nodes[node_id + 1].start_edge - nodes[node_id].start_edge);
                }
            }
            // else, every node has only heavy out edges or zero light edges. Zero is the default value so no changes needed.

            return;
        }

        for(NODE_ID node_id = 0; node_id < end; node_id++)
        {
            auto middel = std::partition(edges.begin() + nodes[node_id].start_edge,
                                         edges.begin() + nodes[node_id + 1].start_edge,
                                         [delta](Edge<directed, weighted>& e) -> bool { return e.get_weight() <= delta; }
            );

            nodes[node_id].num_light_edges = static_cast<NODE_ID>(std::distance(edges.begin() + nodes[node_id].start_edge, middel));
        }
    }

private:
    /**
     * Returns the index of the (directed) edge [src, target] if it exists, else NULL_EDGE.
     * Linear search is used.
     * @tparam directed
     * @tparam weighted
     * @param src       Source Node
     * @param target    Target Node
     * @param nodes     The list of all nodes including a sentinel at the end.
     * @param edges     The list of all edges.
     * @return The index of the (directed) edge [src, target] if it exists, else NULL_EDGE.
     */
    template<bool directed, bool weighted>
    static EDGE_ID find_edge_id(const NODE_ID src, const NODE_ID target, const node_list_type& nodes,
                                const edge_list_type<directed, weighted>& edges) noexcept
    {
        const EDGE_ID end_edge_id = nodes[src + 1].start_edge;

        for(EDGE_ID i = nodes[src].start_edge; i < end_edge_id; i++)
        {
            if(edges[i].get_target() == target)
                return i;
        }

        return NULL_EDGE;
    }
};

#endif  // _GRAPH_RW_H
