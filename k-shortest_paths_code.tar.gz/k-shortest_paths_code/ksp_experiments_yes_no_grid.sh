#!/usr/bin/env bash

#################
#run experiments#
#################
g_grid=("grid/n22_square.weighted.connected.edgelist" "grid/n22_rect.weighted.connected.edgelist")

cd build

#change this accordingly
threads=(1 10)

#collect machine info
for g in ${g_grid[@]}
do
  log="../results/parallel_ksp_performance/$g""_no_early_stopping.log"
  lscpu >> $log
done 

run=(0 1)

#merge later
for r in ${run[@]}
do
  #use RMAT graphs
  for g in ${g_grid[@]}
  do
    for t in ${threads[@]}
    do
      #(2) don’t use early stopping (do not iterate over K in this case and only use 1 thread)
      log="../results/parallel_ksp_performance/$g""_no_early_stopping.log"
      #first run using 1 thread
      cmake -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DKSP_NUM_THREADS=$t -DNO_SSSP_EARLY_STOPPING" ..
      cmake --build . --target ksp_performance
      ./ksp_performance ../resources/$g $r EDGELIST 5 All static 0.01 >> $log
    done
  done
done
