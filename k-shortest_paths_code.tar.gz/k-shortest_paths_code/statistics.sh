#!/usr/bin/env bash

for type in "" "_uniform";
do
    for n in $(seq $1 $2);
    do
        file_name=gnm_${n}m_$((4*$n))m$type;
        printf "$file_name  |";
        for i in $(seq 1 20);
        do
            ./cmake-build-debug/yellow_graph_size ./resources/$file_name.edgelist >> ./results/stats/$file_name.log;
            printf "=";
        done
        echo "|";
#        fix the JSON formatting
        echo "[$(cat ./results/stats/$file_name.log | tail -c +2)]" > ./results/stats/$file_name.log;
    done
done