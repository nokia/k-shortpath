#!/usr/bin/env bash

for type in "" "_uniform";
do
    for n in $(seq 1 10);
    do
        file_name=gnm_${n}m_$((4*$n))m$type;
        printf "$file_name  |";
        for delta in 0.05 0.1 0.15 0.2 0.25 0.3;
        do
            ./build/shortest_path_performance ./resources/$file_name.edgelist $delta 50 >> ./results/sssp_performance/$file_name.log;
            printf "=";
        done
        echo "|";
    done
done
