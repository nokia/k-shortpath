#!/usr/bin/env bash

# Inputs:
# 1. path to the metis file of the graph
# 2. number of runs
# 3. output file path without file ending
#

# run the experiments with uniform edge weights
./build_1/yellow_graph_size $1 $(($2 * 2)) >> $3.log

# fix the JSON formatting
echo "[$(cat $3.log | tail -c +2)]" > $3.log;

# run the experiments with exponential edge weights
./build_1/yellow_graph_size $1 $2 -exp >> $3.exp.log

# fix the JSON formatting
echo "[$(cat $3.exp.log | tail -c +2)]" > $3.exp.log;

# run the experiments
./build_2/yellow_graph_size $1 $2 >> $3.uw.log

# fix the JSON formatting
echo "[$(cat $3.uw.log | tail -c +2)]" > $3.uw.log;
