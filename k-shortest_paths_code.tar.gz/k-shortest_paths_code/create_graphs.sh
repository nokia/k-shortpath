#!/usr/bin/env bash

#prepare resources and results
cd resources
mkdir RMAT
mkdir random
cd ../results
mkdir parallel_ksp_performance
cd parallel_ksp_performance
mkdir RMAT
mkdir random
cd ../..

#build PaRMAT
git submodule update --init --recursive
cd PaRMAT/Release
make

#create RMAT
#n20_128
./PaRMAT -nVertices 1048576 -nEdges 134217728 -output ../../resources/RMAT/n20_128.edgelist -threads 10 -sorted -noEdgeToSelf -noDuplicateEdges -undirected

#n22_4
./PaRMAT -nVertices 4194304 -nEdges 16777216 -output ../../resources/RMAT/n22_4.edgelist -threads 10 -sorted -noEdgeToSelf -noDuplicateEdges -undirected

#build ksp code
cd ../..
mkdir build
cd build
cmake DCMAKE_C_COMPILER=/usr/bin/gcc-5 -DCMAKE_CXX_COMPILER=/usr/bin/g++-5 -DCMAKE_BUILD_TYPE=EXPERIMENT -DCMAKE_CXX_FLAGS="-DUNDIRECTED" ..
cmake --build . --target add_float_weights
cmake --build . --target connected
cmake --build . --target generate_g_nm

#add random weights to RMAT graphs
./add_float_weights ../resources/RMAT/n20_128.edgelist > ../resources/RMAT/n20_128.weighted.edgelist
./add_float_weights ../resources/RMAT/n22_4.edgelist > ../resources/RMAT/n22_4.weighted.edgelist

#extract connected component
./connected ../resources/RMAT/n20_128.weighted.edgelist EDGELIST > ../resources/RMAT/n20_128.weighted.connected.edgelist
./connected ../resources/RMAT/n22_4.weighted.edgelist EDGELIST > ../resources/RMAT/n22_4.weighted.connected.edgelist

